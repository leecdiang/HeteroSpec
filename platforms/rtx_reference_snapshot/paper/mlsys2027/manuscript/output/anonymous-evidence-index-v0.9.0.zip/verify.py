#!/usr/bin/env python3
"""Preserved v087 assertions plus v088 post-study descriptor replay."""
import csv,hashlib,json
from pathlib import Path
from verify_v087 import main as prior_main
from global_analysis import compute,CONDITIONS
ROOT=Path(__file__).resolve().parent
def main():
    prior_main()
    raw=(ROOT/'evidence/RTX_V4.json').read_bytes()
    actual,rows=compute(json.loads(raw));expected=json.loads((ROOT/'derived/GLOBAL_ANALYSIS_V088.json').read_text())
    assert hashlib.sha256(raw).hexdigest()==expected['source_member_sha256']
    assert actual=={k:v for k,v in expected.items() if k not in ('source_member_sha256','plan_sha256')}
    with (ROOT/'derived/RTX_V4_PROMPT_MEDIANS_V088.csv').open(newline='') as f: csv_rows=list(csv.DictReader(f))
    assert len(csv_rows)==len(rows)==19
    for a,b in zip(csv_rows,rows):
        assert a['task_id']==b['task_id']
        assert all(float(a[c])==b[c] for c in CONDITIONS)
    print(json.dumps({'status':'PASS','v088_descriptors':'POST_STUDY_PASS','prompt_rows':19,'conditions':3,'primary_estimates':'unchanged; prior verifier executed','limits':actual['limits']}))
if __name__=='__main__':main()
