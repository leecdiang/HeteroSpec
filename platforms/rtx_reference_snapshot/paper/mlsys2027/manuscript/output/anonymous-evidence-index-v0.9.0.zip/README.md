# Anonymous evidence index v0.8.8
Extract into a clean directory and run `python3 -B verify.py`.
Requires only Python standard library; no model, GPU or network.
Retained original studies and v0.8.7 V4 arrays/timers/verifiers are unchanged.
New descriptors summarize 19 prompt medians per condition and cross failures.
They are post-study, with outcomes known, and do not change primary GM/CI.
The blocked batched speedup/CI remain null. Observation spread is not a CI.
Compact arrays/timer fields permit CPU recalculation, not raw state inspection.
Full capsule identities/entries remain in INDEX.json. Reported ordering is not
trusted external chronology; omitted runtime/model/driver bytes are unavailable.
The source ZIP reconstructs documents separately; no functional pass@k claim.
