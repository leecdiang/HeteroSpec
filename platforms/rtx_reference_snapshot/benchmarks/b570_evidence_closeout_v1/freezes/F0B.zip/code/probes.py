from runtime import *
try:
 for arm in load(R/'ZERO_FORWARD_PLAN.json')['arms']:
  with Worker(arm,'probe_'+arm,'core','F0P_FINAL',probe=True) as w:w.finish_probe()
 save(R/'ZERO_FORWARD_RESULT.json',dict(status='PASS',zero_forward_units=2,forward_calls=0,physical_residency='UNKNOWN',utc=now(),worker_identity_and_memory_gates='PASS',freeze_commit=load(R/'F0P_FINAL_REMOTE_READBACK.json')['commit']))
except BaseException as e:
 save(R/'ZERO_FORWARD_RESULT.json',dict(status='FAILED',reason=str(e),utc=now()));raise
