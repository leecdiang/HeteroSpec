from pathlib import Path
import json,hashlib
r=Path(__file__).parent
names=["prepare.py","setup.py","prefill_submit.cpp","main.cpp.inc","host-prefix.patch","CMakeLists.txt","INPUT_PANEL.json","MODEL_IDENTITY.json","PREREGISTRATION.json","RUN.ps1","recheck.py","freeze.py","BUILD_MANIFEST.json","SOURCE_AUDIT.md"]
out=[]
for name in names:
    b=(r/name).read_bytes()
    out.append({"path":"benchmarks/b570_draft_prefill_submission_v1/"+name,"content":b.decode("utf-8"),"encoding":"utf-8","bytes":len(b),"sha":hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()})
(r/"PREREG_PAYLOAD.json").write_text(json.dumps(out))
print(len(out))
