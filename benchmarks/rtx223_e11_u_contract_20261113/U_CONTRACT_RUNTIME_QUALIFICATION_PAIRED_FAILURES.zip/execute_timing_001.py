from pathlib import Path
import json,hashlib,sys,runpy
p=Path(__file__).resolve().parent
plan=p/'TIMING_PLAN_001.json'
assert hashlib.sha256(plan.read_bytes()).hexdigest()=='9d77d319f0e69c7dbd8b231badf2749e9f1e99a0b3dfba9f55afeae5eb47a0ec'
for row in json.loads(plan.read_bytes())['controller_inputs']:
 assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256']
sys.argv=[str(p/'runner_v3.py'),str(plan)]
runpy.run_path(str(p/'runner_v3.py'),run_name='__main__')
