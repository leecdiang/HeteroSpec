"""CPU8 evidence interface. Keep old raw audit output and total-accounting gap intact."""
import sys,os,json,hashlib,shutil,datetime
from pathlib import Path
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,x):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(x,f,sort_keys=True,indent=2,allow_nan=False);f.write('\n')
def ledger(root):
    legacy=root/'legacy';rows=[];refs=[]
    folder=legacy/'task/raw_os';folder.mkdir(parents=True,exist_ok=True)
    for f in sorted((root/'processes').glob('*/OS_EVENTS.jsonl')):
        raw=f.read_bytes();dest=folder/(f.parent.name+'.jsonl')
        if dest.exists():assert dest.read_bytes()==raw
        else:dest.write_bytes(raw)
        digest=h(dest)
        for r in [json.loads(s) for s in raw.splitlines()]:
            if r['event'] not in ['PROCESS_CREATE','PROCESS_CLOSED']:continue
            record=dict(kind='PROCESS_CREATE' if r['event']=='PROCESS_CREATE' else 'PROCESS_CLOSED',pid=r['pid'],created_filetime=int(r['created_filetime']),at_ns=r['at_ns'],source_event=dict(path=dest.relative_to(legacy).as_posix(),sha256=digest,seq=r['seq']),scope='Real independently observed task-command descendant')
            if r['event']=='PROCESS_CREATE':record.update(parent_pid=r['parent_pid'],role=r['role'],command_sha256=r['command_sha256'],command=r['command'],image=r['image'])
            else:record.update(exit_filetime=int(r['exit_filetime']),exit_code=r['exit_code'],lifetime_seconds=r['lifetime_seconds'])
            rows.append(record)
    rows.sort(key=lambda x:x['at_ns']);out=legacy/'task/PROCESS_LEDGER.snapshot.jsonl'
    if out.exists():out.rename(out.with_name('PROCESS_LEDGER.previous-'+str(len(list(out.parent.glob('PROCESS_LEDGER.previous-*'))))+'.jsonl'))
    out.write_text(''.join(json.dumps(x,sort_keys=True)+'\n' for x in rows))
    write(legacy/('task/TOTAL_LEDGER_GAP-'+str(len(list((legacy/'task').glob('TOTAL_LEDGER_GAP-*'))))+'.json'),dict(status='UNKNOWN',whole_task_ledger_valid=None,unobserved=['command observer own OS exit','watchdog own OS exit','command shell and tool host','preflight and early portable regression roots'],known_observed_prefix_not_complete_task_ledger=True))
    return rows
def manifest(legacy,runid):
    name='AUDIT_INPUT_MANIFEST-'+runid+'.json';p=legacy/name
    members=[]
    for f in sorted(legacy.rglob('*')):
        if f.is_file() and not f.name.startswith('AUDIT_INPUT_MANIFEST'):
            assert not f.is_symlink() and not f.is_junction();members.append(dict(path=f.relative_to(legacy).as_posix(),bytes=f.stat().st_size,sha256=h(f)))
    write(p,dict(members=members));return name
def qualify(raw,runid,cid,phase):
    row=[r for r in raw['cases'] if r.get('run')==runid and r.get('case_id')==cid]
    assert len(row)==1,'one case required';r=row[0]
    if phase=='FORMAL':assert r['status']=='PASS',json.dumps(dict(status=r['status'],reason=r.get('reason'),checks=r.get('checks'),problems=raw.get('problems')))
    else:
        assert cid in ['normal_single','journal_write_failure'],'bounded D0 smoke'
        required=['raw_hashes','coverage_checked','process_ledger','cleanup_checked']
        required+=['work_completed','post_audit_separated'] if cid=='normal_single' else ['trigger_side_effect','detector_object_match','independent_outer_receipt']
        assert all(r['checks'].get(k) is True for k in required),json.dumps(r['checks'])
        assert r['receipt']['control_point_reached'] and r['receipt']['early_failure'] is False,'real control required'
    return dict(status='CPU8_CASE_PASS' if phase=='FORMAL' else 'D0_BRIDGE_SMOKE_PASS',run=runid,case_id=cid,phase=phase,original_raw_status=r['status'],original_raw_reason=r.get('reason'),task_total_ledger_status='UNKNOWN',case_checks=r['checks'],reference_scope='Original raw audit retained separately; no PASS Boolean translation or invented outer OS fields')
def audit(root,runid,cid,phase,outdir):
    root=Path(root).resolve();legacy=root/'legacy';design=legacy/'repo/benchmarks/b570_supervision_fix_v2';outdir=Path(outdir);outdir.mkdir(parents=True,exist_ok=True)
    ledger(root);m=manifest(legacy,runid);sys.path.insert(0,str(design/'host'));import raw_audit
    raw=raw_audit.audit(legacy,m);write(outdir/(runid+'.legacy_raw_audit.json'),raw)
    try:result=qualify(raw,runid,cid,phase)
    except BaseException as e:
        write(outdir/(runid+'.qualification.json'),dict(status='FAIL',case_id=cid,run=runid,error=repr(e)));raise
    result.update(raw_audit_sha256=h(outdir/(runid+'.legacy_raw_audit.json')),manifest_sha256=h(legacy/m));write(outdir/(runid+'.qualification.json'),result);return result
if __name__=='__main__':
    root,runid,cid,phase=sys.argv[1:5];print(json.dumps(audit(root,runid,cid,phase,Path(root)/'reports'),sort_keys=True))
