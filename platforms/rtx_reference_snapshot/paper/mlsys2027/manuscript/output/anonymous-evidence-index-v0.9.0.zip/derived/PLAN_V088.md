POST-STUDY V0.8.8 DERIVED PLAN
Original outcomes were known before this plan and computation.
## Quantitative inputs and operations

Use the exact anonymous v0.8.7 index (SHA256 36609ad6579775deeb7edccc70f89bd9a242346b7446cc28575703ee7a8e3a04), member evidence/RTX_V4.json. Its original 171 B records retain QPC delta/frequency and complete IDs; 285 A arrays retain the five complete conditions. Original raw-record provenance and the previous nine-capsule audit remain prior receipts.

- For each of the 19 prompts in frozen task order and each B condition, take the median of its three QPC durations. Convert to seconds only for presentation. Retain all 57 prompt-condition medians in CSV.
- Summarize each vector of 19 medians with min, linearly interpolated Q25, median, Q75 and max. Also count inclusive-EOG/cap endpoints. These are observation-spread descriptors, not confidence intervals or independent runs.
- Do not divide distribution medians to estimate speedup. Keep the frozen paired prompt-median GM, 10,000-draw seed 2026100204 and original CI unchanged. The batched speedup/CI remain null because its ID gate fails.
- Compare each A predictor's full array with native live per prompt/repetition. Preserve /15, /18 and /25 intersections and differences, first indices and own/live IDs. No first-token-only shortcut or exclusion.
- Independently cross-check all B duration descriptors against retained original B records using a separate numerical implementation. Reuse the v0.8.7 CPU verifier for the frozen primary estimates and earlier studies.

Existing B570 score/margin descriptors, 358H processed-total bounds and M4 fixed-mode medians are reused under their original post-study scope. No cross-campaign trend, pooled hardware GM, event-level inference or population failure rate is formed.

