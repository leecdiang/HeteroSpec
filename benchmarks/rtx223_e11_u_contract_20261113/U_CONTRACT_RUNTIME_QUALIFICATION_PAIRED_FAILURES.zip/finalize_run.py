"""Preserve original snapshots and report real8-call qualification;no timing claim."""
from pathlib import Path
import json,hashlib,shutil,datetime
p=Path(__file__).resolve().parent;state=Path('D:/HeteroSpec-PC/rtx223-e11-u-contract');sha=lambda q:hashlib.file_digest(Path(q).open('rb'),'sha256').hexdigest()
for filename in ['REPORT_ZH.md','RESULT.json','FINAL_IDENTITIES.json','HOST_SUMMARY.json']:
 target=p/('PRE_GPU_'+filename)
 if not target.exists():shutil.copy2(p/filename,target)
family=(state/'family.jsonl').read_bytes();prefix=(p/'FAMILY_PREFIX_BEFORE_CONTINUATION.jsonl').read_bytes();assert family.startswith(prefix)
events=[json.loads(x) for x in family.splitlines()];assert events[-1]['kind']=='CONTINUATION_STOPPED'
reserved=sum(x['reserved'] for x in events if x['kind']=='RESERVED_BEFORE_TASK');assert reserved==430 and all(x.get('additional_reserved',0)==0 for x in events)
qual=json.loads((p/'evidence-run/profile/AC/Temp/e11-qualification-001/result.json').read_bytes());assert qual['status']=='PASS_E11_TWO_CONTRACTS' and qual['explicit_prelaunch_charged']==8
attempts=[]
for name in ['timing-001','timing-002']:
 rows=[json.loads(x)['event'] for x in (state/name/'attempt.jsonl').read_bytes().splitlines()];assert rows[-1]['kind']=='FAIL' and rows[-1]['owned_process_exit_confirmed']
 assert not any(x.get('kind') in ['OWNED_SUSPENDED','PERMIT'] for x in rows)
 exits=[x for x in rows if x.get('kind')=='EXIT'];assert len(exits)==1 and exits[0]['code'] is None and exits[0]['confirmed']
 attempts.append(dict(name=name,status='FAIL_BEFORE_NATIVE_CREATION',explicit_permits=0,terminal=rows[-1]))
host=json.loads((p/'HOST_POSTRUN.private.json').read_bytes());assert not host['competing_workers'] and not host['project_services'] and not host['project_tasks']
pids={x['ProcessId'] for x in host['all_processes']};assert not {26356,3004}&pids
assert not Path('D:/HeteroSpec-PC/RTX_EXPERIMENT.lock').exists() and not (state/'runner.lease').exists()
assert json.loads((p/'PROFILE_CLEANUP.json').read_bytes())['deleted']
for row in json.loads((p/'PROFILE_DATA_PRESERVED.json').read_bytes())['files']:assert sha(row['preserved'])==row['sha256']
for row in json.loads((p/'PARENTS_VERIFIED.json').read_bytes())['files']:assert sha(row['path'])==row['sha256'],row['path']
native_inputs=json.loads((p/'build-003/FREEZE.json').read_bytes())['inputs']
for name,row in native_inputs.items():assert sha(name)==row['sha256'],name
(p/'evidence-run/family.jsonl').write_bytes(family)
for name in ['cpu-001','cpu-002','qualification-001','timing-001','timing-002']:
 for q in (state/name).iterdir():
  if q.is_file():shutil.copy2(q,p/'evidence-run'/name/q.name)
result=dict(schema='heterospec.e11.real-U-qualification.v2',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='NUMERICAL_PASS_TIMING_BLOCKED_FOREIGN_CONTEXT',parents=json.loads((p/'PARENT_HEADS.json').read_bytes()),upstream='0fb8f157702702f33f4e018de8701b2569a1bc28',gates=dict(A_old_reference_B_full_bitwise='PASS_2_REPLAYS',B_new_independent_U='PASS_2_REPLAYS_AND_SEPARATE_CPU_CHECKER',U_legacy_bitwise='NON_EQUIVALENT',C_paired_timing='NOT_RUN_BOTH_ADMISSIONS_REFUSED',full_default_backend='COMPILE_PASS_RUNTIME_NOT_RUN',actual_occupancy='NOT_MEASURED',L2_DRAM='NOT_MEASURED',service5pct='UNDETERMINED_NO_TIMING_OR_SAME_REQUEST_STACK',cleanup='PASS',old_e10='FAIL_UNCHANGED',old4096='NOT_CLOSED',production_native='DENY_UNCHANGED'),native_qualification=qual,independent_CPU=json.loads((p/'INDEPENDENT_QUALIFICATION.json').read_bytes()),timing_attempts=attempts,budget=dict(limit=500,global_reserved=430,explicit_application_permits=8,qualification=8,timing_001=0,timing_002=0,unused_reserved_not_refunded=422,unreserved=70,continuation_additional_reserved=0,original_timing416_preserved=True,old_ledgers_unchanged=True),consumption=dict(model_loads=0,new_captures=0,forward=0,numerical_root_DLL_loads=0,native_GPU_processes=1,CUDA_runtime_driver_initialized=True,implicit_context_count=None,full_lifecycle_physical_launches=None),samples=0,pairs=0,foreign_context=json.loads((p/'FOREIGN_CONTEXT_002.json').read_bytes()),next='Require an idle exclusive window without video-session GPU activity;new entry must wait read-only before native creation;no further timing automatically queued',candidate='one conditional8warp raw shared-stage proposal only;not implemented/run')
(p/'RESULT.json').write_text(json.dumps(result,indent=2),encoding='utf8')
notrun=dict(status='NOT_RUN',raw_samples=0,reason='Both timing requests refused before native process creation;no CUDA events recorded',attempts=attempts,not_a_negative_speed_result=True,no_service_conclusion=True)
(p/'TIMING_NOT_RUN.json').write_text(json.dumps(notrun,indent=2),encoding='utf8')
(p/'LEDGER_INTERPRETATION.json').write_text(json.dumps(dict(global_debits='family RESERVED_BEFORE_TASK only:14+416=430;CPU tasks0',inner_attempt_reservation_field='416 denotes same logical timing ceiling;continuation references003-timing and adds0 globally,not a second416 debit',prefix_preserved_sha256=hashlib.sha256(prefix).hexdigest(),final_journal_sha256=hashlib.sha256(family).hexdigest(),actual8=qual['explicit_by_operation'],timing_native_not_created_both=True,unused422_not_refunded=True,old_experiments_not_borrowed=True),indent=2),encoding='utf8')
cleanup=dict(pass_=True,utc=host['end_utc'],controllers_absent=[26356,3004],competing_workers=host['competing_workers'],project_tasks=host['project_tasks'],project_services=host['project_services'],canonical_lease_exists=False,runner_lease_exists=False,profile_deleted=True,preserved_files=9,unrelated_processes_killed=0,ToDesk_settings_changes=0,ACL_changes=0,security_changes=0,limits='point-in-time host snapshot;not a guarantee about future external tasks')
(p/'CLEANUP_FINAL.json').write_text(json.dumps(cleanup,indent=2),encoding='utf8')
identity=dict(pass_=True,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),native_build_inputs_rechecked=len(native_inputs),parent_records_rechecked=len(json.loads((p/'PARENTS_VERIFIED.json').read_bytes())['files']),native_sha256=sha(p/'build-003/operator-upstream.exe'),family_prefix_exactly_preserved=True,final_family_sha256=sha(state/'family.jsonl'),raw_data_preserved=True,old_failures_unchanged=True,cleanup=True)
(p/'FINAL_IDENTITIES.json').write_text(json.dumps(identity,indent=2),encoding='utf8')
print(json.dumps(dict(qualification='PASS',timing='NOT_RUN',reserved=430,actual=8,cleanup=True)))
