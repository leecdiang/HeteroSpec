from common import *
assert not any(json.loads(s).get('bucket') in ['formal','formal_warm'] for s in (R/'LEDGER.jsonl').read_text().splitlines())
for name in ['F0B_PRECOMMIT.json','F0B_MANIFEST.json','F0B_REMOTE_READBACK.json']:
 shutil.copy2(R/name,R/'versions'/('INITIAL_'+name))
p=R/'code/freeze_formal.py';shutil.copy2(p,R/'versions/freeze_formal.pre-correction.py')
s=p.read_text();wrong="plan_sha256=load(R/'FORMAL_PLAN.json')['design_sha256']"
right="plan_sha256=hashlib.sha256(json.dumps(load(R/'FORMAL_PLAN.json'),ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()"
assert wrong in s;s=s.replace(wrong,right);p.write_text(s,encoding='utf8')
x=load(R/'F0B_PRECOMMIT.json');x['plan_sha256']=x['formal_plan_digest'];x['corrected_utc']=now();save(R/'F0B_PRECOMMIT.json',x)
save(R/'F0B_METADATA_CORRECTION.json',dict(status='CORRECTED_BEFORE_ANY_FORMAL_FORWARD_OR_WARMUP',initial_freeze_commit=load(R/'F0B_REMOTE_READBACK.json')['commit'],initial_archive_sha256=load(R/'F0B_REMOTE_READBACK.json')['verified'][0]['sha256'],problem='F0B_PRECOMMIT.plan_sha256 accidentally held design digest; formal_plan_digest and actual PLAN byte bindings were already correct.',change='plan_sha256 corrected to the canonical full FORMAL_PLAN digest; source writer corrected; initial files/commit preserved.',inputs_changed=False,schedule_changed=False,native_source_changed=False,runtime_measurer_changed=False,model_changed=False,engineering_data_changed=False,utc=now()))
archive=PUBLIC/'freezes/F0B.zip'
assert archive.resolve().parent==(PUBLIC/'freezes').resolve()
assert sha(archive)==load(R/'F0B_REMOTE_READBACK.json')['verified'][0]['sha256']
archive.unlink() # Initial archive remains in actual pushed Git commit and original remote blob.
os.execv(sys.executable,[sys.executable,'-X','utf8',str(R/'code/seal_freeze.py'),'F0B'])
