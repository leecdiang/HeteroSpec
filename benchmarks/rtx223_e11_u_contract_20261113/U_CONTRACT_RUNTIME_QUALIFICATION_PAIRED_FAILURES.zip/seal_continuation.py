"""Seal a closed ledger prefix; never recreates or truncates the family journal."""
from pathlib import Path
import json,hashlib,importlib.util,datetime
p=Path(__file__).resolve().parent;state=Path('D:/HeteroSpec-PC/rtx223-e11-u-contract');sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
family=state/'family.jsonl';data=family.read_bytes();events=[json.loads(x) for x in data.splitlines()]
assert events[-1]['kind']=='STOPPED' and events[-1]['reserved']==430
assert not (state/'runner.lease').exists() and not Path('D:/HeteroSpec-PC/RTX_EXPERIMENT.lock').exists()
sp=importlib.util.spec_from_file_location('proof',p/'continuation_proof.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
failed=state/'timing-001/attempt.jsonl';qual=Path(json.loads((p/'STAGING_V3.json').read_bytes())['profile'])/'Temp/e11-qualification-001/result.json'
audit=m.audit(events,[json.loads(x) for x in failed.read_bytes().splitlines()],json.loads(qual.read_bytes()),sha(p/'CONTRACT.json'))
assert not list((qual.parent.parent/'e11-timing-001').glob('*'))
with (p/'FAMILY_PREFIX_BEFORE_CONTINUATION.jsonl').open('xb') as f:f.write(data)
policy=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),prefix_sha256=sha(family),prefix_bytes=len(data),failed_attempt_sha256=sha(failed),qualification_result=str(qual),qualification_result_sha256=sha(qual),audit=audit,runner_context=json.loads((p/'CPU_SMOKE_PASS.json').read_bytes())['runner_context'],native_exe_sha256=sha(p/'build-003/operator-upstream.exe'),previous_failure='foreign context unknownPID;not ignored or whitelisted;currently absent in same-admin24samples',guards_unchanged=True,additional_reservation=0,same_protocol='12pairs5reps eachboundary,392calls',no_numerical_contract_change=True)
with (p/'CONTINUATION_POLICY.json').open('x',encoding='utf8') as f:json.dump(policy,f,indent=2)
s=(p/'analyze_v3.py').read_text().replace('e11-timing-001','e11-timing-002').replace('rtx223-e11-u-contract/timing-001','rtx223-e11-u-contract/timing-002')
with (p/'analyze_v4.py').open('x',encoding='utf8',newline='\n') as f:f.write(s)
s=(p/'Launch-Controller.ps1').read_text().replace('CONTROL_RELEASE.json','CONTINUATION_RELEASE.json').replace("'admin_controller.py'","'admin_continuation.py'").replace('ADMIN_LAUNCH.json','ADMIN2_LAUNCH.json').replace('e11 independent U-contract operator diagnostic only,500 independent explicit reservations','e11 append-only continuation of already charged416 timing reservation;500 total unchanged')
with (p/'Launch-Continuation.ps1').open('x',encoding='utf8',newline='\n') as f:f.write(s)
files=[p/x for x in ['admin_continuation.py','continuation_proof.py','CONTINUATION_POLICY.json','CONTINUATION_CPU_TESTS.json','runner_v4.py','observation_v2.py','CPU_PLAN_004.json','execute_cpu_004.py','Launch-Continuation.ps1','CONTRACT.json','STAGING_V3.json','DEPLOYMENT.json','INDEPENDENT_QUALIFICATION.json','PERFORMANCE_DECISION.json','analyze_v4.py','prepare_timing_continuation.py']]
release=dict(files=[dict(path=str(q),sha256=sha(q)) for q in files],scope='same500 family,430alreadycharged,416timing unspent:no refund/no reset;one continuation only;CPUreadmit first;120s,2processes,2GiB',all_old_records_preserved=True)
with (p/'CONTINUATION_RELEASE.json').open('x',encoding='utf8') as f:json.dump(release,f,indent=2)
print(json.dumps(audit))
