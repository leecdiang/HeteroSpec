INTEGRATED EMPIRICAL MANUSCRIPT v0.11.0
Build: latexmk -pdf main.tex; latexmk -pdf appendix.tex
Full clean packaging/QA: python scripts/build_v011.py (requires pypdf).
Optional chart regeneration: python scripts/figure_v011.py (requires matplotlib).
The included chart is generated already; the document needs no model or network.
All document dependencies are included; TeX comments are stripped for anonymity.
SHA256SUMS.json binds this source package.
Separate anonymous-integrated-evidence-v0.11.0.zip: python -B verify_v011.py.
That package validates retained exports and historical arithmetic, not execution
of omitted models/binaries or absolute experiment chronology. The author review,
raw provenance and venue assessment are separate from anonymous material.
