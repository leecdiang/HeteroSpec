from pathlib import Path
import hashlib,runpy,sys,json
p=Path(__file__).resolve().parent
plan=p/"CPU_PLAN_003.json"
assert hashlib.sha256(plan.read_bytes()).hexdigest()=="27d7898692e11d4e198dc54cc83f5444ec37172f989574abf5c12b6bb5912da7"
for row in json.loads(plan.read_bytes())["controller_inputs"]:
 assert hashlib.sha256(Path(row["path"]).read_bytes()).hexdigest()==row["sha256"]
sys.argv=[str(p/"runner-v3.py"),str(plan)]
runpy.run_path(str(p/"runner-v3.py"),run_name="__main__")
