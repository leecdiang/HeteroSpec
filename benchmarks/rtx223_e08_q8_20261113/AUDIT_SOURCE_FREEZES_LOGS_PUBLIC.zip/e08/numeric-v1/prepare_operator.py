"""Build-only isolated standalone arithmetic; all execution is separately gated."""
import os,sys,json,re,subprocess,hashlib,time,importlib.util
from pathlib import Path
here=Path(__file__).resolve().parent;study=here.parents[1]
old=study/'rtx221-round1-20261112';runtime=study/'rtx223-round1-resume-20261112-e04/runtime'
core=Path('D:/rtx192-review-v2/native-v2/cores/packed');cs=core/'ggml/src/ggml-cuda'
out=here/'operator-build-001';out.mkdir(exist_ok=False)
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2),encoding='utf8')
spec=importlib.util.spec_from_file_location('extract',old/'build_tools/build_operator.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
original=(cs/'mmvq.cu').read_text();assert sha(cs/'mmvq.cu')=='d9c69fafab943383b29e525417f5e2157a445c9b1afca97b7d9de23d20a2564a'
prefix=original[:original.index('// Dedicated MoE multi-token kernel.')];prefix=prefix.replace(m.extract_function(prefix,'bool ggml_cuda_should_use_mmvq('),'')
for inc in re.findall(r'^#include "([^"]+)"',prefix,re.M):prefix=prefix.replace('#include "'+inc+'"','#include "'+(cs/inc).resolve().as_posix()+'"')
(out/'bound_mmvq_prefix.cuh').write_text(prefix)
(out/'bound_quantizer.cuh').write_text(m.extract_function((cs/'quantize.cu').read_text(),'__launch_bounds__(CUDA_QUANTIZE_BLOCK_SIZE, 1)\nstatic __global__ void quantize_q8_1('))
assert (old/'native/two_group_q8.cuh').read_bytes()==(runtime/'source-v1/ggml/src/ggml-cuda/hs_pair4_q8.cuh').read_bytes()
(out/'two_group_q8.cuh').write_bytes((old/'native/two_group_q8.cuh').read_bytes())
s=(old/'native/operator_probe.cu').read_text()
s=s.replace('int main(int argc,char ** argv) {','static int used=0,limit=0;\nstatic void reserve(int n){need(n>0&&used+n<=limit,"explicit application budget exceeded before dispatch");used+=n;}\nint main(int argc,char ** argv) {')
s=s.replace('need(job.at("warmups")==3 && job.at("timing_blocks")==6,"unfrozen work count");','''need(job.at("warmups")==1 && job.at("timing_blocks")==6,"unfrozen work count");
        std::string phase=job.at("phase");need(phase=="qualification"||phase=="timing","phase");
        limit=phase=="qualification"?14:421;
        auto captured_a=load(job.at("quantized_activation_path"),size_t(pk/32)*8*sizeof(block_q8_1));
        need(sha256(captured_a)==job.at("quantized_activation_sha256"),"captured quantized SHA256");''')
s=s.replace('++quantizers;result["quantizer_launch_attempts"]=quantizers;','reserve(1);++quantizers;')
s=s.replace('projections+=arm==0?2:1;result["projection_launch_attempts_reserved"]=projections;','reserve(arm==0?2:1);projections+=arm==0?2:1;')
s=s.replace('for (int arm=0;arm<3;++arm) {\n            result["resources"]','if(phase=="qualification") for (int arm=0;arm<3;++arm) {\n            result["resources"]')
s=s.replace('const bool exact_a=ah==first_a','const bool exact_a=ah==captured_a && ah==first_a')
s=s.replace('        for (int arm=0;arm<3;++arm) for(int repeat=0;repeat<3;++repeat)', '        if(phase=="timing") {\n        for(int arm=0;arm<3;++arm)result["resources"][std::to_string(arm)]=resources(arm);\n        for (int arm=0;arm<3;++arm) for(int repeat=0;repeat<1;++repeat)')
s=s.replace('            if(mode==1) quantize();project(arm);','            for(int repetition=0;repetition<6;++repetition){if(mode==1) quantize();project(arm);}')
s=s.replace('{"event_ms",ms}','{"batch_repetitions",6},{"event_ms",ms},{"per_operator_ms",ms/6}')
s=s.replace('        result["quantizer_launches"]=quantizers;', '        check(cudaEventDestroy(begin));check(cudaEventDestroy(end));\n        }\n        result["quantizer_launches"]=quantizers;')
s=s.replace('result["capture_bytes"]=6*(abytes+ybytes);result["warmup_operator_calls"]=9;', 'result["capture_bytes"]=phase=="qualification"?6*(abytes+ybytes):0;result["warmup_operator_calls"]=phase=="timing"?3:0;result["phase"]=phase;result["explicit_limit"]=limit;result["explicit_prelaunch_charged"]=used;')
s=s.replace('        check(cudaEventDestroy(begin));check(cudaEventDestroy(end));check(cudaStreamDestroy(stream));','        check(cudaStreamDestroy(stream));')
s=s.replace('    } catch(const std::exception & error) {result["error"]=error.what();}','    } catch(const std::exception & error) {result["error"]=error.what();result["explicit_prelaunch_charged"]=used;result["explicit_limit"]=limit;}')
src=out/'operator_probe.cu';src.write_text(s)
cuda=runtime/'toolchain-v1/cuda';msvc=runtime/'toolchain-v2/msvc';vc=msvc/'VC/Tools/MSVC/14.44.35207';sdk=msvc/'Windows Kits/10';ver='10.0.26100.0'
env=os.environ.copy();env['PATH']=';'.join(map(str,[vc/'bin/Hostx64/x64',sdk/f'bin/{ver}/x64',cuda/'bin',Path('C:/Windows/System32')]))
env['INCLUDE']=';'.join(str(p) for p in [vc/'include',*[sdk/f'Include/{ver}/{x}' for x in ('ucrt','shared','um','winrt','cppwinrt')]])
env['LIB']=';'.join(str(p) for p in [vc/'lib/x64',sdk/f'Lib/{ver}/ucrt/x64',sdk/f'Lib/{ver}/um/x64'])
env['CUDA_PATH']=str(cuda);env['TEMP']=env['TMP']=str(out)
cmd=[str(cuda/'bin/nvcc.exe'),'-std=c++17','-O3','-arch=sm_120','--ptxas-options=-v','-lineinfo','-ccbin',str(vc/'bin/Hostx64/x64'),'-Xcompiler=/MT,/O2,/EHsc','-DGGML_CUDA_NO_VMM','-DHS_NATIVE_EXECUTION_ENABLED=1','-I'+str(out),'-I'+str(core/'ggml/include'),'-I'+str(core/'ggml/src'),'-I'+str(core/'vendor'),'-I'+str(cs),str(src),'-o',str(out/'operator_probe.exe'),'psapi.lib','bcrypt.lib']
write(out/'COMMAND.json',dict(command=cmd,environment=env))
inputs={}
for tree in (cuda,msvc,core):
 for p in tree.rglob('*'):
  if p.is_file() and (tree!=core or p.suffix in ('.h','.hpp','.cuh','.cu')):inputs[str(p.resolve())]={'sha256':sha(p),'bytes':p.stat().st_size}
for p in [*out.glob('*'),Path(__file__),here/'CONTRACT.json']:
 if p.is_file():inputs[str(p.resolve())]={'sha256':sha(p),'bytes':p.stat().st_size}
write(out/'FREEZE.json',dict(inputs=inputs,C_identical_to_e04=True,mmvq_original_sha256=sha(cs/'mmvq.cu'),execution_enabled=True))
spec=importlib.util.spec_from_file_location('closure',runtime/'input_closure_v2.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);held=module.ReadFreeze()
try:
 for p,v in inputs.items():
  held.add(p)
  if sha(p)!=v['sha256']:raise RuntimeError('changed input')
 with (out/'build.log').open('xb') as f:cp=subprocess.run(cmd,cwd=out,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=600)
 changes=[p for p,v in inputs.items() if sha(p)!=v['sha256']]
 write(out/'BUILD.json',dict(returncode=cp.returncode,changes=changes,executable_sha256=sha(out/'operator_probe.exe') if (out/'operator_probe.exe').exists() else None,CUDA_calls=0,native_execution='NOT_RUN',freeze_sha256=sha(out/'FREEZE.json')))
 print((out/'BUILD.json').read_text(),flush=True)
finally:held.release()
