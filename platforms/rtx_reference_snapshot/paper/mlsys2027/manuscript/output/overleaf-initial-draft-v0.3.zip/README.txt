INITIAL DRAFT FROZEN FOR OVERLEAF COLLABORATION -- v0.3

Upload this ZIP as a new Overleaf project. Use pdfLaTeX and TeX Live 2025.
Select main.tex for the full manuscript (runtime proposal retained).
Select appendix.tex to compile the separate appendix, then restore main.tex.
Locally: latexmk -pdf main.tex; latexmk -pdf appendix.tex.

Hardware evidence is closed. The synthesis is retrospective; campaign primary
outcomes were frozen independently. Runtime design is proposed and unmeasured.
The title and abstract remain provisional. This is not a final submission.

Only dependency paths are relocated. Figure PDF bytes, the inventory table,
official style, scientific values, bibliography, and manuscript prose are kept.
This source bundle is for author collaboration, not an anonymous artifact release.
No shared Overleaf project or collaborator invitation is created by packaging.
