"""Same392-call timing protocol; reuse the unspent charged416,never refund it."""
from pathlib import Path
import json,hashlib,os
p=Path(__file__).resolve().parent;sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
def write(q,v):
 with q.open('x',encoding='utf8',newline='\n') as f:json.dump(v,f,indent=2)
smoke=p/'CPU_SMOKE_PASS_V4.json';assert json.loads(smoke.read_bytes())['pass']
plan=json.loads((p/'TIMING_PLAN_001.json').read_bytes());stage=Path(json.loads((p/'STAGING_V3.json').read_bytes())['stage'])
old_job=Path(plan['argv'][1]);job=json.loads(old_job.read_bytes());profile=Path(json.loads((p/'STAGING_V3.json').read_bytes())['profile']);out=profile/'Temp/e11-timing-002'
job['output_dir']=str(out);jobpath=stage/'timing-job-002.json';write(jobpath,job)
plan.update(receipt_dir='D:/HeteroSpec-PC/rtx223-e11-u-contract/timing-002',output_dir=str(out),argv=[plan['argv'][0],str(jobpath)])
mapping={str(p/'runner_v3.py'):p/'runner_v4.py',str(p/'observation.py'):p/'observation_v2.py',str(p/'CPU_SMOKE_PASS.json'):smoke,str(old_job):jobpath}
for row in plan['controller_inputs']:
 if row['path'] in mapping:row.update(path=str(mapping[row['path']]),sha256=sha(mapping[row['path']]))
plan['controller_inputs'] += [dict(path=str(p/x),sha256=sha(p/x)) for x in ['CONTINUATION_CPU_TESTS.json','CONTINUATION_POLICY.json','continuation_proof.py']]
planpath=p/'TIMING_PLAN_002.json';write(planpath,plan)
entry=p/'execute_timing_002.py';source="from pathlib import Path\nimport json,hashlib,sys,runpy\np=Path(__file__).resolve().parent\nplan=p/'TIMING_PLAN_002.json'\nassert hashlib.sha256(plan.read_bytes()).hexdigest()=="+repr(sha(planpath))+"\nfor row in json.loads(plan.read_bytes())['controller_inputs']:\n assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256']\nsys.argv=[str(p/'runner_v4.py'),str(plan)]\nrunpy.run_path(str(p/'runner_v4.py'),run_name='__main__')\n"
with entry.open('x',encoding='utf8',newline='\n') as f:f.write(source)
q=p/'admin-queue-continuation/006-timing-continuation.pending';write(q,dict(script=str(entry),sha256=sha(entry),reservation=0,kind='NUMERICAL_CONTINUATION',reservation_ref='003-timing.json',explicit_limit=392));os.rename(q,q.with_suffix('.json'))
print(json.dumps(dict(existing_reservation=416,new_reservation=0,native_limit=392,protocol_unchanged='12pairs*5reps perboundary')))
