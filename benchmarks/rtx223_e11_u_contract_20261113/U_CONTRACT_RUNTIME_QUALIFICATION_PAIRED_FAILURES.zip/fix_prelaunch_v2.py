"""Retain v1 failure; use nonthrowing C ABI returns in a separately frozen build."""
from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'main_body.inc').read_text()
a=s.index('extern "C" void e11_reserve(');b=s.index('static void quantize(',a)
callback='''static const char* refusal_reason=nullptr;
extern "C" bool e11_reserve(unsigned n,const char*label) noexcept {
    if(!n||used>limit||n>limit-used){refusal_reason="explicit budget refused before dispatch";return false;}
    if(GetTickCount64()>=deadline){refusal_reason="prelaunch deadline reached";return false;}
    const char* names[]={"B_quantizer","B_projection","U_quantizer","U_projection"};int id=-1;
    for(int i=0;i<4;++i)if(strcmp(names[i],label)==0)id=i;
    if(id<0||n!=1){refusal_reason="unknown dispatch accounting";return false;}
    used+=n;operations[id]+=n;return true;
}
'''
s=s[:a]+callback+s[b:]
s=s.replace('extern "C" void e10_u_quantize','extern "C" cudaError_t e11_u_quantize').replace('extern "C" void e10_u_project','extern "C" cudaError_t e11_u_project')
s=s.replace('if(arm==1)e10_u_quantize(x,q,stream);','if(arm==1)check(e11_u_quantize(x,q,stream));').replace('if(arm==1)e10_u_project(w,q,y,stream);','if(arm==1)check(e11_u_project(w,q,y,stream));')
s=s.replace('e11_reserve(1,"B_quantizer");','need(e11_reserve(1,"B_quantizer"),refusal_reason?refusal_reason:"budget");').replace('e11_reserve(1,"B_projection");','need(e11_reserve(1,"B_projection"),refusal_reason?refusal_reason:"budget");')
s=s.replace('result["explicit_by_operation"]=', 'if(refusal_reason)result["prelaunch_refusal"]=refusal_reason;result["explicit_by_operation"]=')
with (p/'main_body_v2.inc').open('x',encoding='utf8',newline='\n') as f:f.write(s)
s=(p/'upstream_wrap.cu').read_text().replace('extern "C" void e11_reserve(unsigned,const char*);','extern "C" bool e11_reserve(unsigned,const char*) noexcept;')
s=s.replace('extern "C" void e10_u_quantize','extern "C" cudaError_t e11_u_quantize').replace('extern "C" void e10_u_project','extern "C" cudaError_t e11_u_project')
s=s.replace(' e11_reserve(1,"U_quantizer");',' if(!e11_reserve(1,"U_quantizer"))return cudaErrorInvalidValue;').replace(' e11_reserve(1,"U_projection");',' if(!e11_reserve(1,"U_projection"))return cudaErrorInvalidValue;')
s=s.replace('4096,4096,32768,32768,8,1);\n}', '4096,4096,32768,32768,8,1);\n return cudaGetLastError();\n}')
s=s.replace('32768,true);\n}', '32768,true);\n return cudaGetLastError();\n}')
with (p/'upstream_wrap_v2.cu').open('x',encoding='utf8',newline='\n') as f:f.write(s)
s=(p/'build_diagnostic.py').read_text().replace("out=here/'build-001'","out=here/'build-002'").replace('main_body.inc','main_body_v2.inc').replace("here/'upstream_wrap.cu'","here/'upstream_wrap_v2.cu'")
with (p/'build_diagnostic_v2.py').open('x',encoding='utf8',newline='\n') as f:f.write(s)
