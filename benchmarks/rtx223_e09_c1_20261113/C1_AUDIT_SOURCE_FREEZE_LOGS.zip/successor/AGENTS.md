# RTX223 e09 C1 successor

Parent PR230 head ba019f30522352c87cac2cc527082ecc6c73ed97 is immutable input.
The current user authorizes one targeted C1, at most415 explicit application
kernel reservations in a new ledger, <=120 seconds per owned GPU process.
The earlier e08 08:00 cutoff applied to that completed task; this successor has
its own current window. No model load, decode, service, round two or old edits.
Do not change security settings/ACLs. Use the approved zero-capability package
and inherited staging permissions, verify current effective access first.
No ordinary numerical image execution during CPU-only checks. Freeze inputs
before compilation; repairs get new versions. Never reset/refund old ledgers.
Keep failures and all paired samples. No merge or paper/baseline edits.
