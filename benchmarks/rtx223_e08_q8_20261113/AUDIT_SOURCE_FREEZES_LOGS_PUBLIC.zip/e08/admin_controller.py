"""Ephemeral administrator controller for the explicitly authorized overnight task.
Only fixed interpreter, hash-bound scripts within this successor, at most 3
bootstrap attempts (canonical family ledger) and 567 reserved app launches.
No scheduled task, service, account, ACL or UAC-policy installation.
"""
import ctypes as C,sys,os,json,hashlib,time,datetime as dt,importlib.util,subprocess,winreg
from pathlib import Path
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'attempt-002'))
import runner as r
w=r.win
python=(root/'python311/python.exe').resolve()
if Path(sys.executable).resolve()!=python:raise RuntimeError('wrong broker interpreter')
end=dt.datetime.fromisoformat('2026-11-13T08:00:00+08:00').timestamp()
queue=root/'admin-queue';queue.mkdir(exist_ok=True)
journal=(root/'ADMIN_EVENTS.jsonl').open('xb',buffering=0)
def event(**v):
 raw=(json.dumps(dict(utc=w.utc(),**v))+'\n').encode()
 if journal.write(raw)!=len(raw):raise RuntimeError('broker log short write')
 os.fsync(journal.fileno())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def restore():
 try:
  backup=json.loads((root/'WINDHAWK_EXCLUDE_BEFORE.json').read_bytes())
  with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,r'SOFTWARE\Windhawk\Engine\Settings',0,winreg.KEY_QUERY_VALUE|winreg.KEY_SET_VALUE) as key:
   value,kind=winreg.QueryValueEx(key,'Exclude')
   if value==backup['after']:
    winreg.SetValueEx(key,'Exclude',0,winreg.REG_SZ,backup['before'])
   elif value!=backup['before']:raise RuntimeError('concurrent Windhawk config change; do not overwrite')
  subprocess.run(['C:/Program Files/Windhawk/windhawk.exe','-app-settings-changed'],timeout=10,creationflags=0x08000000,check=True)
  event(kind='RESTORED_WINDHAWK')
 except Exception as ex:event(kind='RESTORE_FAILED',error=str(ex))
event(kind='READY',runner_context=r.runner_context(),hard_end='2026-11-13T08:00:00+08:00')
seen=set();reserved=0
try:
 while time.time()<end and not (root/'ADMIN_STOP').exists():
  pending=sorted(p for p in queue.glob('*.json') if p.name not in seen)
  if not pending:time.sleep(.2);continue
  reqpath=pending[0];seen.add(reqpath.name)
  request=json.loads(reqpath.read_bytes())
  script=Path(request['script']).resolve(strict=True)
  if not script.is_relative_to(root) or script.suffix!='.py' or sha(script)!=request['sha256']:
   raise RuntimeError('unbound task script')
  kind=request['kind'];n=request['app_launch_reservation']
  if kind not in ('CPU_ONLY','BOOTSTRAP','NUMERICAL'):raise RuntimeError('unsupported phase')
  if type(n)is not int or n<0 or reserved+n>567 or (kind!='NUMERICAL' and n):
   raise RuntimeError('explicit kernel reservation rejected')
  if kind=='NUMERICAL' and request.get('producer_and_count_audit') is not True:
   raise RuntimeError('missing reviewed producer/counter audit')
  timeout=min(120 if kind=='NUMERICAL' else 100 if kind=='BOOTSTRAP' else 30,end-time.time())
  if timeout<(120 if kind=='NUMERICAL' else 90 if kind=='BOOTSTRAP' else 5):
   event(kind='WINDOW_REFUSAL',request=reqpath.name);continue
  reserved+=n
  event(kind='RESERVED_BEFORE_TASK',request=reqpath.name,phase=kind,app_launches=n,total=reserved,script=str(script),sha256=request['sha256'])
  job=w.AtomicJob()
  limits=w.EXTENDED_LIMIT()
  limits.BasicLimitInformation.LimitFlags=0x2000|0x100|0x8
  limits.BasicLimitInformation.ActiveProcessLimit=2
  limits.ProcessMemoryLimit=2*1024**3
  w.checked(w.SetJob(job.job,9,C.byref(limits),C.sizeof(limits)),'outer Job containment')
  output=bytearray();error=bytearray();status='UNKNOWN'
  start=time.monotonic()
  try:
   env={k:v for k,v in os.environ.items() if not k.startswith(('CUDA_','GGML_','HS_B_'))}
   job.create([python,'-I','-B','-S',script,*request.get('arguments',[])],root,env)
   job.resume()
   while job.exit_code() is None and time.monotonic()-start<timeout and time.time()<end:
    for name,dest in ((job.output,output),(job.error,error)):
     part=job.read(name)
     if part:dest.extend(part)
    if len(output)+len(error)>64*1024**2:raise RuntimeError('broker output budget')
    time.sleep(.02)
   if job.exit_code() is None:job.kill()
   w.Wait(job.process,1000)
   code=job.exit_code()
   for name,dest in ((job.output,output),(job.error,error)):
    part=job.read(name)
    if part:dest.extend(part)
   status='COMPLETE' if code==0 else 'FAILED'
   event(kind='TASK_EXIT',request=reqpath.name,status=status,exit_code=code,wall_s=time.monotonic()-start)
  except Exception as ex:
   job.kill();event(kind='TASK_ERROR',request=reqpath.name,error=str(ex))
  finally:
   job.close()
   (queue/(reqpath.stem+'.stdout.log')).write_bytes(output)
   (queue/(reqpath.stem+'.stderr.log')).write_bytes(error)
   with (queue/(reqpath.stem+'.result')).open('x',encoding='utf8') as f:json.dump(dict(status=status),f)
finally:
 restore();event(kind='STOPPED',total_reserved_explicit_launches=reserved);journal.close()
