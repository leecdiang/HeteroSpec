"""Read-only independent reconstruction of capability evidence; no Win32 imports."""
import argparse,hashlib,json,math,sys
from pathlib import Path
def need(v,m):
    if not v:raise ValueError(m)
def load(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rows(p):
    b=p.read_bytes();need(not b or b.endswith(b'\n'),'partial journal '+str(p));r=[json.loads(s) for s in b.splitlines()]
    need(all(x['seq']==i+1 for i,x in enumerate(r)),'journal sequence');need(all(x['at_ns']<=y['at_ns'] for x,y in zip(r,r[1:])),'journal clock');return r
def one(rs,event):
    found=[r for r in rs if r['event']==event];need(len(found)==1,'expected one '+event);return found[0]
def verify_case(folder):
    rs=rows(folder/'EVENTS.jsonl');b=one(rs,'CASE_BEGIN');end=one(rs,'CASE_CLOSED');cid=b['case'];nonce=b['nonce'];need(not any(r['event'] in ['REAL_FAILURE','CASE_ERROR','FORBIDDEN_MODULE'] for r in rs),'case raw error')
    creates=[r for r in rs if r['event']=='PROCESS_CREATE'];exits=[r for r in rs if r['event']=='PROCESS_EXIT'];need(len(creates)==len(exits)==(3 if cid=='C3' else 1),'actor count')
    bypid={r['pid']:r for r in creates};need(len(bypid)==len(creates),'duplicate actor PID');ex={r['pid']:r for r in exits};need(set(ex)==set(bypid),'exit identity set')
    lives=[]
    for c in creates:
        e=ex[c['pid']];need(c['created_filetime']==e['created_filetime'],'creation binding');life=(int(e['exit_filetime'])-int(c['created_filetime']))/1e7;need(life>=0 and abs(life-e['lifetime_seconds'])<1e-6,'OS lifetime');lives.append(life)
        closed=[r for r in rs if r['event']=='HANDLE_CLOSED' and r.get('handle_kind')=='retained_actor' and r.get('pid')==c['pid']];need(len(closed)==1 and closed[0]['at_ns']>=e['at_ns'],'retained handle close')
        need(c['at_ns']<=e['exit_observed_ns']<=e['at_ns'],'exit event ordering')
    root=next(r for r in creates if r['role']=='root');re=ex[root['pid']];ready=one(rs,'READY_OBSERVED');need(ready['nonce']==nonce and ready['pid']==root['pid'],'READY binding');need(ready['at_ns']-b['at_ns']<=(3 if cid=='C2' else 5)*1e9,'READY deadline')
    need(one(rs,'JOB_EMPTY')['active_pids']==[] and one(rs,'FINAL_JOB_COUNT')['active_pids']==[],'empty job evidence');one(rs,'STDIO_CLOSED')
    for kind in ['popen_root','case_job']:need(len([r for r in rs if r['event']=='HANDLE_CLOSED' and r.get('handle_kind')==kind])==1,'handle closure '+kind)
    if cid=='C1':
        complete=load(folder/'COMPLETE.json');need(complete['nonce']==nonce and complete['pid']==root['pid'] and complete['event']=='COMPLETE','normal completion');need(re['exit_code']==0 and re['at_ns']-b['at_ns']<=5e9,'normal OS exit/deadline')
    elif cid=='C2':
        t=one(rs,'TIMEOUT_CONTROL');kill=one(rs,'JOB_TERMINATE');need(t['actor_alive'] is True and t['ready_ns']==ready['at_ns'] and 2e9<=t['at_ns']-ready['at_ns']<=3e9,'timeout control');need(kill['reason']=='EXPECTED_TIMEOUT' and kill['at_ns']>=t['at_ns'],'timeout Job termination');need(re['exit_code']!=0 and re['at_ns']>=kill['at_ns'] and end['at_ns']-t['at_ns']<=5e9,'timeout exit/cleanup');need(not (folder/'LATE_WORK.json').exists(),'work after timeout')
    else:
        go=one(rs,'CRASH_GO_CONTROL');sent=one(rs,'CRASH_GO_SENT');need(go['all_alive'] is True and go['nonce']==nonce and sent['at_ns']>=go['at_ns'],'tree alive/control');need(re['exit_code']==7 and re['exit_observed_ns']>=sent['at_ns'],'root abnormal exit');kill=one(rs,'JOB_TERMINATE');need(kill['reason']=='EXPECTED_ABNORMAL_TREE' and kill['at_ns']>=re['at_ns'],'tree terminate after root exit')
        child=bypid[go['child_pid']];grand=bypid[go['grandchild_pid']];need(child['parent_pid']==root['pid'] and grand['parent_pid']==child['pid'],'actual tree parent links')
        for name,c in [('child',child),('grandchild',grand)]:
            d=load(folder/(name+'.ready.json'));need(d['nonce']==nonce and d['pid']==c['pid'],'descendant READY');need(c['at_ns']<=go['at_ns'],'registration before control');need(ex[c['pid']]['exit_code']!=0 and int(ex[c['pid']]['exit_filetime'])>=int(re['exit_filetime']),'descendant actual exit');need(ex[c['pid']]['at_ns']-re['at_ns']<=5e9,'descendant cleanup deadline')
    need(end['status']=='PASS' and end['cleanup_confirmed'] and end['job_empty'],'derived/report mismatch');need(end['at_ns']-b['at_ns']<=(10 if cid!='C1' else 10)*1e9,'whole case deadline')
    result=load(folder/'RESULT.json');need(all(result[k]==end[k] for k in result),'case summary differs from journal');return dict(label=b['label'],case=cid,actors=len(creates),lifetime_seconds=sum(lives),begin_ns=b['at_ns'],end_ns=end['at_ns'])
def audit(root,run,manifest=None,tool_receipt=None):
    root=Path(root).resolve();run=(root/run).resolve();need(root in run.parents,'run path')
    if manifest:
        m=load(root/manifest);seen=set()
        for item in m['files']:
            p=item['path'];need(p not in seen and not Path(p).is_absolute() and '..' not in Path(p).parts,'manifest member');seen.add(p);f=root/p;need(f.is_file() and f.stat().st_size==item['bytes'] and sha(f)==item['sha256'],'manifest hash '+p)
    sr=rows(run/'SUPERVISOR.jsonl');wr=rows(run/'WATCHDOG.jsonl');summary=load(run/'SUMMARY.json');receipt=load(run/'WATCHDOG_RECEIPT.json')
    need(not any(r['event'] in ['SUPERVISOR_FAILURE'] for r in sr),'supervisor failure');need(not any(r['event'] in ['WATCHDOG_FAILURE','WATCHDOG_EXCEPTION','CLEANUP_ERROR'] for r in wr),'watchdog failure')
    sup=one(wr,'SUPERVISOR_CREATED_SUSPENDED');assigned=one(wr,'OUTER_JOB_ASSIGNED');resumed=one(wr,'SUPERVISOR_RESUMED');ex=one(wr,'SUPERVISOR_OS_EXIT');need(sup['at_ns']<=assigned['at_ns']<=resumed['at_ns']<ex['at_ns'],'suspended registration order');need(sup['created_filetime']==ex['created_filetime'] and ex['exit_code']==0 and int(ex['exit_filetime'])>int(ex['created_filetime']),'supervisor OS exit');need(one(wr,'OUTER_JOB_EMPTY')['active_pids']==[],'outer job not empty')
    for kind in ['supervisor_primary_thread','supervisor_process','outer_job']:need(len([r for r in wr if r['event']=='HANDLE_CLOSED' and r.get('handle_kind')==kind])==1,'outer owned handle '+kind)
    need(one(wr,'WATCHDOG_END')['receipt']==receipt and receipt['error'] is None and receipt['status']=='WATCHDOG_CLOSED','watchdog receipt reconciliation')
    results=[]
    for r in sr:
        if r['event']=='CASE_RESULT':
            result=verify_case(run/r['label']);need(result['label']==r['label'] and r['status']=='PASS','case linkage');results.append(result)
    actual_dirs={p.name for p in run.iterdir() if p.is_dir()};need(actual_dirs=={r['label'] for r in results},'unlisted/duplicate case directory')
    need([r['case'] for r in results[:3]]==['C1','C2','C3'],'Q order');need(len(results)*0+sum(r['actors'] for r in results)==summary['actor_starts'],'actor totals');need(abs(sum(r['lifetime_seconds'] for r in results)-summary['actor_lifetime_seconds'])<1e-5,'actor lifetime totals')
    sample_info={}
    for filename,start,end in [('SAMPLES.jsonl',one(sr,'SUPERVISOR_START')['at_ns'],one(sr,'SUPERVISOR_END')['at_ns']),('WATCHDOG_SAMPLES.jsonl',one(wr,'WATCHDOG_START')['at_ns'],one(wr,'WATCHDOG_END')['at_ns'])]:
        samples=rows(run/filename);need(samples and all(r['event']=='SAMPLE' for r in samples),'missing samples');gaps=[samples[0]['end_ns']-start,end-samples[-1]['end_ns']]+[y['end_ns']-x['end_ns'] for x,y in zip(samples,samples[1:])]+[r['end_ns']-r['begin_ns'] for r in samples];need(min(gaps)>=0 and max(gaps)<=5e9,'monitor gap');need(all(r['disk_free_bytes']>=10*1024**3 and r.get('storage_upper_bytes',0)<=1024**3 and r['total_observed_rss']<=1536*1024**2 for r in samples if r.get('storage_upper_bytes') is not None),'sample resource limit');sample_info[filename]=dict(samples=len(samples),maximum_effective_gap_ns=max(gaps))
    mode=summary['mode'];soak_seconds=None;cycles=0
    if mode=='measured':
        freeze=load(root/'CAPABILITY_FREEZE.json');need(all(sha(root/p)==h for p,h in freeze['files'].items()),'freeze drift');need(sha(freeze['python'])==freeze['python_sha256'],'Python drift')
        sb=one(sr,'SOAK_BEGIN');se=one(sr,'SOAK_END');soak_seconds=(se['at_ns']-sb['begin_ns'])/1e9;need(soak_seconds>=10800,'short soak');completed=[r for r in sr if r['event']=='CYCLE_COMPLETE'];cycles=len(completed);need(350<=cycles<=360,'cycle count');need(len(results)==3+3*cycles,'partial cycle')
        for i,c in enumerate(completed):
            trio=results[3+3*i:6+3*i];need(c['cycle']==i+1 and [r['case'] for r in trio]==['C1','C2','C3'],'cycle order');need([r['label'] for r in trio]==['S_%03d_%s'%(i,cid) for cid in ['C1','C2','C3']],'cycle identity');need(c['end_ns']-c['begin_ns']<=25e9,'cycle deadline');need(0<=c['begin_ns']-(sb['begin_ns']+i*30e9)<5e9,'cadence')
    if tool_receipt:need(load(root/tool_receipt)['exit_code']==0,'formal tool exit')
    return dict(status='CAPABILITY_ENDURANCE_PASS' if mode=='measured' and tool_receipt and manifest else 'DEVELOPMENT_EVIDENCE_PASS' if mode=='development' else 'CAPABILITY_3CHECK_PASS',source='raw journal, OS FILETIME, actual controls, known case files, manifest and tool receipt',cases=len(results),cycles=cycles,soak_seconds=soak_seconds,actor_starts=sum(r['actors'] for r in results),actor_lifetime_seconds=sum(r['lifetime_seconds'] for r in results),supervisor_os_lifetime_seconds=(int(ex['exit_filetime'])-int(sup['created_filetime']))/1e7,sampling=sample_info,manifest_checked=bool(manifest),tool_exit_checked=bool(tool_receipt),outer_gaps=['watchdog own OS exit','command shells','tool host','preflight and some development/review/delivery processes'])
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--run',required=True);p.add_argument('--manifest');p.add_argument('--tool-receipt');a=p.parse_args()
    try:print(json.dumps(audit(a.root,a.run,a.manifest,a.tool_receipt),sort_keys=True));sys.exit(0)
    except BaseException as e:print(json.dumps(dict(status='VERIFICATION_FAILED',error=repr(e))));raise
