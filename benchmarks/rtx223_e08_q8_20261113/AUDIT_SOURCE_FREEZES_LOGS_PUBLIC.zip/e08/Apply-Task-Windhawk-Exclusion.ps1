# Only the path-specific temporary exclusion approved for this experiment.
$ErrorActionPreference='Stop'
$root='C:\Users\ASUS\Documents\ChatGPT\HeteroSpec\rtx223-e08'
$key='HKLM:\SOFTWARE\Windhawk\Engine\Settings'
$backup=Join-Path $root 'WINDHAWK_EXCLUDE_BEFORE.json'
if(Test-Path $backup){throw 'Backup exists; do not apply again'}
$old=(Get-ItemProperty -LiteralPath $key -Name Exclude).Exclude
$rules=@('C:\Users\ASUS\Documents\ChatGPT\HeteroSpec\rtx223-e08\*','C:\Users\ASUS\Documents\ChatGPT\HeteroSpec\rtx223-e07\staging-B1\cpu-probe.exe','C:\Users\ASUS\Documents\ChatGPT\HeteroSpec\rtx223-e07\staging-B1\native-probe.exe')
$new=(@($old -split '\|' | Where-Object {$_})+$rules)-join '|'
@{key=$key;name='Exclude';kind='String';before=$old;after=$new;utc=[DateTimeOffset]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content -LiteralPath $backup -Encoding utf8
Set-ItemProperty -LiteralPath $key -Name Exclude -Type String -Value $new
if((Get-ItemProperty -LiteralPath $key -Name Exclude).Exclude -cne $new){throw 'Exclusion readback mismatch'}
Start-Sleep -Seconds 2
@{readback=$new;applied=$true}|ConvertTo-Json|Set-Content (Join-Path $root 'WINDHAWK_EXCLUDE_APPLIED.json') -Encoding utf8
