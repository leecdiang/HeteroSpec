import hashlib,json,sys,platform,os,subprocess
from pathlib import Path
B=Path(__file__).resolve().parents[1]
R=B/'repo'/'benchmarks'/'b570_zero_gpu_repair_v1'
(R/'host').mkdir(exist_ok=True);(R/'results').mkdir(exist_ok=True);(B/'sources').mkdir(exist_ok=True)
out=[]
for row in json.loads((B/'task/SOURCE_PAYLOAD.json').read_text(encoding='utf-8')):
    spec=row['spec']; data=row['content'].encode('utf-8')
    assert len(data)==spec['bytes'],spec
    assert hashlib.sha256(data).hexdigest()==spec['sha256'],spec
    assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==spec['git_blob'],spec
    path=B/'sources'/spec['path'];path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
    out.append({**spec,'local':str(path),'verified':True})
(R/'results'/'SOURCE_VERIFICATION.json').write_text(json.dumps(out,indent=2))
env=dict(platform=platform.platform(),windows=sys.getwindowsversion()[:],python=sys.executable,python_sha256=hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),pid=os.getpid(),task_root=str(B),checkout=str(R),legacy_source_read_only=True,GPU_queries=0,model_file_reads=0)
(R/'results'/'ENVIRONMENT.json').write_text(json.dumps(env,indent=2))
G='C:/hs/pr108-tools/git/cmd/git.exe'
subprocess.run([G,'config','core.autocrlf','false'],cwd=B/'repo',check=True)
paths=[p.relative_to(B/'repo').as_posix() for p in R.iterdir() if p.is_file()]
subprocess.run([G,'checkout-index','-f','--',*paths],cwd=B/'repo',check=True)
print(json.dumps({'verified':len(out),'environment':env,'paths':paths}))
