import ctypes as C, hashlib, json, os, sys, time
from pathlib import Path
root=Path(sys.argv[1]).resolve()
assert root.parent==Path('C:/hs/b570-capability-v1').resolve()
k=C.WinDLL('kernel32',use_last_error=True)
def directory(name):
    f=getattr(k,name);f.argtypes=[C.c_wchar_p,C.c_uint];f.restype=C.c_uint
    b=C.create_unicode_buffer(32768);n=f(b,len(b))
    if not 0<n<len(b):raise C.WinError(C.get_last_error())
    return b.value
record={'pid':os.getpid(),'sys_executable':sys.executable,'sys_version':sys.version,'os_name':os.name,'windows_directory':directory('GetWindowsDirectoryW'),'system_directory':directory('GetSystemDirectoryW'),'python_sha256':hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),'environment_presence':{n:n in os.environ for n in ['SystemRoot','SYSTEMROOT','WINDIR','COMSPEC','PATH','USERPROFILE','TEMP','TMP']},'monotonic_ns':time.perf_counter_ns(),'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'coverage':'This preflight PID has no independent OS creation/exit observation; tool exit separately retained.'}
with (root/'PREFLIGHT.json').open('x',encoding='utf-8') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps(record))
