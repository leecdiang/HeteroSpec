from pathlib import Path
import json,hashlib,runpy,sys
p=Path(__file__).resolve().parent
plan=p/'CPU_PLAN_004.json'
assert hashlib.sha256(plan.read_bytes()).hexdigest()=='b387f07cd9377ca5d838d2198b5b8605d95a13c057e0587d87ad3c908d75d47b'
for row in json.loads(plan.read_bytes())['controller_inputs']:
 assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256']
profile=json.loads((p/'PROFILE_CREATED.json').read_bytes())
assert profile['create_hresult']==0 and profile['capabilities']==0 and Path(profile['profile']).exists()
sys.argv=[str(p/'runner_v4.py'),str(plan)]
runpy.run_path(str(p/'runner_v4.py'),run_name='__main__')
