"""Read-only PID diagnosis in the same administrator identity; no CUDA/numerics."""
from pathlib import Path
import importlib.util,json,hashlib,ctypes as C,os,time,datetime
from ctypes import wintypes as W
p=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('ob',p/'observation.py');ob=importlib.util.module_from_spec(sp);sp.loader.exec_module(ob)
row=json.loads((p/'DEPLOYMENT.json').read_bytes())['modules']['nvml.dll'];assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256']
k=C.WinDLL('kernel32',use_last_error=True)
k.OpenProcess.argtypes=[W.DWORD,W.BOOL,W.DWORD];k.OpenProcess.restype=W.HANDLE
k.QueryFullProcessImageNameW.argtypes=[W.HANDLE,W.DWORD,W.LPWSTR,C.POINTER(W.DWORD)];k.QueryFullProcessImageNameW.restype=W.BOOL
k.CloseHandle.argtypes=[W.HANDLE];k.CloseHandle.restype=W.BOOL
k.GetProcessTimes.argtypes=[W.HANDLE,*([C.POINTER(W.FILETIME)]*4)];k.GetProcessTimes.restype=W.BOOL
def identity(pid):
 h=k.OpenProcess(0x1000,False,pid)
 if not h:return dict(pid=pid,error=C.get_last_error())
 try:
  buffer=C.create_unicode_buffer(32768);length=W.DWORD(len(buffer));ok=k.QueryFullProcessImageNameW(h,0,buffer,C.byref(length));times=[W.FILETIME() for _ in range(4)];timed=k.GetProcessTimes(h,*[C.byref(x) for x in times]);a=times[0]
  return dict(pid=pid,image=buffer.value if ok else None,creation_filetime=(a.dwHighDateTime<<32)|a.dwLowDateTime if timed else None)
 finally:k.CloseHandle(h)
m=ob.Management(row['path']);records=[]
try:
 m.start()
 for i in range(24):
  data=m.sample(p);records.append(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),used=data[2],free=data[1],temperature_c=m.temperature,pids=data[4],identities=[identity(pid) for pid in data[4]]));time.sleep(.25)
finally:m.close()
report=dict(read_only=True,administrator=bool(C.windll.shell32.IsUserAnAdmin()),management_pid=os.getpid(),nvml_sha256=row['sha256'],samples=records,CUDA_runtime_calls=0,numerical_DLL_loads=0,admission_guard_changes=0,old_failure_pid='NOT_RECORDED;cannot retrospectively identify from these new samples')
with (p/'ADMIN_NVML_DIAG_001.json').open('x',encoding='utf8') as f:json.dump(report,f,indent=2)
print(json.dumps(report))
