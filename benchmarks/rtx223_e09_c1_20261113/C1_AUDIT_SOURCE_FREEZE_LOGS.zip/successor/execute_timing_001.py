from pathlib import Path
import hashlib,json,sys,runpy
p=Path(__file__).resolve().parent
plan=p/"TIMING_PLAN_001.json"
assert hashlib.sha256(plan.read_bytes()).hexdigest()=="0b43f07c76e367b060e9e166de7b44197934b39a1bf3285eac9a2b03e6bbb461"
for row in json.loads(plan.read_bytes())["controller_inputs"]:
 assert hashlib.sha256(Path(row["path"]).read_bytes()).hexdigest()==row["sha256"]
sys.argv=[str(p/"runner.py"),str(plan)]
runpy.run_path(str(p/"runner.py"),run_name="__main__")
