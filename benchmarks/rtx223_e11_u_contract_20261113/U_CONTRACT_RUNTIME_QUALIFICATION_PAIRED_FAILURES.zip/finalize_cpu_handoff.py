"""Read-only checks and immutable zero-GPU handoff snapshot."""
from pathlib import Path
import json,hashlib,datetime,subprocess,re
p=Path(__file__).resolve().parent
sha=lambda q:hashlib.file_digest(Path(q).open('rb'),'sha256').hexdigest()
parent=json.loads((p/'PARENTS_VERIFIED.json').read_bytes())
for row in parent['files']:assert sha(row['path'])==row['sha256'],row['path']
frozen=json.loads((p/'build-003/FREEZE.json').read_bytes())['inputs']
for path,row in frozen.items():assert sha(path)==row['sha256'],path
source=json.loads((p/'PARENT_REUSE_VERIFIED.json').read_bytes())
assert sha(source['model']['path'])==source['model']['sha256']
stage=json.loads((p/'STAGING_V3.json').read_bytes())
for row in stage['files']:
 q=Path(row['path']);assert sha(q)==row['sha256'] and q.stat().st_ino==row['file_id']['inode'] and q.stat().st_dev==row['file_id']['volume']
assert not (p/'ADMIN_LAUNCH.json').exists() and not Path('D:/HeteroSpec-PC/rtx223-e11-u-contract/family.jsonl').exists()
assert not Path(stage['profile']).exists() and not list((p/'admin-queue').glob('*.json')) and (p/'ADMIN_STOP').exists()
full=json.loads((p/'FULL_BACKEND_BUILD_IDENTITY_V3.json').read_bytes());assert sha(full['path'])==full['sha256']
for row in json.loads((p/'UPSTREAM_BLOBS_VERIFIED.json').read_bytes())['files']:assert sha(p/'u'/row['path'])==row['sha256']
modules=p/'tools/cmake-3.31.8-windows-x86_64/share/cmake-3.31/Modules'
assert 'if(CMAKE_CUDA_COMPILER_FORCED)' in (modules/'CMakeTestCUDACompiler.cmake').read_text()
assert not list((p/'full-backend-002/build').rglob('CMakeDetermineCompilerABI_CUDA.bin'))
record=dict(pass_=True,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),parent_file_records_checked=len(parent['files']),native_build_inputs_checked=len(frozen),new_native_exe_sha256=sha(p/'build-003/operator-upstream.exe'),full_backend_DLL_sha256=full['sha256'],upstream10_blobs_match=True,all_staging_bytes_and_file_ids_match=True,model_raw_file_identity_rechecked=True,old_e10_still_FAIL=True,runtime_family_ledger_exists=False,CPU_request_parked=True,profile_not_created=True,queued_JSON_requests=0,ADMIN_STOP_present=True,CUDA_ABI_binary_absent=True,experimental_model_loads=0,experimental_CUDA_initializations=0,experimental_contexts=0,explicit_app_kernel_permits=0,physical_all_host_launches=None)
with (p/'FINAL_IDENTITIES.json').open('x',encoding='utf8') as f:json.dump(record,f,indent=2)
for name,argv in [('gpu',['nvidia-smi','--query-gpu=uuid,name,driver_version,memory.used,memory.free,temperature.gpu,utilization.gpu','--format=csv,noheader']),('compute',['nvidia-smi','--query-compute-apps=pid,process_name,used_memory','--format=csv,noheader'])]:
 cp=subprocess.run(argv,capture_output=True,text=True,timeout=10,creationflags=0x08000000)
 with (p/('FINAL_'+name.upper()+'_OBSERVATION.json')).open('x',encoding='utf8') as f:json.dump(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),read_only_management=True,argv=argv,returncode=cp.returncode,stdout=cp.stdout,stderr=cp.stderr,limitations='point-in-time driver observation,not CUDA context or physical launch census'),f,indent=2)
resources={}
for unit in ['main','upstream_wrap']:
 text=(p/'build-003'/(unit+'.log')).read_text(errors='replace')
 chunks=re.split(r"ptxas info\s*:\s*Compiling entry function ",text)[1:]
 rows=[]
 for chunk in chunks:
  used=re.search(r'Used (\d+) registers',chunk);stack=re.search(r'(\d+) bytes stack frame, (\d+) bytes spill stores, (\d+) bytes spill loads',chunk)
  if used:rows.append(dict(symbol=chunk.splitlines()[0],registers=int(used.group(1)),stack_spill_bytes=list(map(int,stack.groups())) if stack else None))
 resources[unit]=rows
with (p/'COMPILER_RESOURCES.json').open('x',encoding='utf8') as f:json.dump(dict(build='003',resources=resources,U_dynamic_shared_bytes=69632,B_static_shared_bytes=3072,actual_occupancy='NOT_MEASURED',DRAM_L2='NOT_MEASURED',new_runtime_resource_query='NOT_RUN'),f,indent=2)
print(json.dumps(record))
