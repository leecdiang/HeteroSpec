# Integrated anonymous evidence — v0.11.0

Run `python -B verify_v011.py` with Python 3 and NumPy (used by the inherited historical bootstrap). No network, credentials, GPU, model weights or runtime binaries are required.

The byte-preserved v0.10.0 package checks 1,005 original intervention arrays, 144 untruncated B570 exports, and its nested historical arithmetic. The selection snapshot separately contains 1,005 overlapping/recomposed records: 285 RTX19 (171 fresh bridge, 57 historical reference, 57 historical H1), 360 B570 and 360 MBPP. These denominators must not be added.

The new wrapper verifies hashes, runs the original compact-data audit, paid-query replay and ten integrity tests in a temporary copy, checks exact output identities, and independently recomputes the new figure groups and complete-output/stop-boundary comparisons. It validates retained exports, not omitted assets, fresh physical execution, full raw archives, or trusted absolute chronology. Original CPU scripts remain byte-identical and retain opaque source identities; the author provenance ledger is separate.

Run outputs are record-equivalent accounting, never latency, independent-task counts or new inference. Unknown counterfactuals remain unknown. Two-candidate negative feasibility does not imply universal impossibility.
