from pathlib import Path
import hashlib,runpy,sys,json
p=Path(__file__).resolve().parent
plan=p/"TIMING_PLAN_001.json"
assert hashlib.sha256(plan.read_bytes()).hexdigest()=="fc9c99b4223fac4cfcf1fd79276832c3b973301005d8d6e812135551397c5e36"
for row in json.loads(plan.read_bytes())["controller_inputs"]:
 assert hashlib.sha256(Path(row["path"]).read_bytes()).hexdigest()==row["sha256"]
sys.argv=[str(p/"runner-v6.py"),str(plan)]
runpy.run_path(str(p/"runner-v6.py"),run_name="__main__")
