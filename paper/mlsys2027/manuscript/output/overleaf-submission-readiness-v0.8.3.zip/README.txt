HeteroSpec v0.8.3 anonymous MLSys manuscript sources.
Use pdfLaTeX with TeX Live 2025. Build main.tex for the manuscript and appendix.tex for the separate supplement.
Embedded figure PDFs and frozen value macros are supplied; no experiment data or private provenance is included.
