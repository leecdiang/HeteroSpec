from pathlib import Path
import json,hashlib,runpy,sys
p=Path(__file__).resolve().parent
plan=p/'CPU_PLAN_006.json'
assert hashlib.sha256(plan.read_bytes()).hexdigest()=='e4c487d6aca15bb301a1c82b3e275f35958370d5aaa80cbc4d8fd22f2ed7df56'
for row in json.loads(plan.read_bytes())['controller_inputs']:
 assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256']
runpy.run_path(str(p/'create_profile_003.py'),run_name='__main__')
sys.argv=[str(p/'runner_v5.py'),str(plan)]
runpy.run_path(str(p/'runner_v5.py'),run_name='__main__')
