import sys,json,ctypes,time
from pathlib import Path
root=Path(sys.argv[1]).resolve();sys.path.insert(0,str(root/'src/rev2'));from win import *
rows=json.loads((root/'commands/009.review1-identities.json').read_text());out=[]
for r in rows:
    C.set_last_error(0);handle=open_process(0x100410,False,r['pid'])
    if not handle:
        error=C.get_last_error();need(error in (87,1168),'identity cleanup query failed '+str(error));out.append(dict(r,state='NO_SUCH_PID',query_error=error,original_exit_filetime=None));continue
    try:
        actual=os_times(handle)
        if actual['created_filetime']!=r['created_filetime']:out.append(dict(r,state='OLD_IDENTITY_GONE_PID_REUSED',current_created_filetime=actual['created_filetime'],original_exit_filetime=None))
        elif not alive(handle):out.append(dict(r,state='SIGNALED_EXIT',actual_os_times=actual,actual_exit_code=exit_code(handle)))
        else:out.append(dict(r,state='STILL_LIVE',actual_os_times=actual))
    finally:checked(close(handle),'query handle close')
result=dict(observed_ns=now(),identities=out,all_known_gone=all(r['state']!='STILL_LIVE' for r in out),historical_missing_os_exits_not_repaired=True,scope='Read-only actual identity query; not a replacement of original failed observation or proof about unobserved processes')
dump_new(root/'development/REVIEW1_CLEANUP_QUERY.json',result);print(json.dumps(result,sort_keys=True));sys.exit(0 if result['all_known_gone'] else 1)
