from pathlib import Path
import json,hashlib,runpy,sys
p=Path(__file__).resolve().parent
plan=p/"CPU_PLAN_001.json"
assert hashlib.sha256(plan.read_bytes()).hexdigest()=="15efad412f7b8364fa883e51218dafb1612d3ec2e6a87406680885589c10d09b"
for row in json.loads(plan.read_bytes())["controller_inputs"]:
 assert hashlib.sha256(Path(row["path"]).read_bytes()).hexdigest()==row["sha256"]
runpy.run_path(str(p/"create_profile.py"),run_name="__main__")
sys.argv=[str(p/"runner.py"),str(plan)]
runpy.run_path(str(p/"runner.py"),run_name="__main__")
