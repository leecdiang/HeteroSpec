"""CPU task-command observer. Own Job + DEBUG_PROCESS, never self-certifies own OS exit."""
import argparse,sys,os,json,time,hashlib,subprocess,traceback
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--id',required=True);p.add_argument('--seconds',type=float,required=True);p.add_argument('argv',nargs=argparse.REMAINDER);a=p.parse_args()
ROOT=Path(a.root).resolve();sys.path.insert(0,str(ROOT/'src/rev2'));from win import *
need(ROOT.parent==Path('C:/hs/b570-capability-v1').resolve(),'fresh root')
need(a.id.replace('-','').replace('_','').isalnum(),'id')
need(0<a.seconds<=900,'command deadline')
argv=a.argv[1:] if a.argv and a.argv[0]=='--' else a.argv;need(argv,'argv')
folder=ROOT/'processes'/a.id;folder.mkdir(parents=True,exist_ok=False);J=Journal(folder/'OS_EVENTS.jsonl');M=Journal(folder/'RESOURCES.jsonl')
job=make_job();proc=None;live={};observed={};closed={};root_seen=False;root_exited=False;failure=None;cutoff=now()+int(a.seconds*1e9);cleanup_at=None;last_sample=0
def launch():
    sa=SA(C.sizeof(SA),None,True);hs=[];pi=PI();made=False
    try:
        for path,access,disp in [('NUL',0x80000000,3),(str(folder/'stdout.log'),0x40000000,1),(str(folder/'stderr.log'),0x40000000,1)]:
            h=create_file(path,access,1,C.byref(sa),disp,128,None);need(h not in (None,C.c_void_p(-1).value),'capture file');hs.append(h)
        si=SI();si.cb=C.sizeof(si);si.flags=0x100;si.stdin,si.stdout,si.stderr=hs
        s=C.create_unicode_buffer(subprocess.list2cmdline(argv))
        checked(create_process(argv[0],s,None,None,True,0x0000000d,None,str(ROOT),C.byref(si),C.byref(pi)),'debug suspended create');made=True
        ident=identity(pi.process);J.emit('ROOT_CREATED_SUSPENDED',pid=int(pi.pid),argv=argv,**ident)
        checked(job_assign(job,pi.process),'command Job assignment');J.emit('JOB_ASSIGNED',pid=int(pi.pid))
        need(resume(pi.thread)!=0xffffffff,'resume');checked(close(pi.thread),'close initial thread');pi.thread=None;J.emit('ROOT_RESUMED',pid=int(pi.pid));return pi
    except BaseException:
        if made:
            terminate_process(pi.process,125);wait_handle(pi.process,5000)
            J.emit('UNRETURNED_ROOT_EXIT',pid=int(pi.pid),exit_code=exit_code(pi.process),**os_times(pi.process))
            if pi.thread:close(pi.thread)
            close(pi.process)
        raise
    finally:
        for h in hs:checked(close(h),'capture duplicate close')
try:
    observed_begin=now();J.emit('OBSERVER_START',pid=os.getpid(),argv=argv,seconds=a.seconds,observer_os_exit_filetime=None)
    proc=launch()
    while not root_seen or live:
        t=now()
        if cleanup_at is None and t>cutoff:failure='COMMAND_TIMEOUT';terminate_job(job);cleanup_at=t;J.emit('JOB_TERMINATE',reason=failure)
        if cleanup_at is not None and t-cleanup_at>5e9:raise RuntimeError('COMMAND_CLEANUP_UNCONFIRMED')
        if t-last_sample>=1e9:
            vals=[]
            for pid,h in live.items():
                if alive(h):vals.append(dict(pid=pid,created_filetime=os_times(h)['created_filetime'],rss_bytes=rss(h)))
            own=rss(current());need(own<=512*1024**2 and len(vals)<=8 and all(x['rss_bytes']<=256*1024**2 for x in vals) and sum(x['rss_bytes'] for x in vals)+own<=1536*1024**2,'command resource budget')
            M.emit('SAMPLE',begin_ns=t,end_ns=now(),members=vals,observer_rss=own)
            for n in ['stdout.log','stderr.log']:need((folder/n).stat().st_size<=16*1024**2,'command output cap')
            last_sample=now()
        ev=DE()
        if not wait_debug(C.byref(ev),20):
            need(C.get_last_error() in (0,121),'debug wait');continue
        code=0x00010002;exiting=None
        if ev.event==3:
            h=retain(ev.u.create.process);ident=identity(h);pid=int(ev.pid);need(pid not in observed,'duplicate PID');observed[pid]=ident;live[pid]=h;root_seen|=pid==proc.pid
            J.emit('PROCESS_CREATE',pid=pid,role='root' if pid==proc.pid else 'descendant',**ident)
            if ev.u.create.file:checked(close(ev.u.create.file),'debug image close')
        elif ev.event==6 and ev.u.dll.file:
            b=C.create_unicode_buffer(32768);n=query_path(ev.u.dll.file,b,len(b),0)
            if n and any(x in b.value.lower() for x in ['vulkan','nvcuda','cudart','ggml','igvk']):
                failure='FORBIDDEN_MODULE';terminate_job(job);cleanup_at=now();J.emit('FORBIDDEN_MODULE',pid=int(ev.pid),path=b.value)
            checked(close(ev.u.dll.file),'DLL debug file close')
        elif ev.event==5:
            pid=int(ev.pid);need(pid in live,'unknown process exit');exiting=live.pop(pid);J.emit('EXIT_OBSERVED',pid=pid,exit_code=int(ev.u.code))
        elif ev.event==1:
            if int(ev.u.code) not in (0x80000003,0x80000004):code=0x80010001;J.emit('EXCEPTION',pid=int(ev.pid),code=int(ev.u.code))
        checked(continue_debug(ev.pid,ev.tid,code),'continue command debug')
        if exiting:
            need(wait_handle(exiting,5000)==0,'actual exit signal');ts=os_times(exiting);pid=int(ev.pid)
            need(ts['created_filetime']==observed[pid]['created_filetime'] and int(ts['exit_filetime'])>0,'OS exit identity')
            row=J.emit('PROCESS_CLOSED',pid=pid,exit_code=int(ev.u.code),lifetime_seconds=(int(ts['exit_filetime'])-int(ts['created_filetime']))/1e7,**ts);closed[pid]=row
            checked(close(exiting),'retained process close');J.emit('HANDLE_CLOSED',pid=pid,handle_kind='retained_process')
            if pid==proc.pid:root_exited=True
    need(root_exited and not job_pids(job),'observed Job not empty');J.emit('JOB_EMPTY',active_pids=[])
    actual=exit_code(proc.process);need(wait_handle(proc.process,0)==0,'root actual exit');checked(close(proc.process),'root process close');proc.process=None;J.emit('HANDLE_CLOSED',handle_kind='root_process')
    checked(close(job),'command Job close');job=None;J.emit('HANDLE_CLOSED',handle_kind='command_job')
    receipt=dict(status='CLOSED' if failure is None else 'FAILED',root_exit_code=actual,error=failure,all_observed_closed=len(closed)==len(observed),observed=len(observed),closed=len(closed),lifetime_seconds=sum(x['lifetime_seconds'] for x in closed.values()),begin_ns=observed_begin,end_ns=now(),observer_pid=os.getpid(),observer_os_exit_filetime=None)
    dump_new(folder/'RECEIPT.json',receipt);J.emit('OBSERVER_END',receipt=receipt)
except BaseException as e:
    failure=repr(e)
    try:
        if job:terminate_job(job)
        J.emit('OBSERVER_FAILURE',error=failure,traceback=traceback.format_exc(),unclosed=list(live))
    finally:
        dump_new(folder/'INCOMPLETE.json',dict(error=failure,unclosed=list(live),cleanup_confirmed=False))
finally:
    if job:close(job)
    if proc and proc.process:close(proc.process)
    J.end();M.end()
print(json.dumps(dict(command=a.id,error=failure,root_exit_code=actual if 'actual' in globals() else None)),flush=True)
sys.exit(0 if failure is None and actual==0 else 1)
