from pathlib import Path
import json
r=Path(__file__).parent
old=Path("C:/hs/b570-qb-transaction-20261020160400")
s=(old/"RUN_ALL.ps1").read_text().replace(old.as_posix(),r.as_posix())
s=s.replace("PR128_COMMON_Q_TRANSACTION","PR128_MODEL_GEOMETRY_BRIDGE")
s=s.replace("27.8414773","53.7774511").replace("272.1585227","246.2225489")
s=s.replace("$session -lt 3","$session -lt 1").replace("-lt 70","-lt 140")
s=s.replace("transaction.exe","model_bridge.exe")
s=s.replace('$info.ArgumentList.Add([string]$session)', '''$modelPath='C:/Users/DIANG/Documents/ChatGPT/HeteroSpec/models/gguf/Qwen3-8B-Q8_0.gguf'
 $info.ArgumentList.Add($modelPath)
 $info.ArgumentList.Add((Join-Path $studyRoot 'INPUT.json'))''')
s=s.replace('argv=@($info.FileName,$dest,[string]$session)','argv=@($info.FileName,$dest,$modelPath,(Join-Path $studyRoot \'INPUT.json\'))')
s=s.replace("deadline_seconds=60","deadline_seconds=120").replace("WaitForExit(60000)","WaitForExit(120000)")
s=s.replace("EXPLORATORY_ALL_PASS","GEOMETRY_AND_OBSERVER_QUALIFIED").replace("THREE_SESSIONS_COMPLETED","ONE_MODEL_SESSION_COMPLETED")
(r/"RUN.ps1").write_text(s)
protocol={
 "study":"REAL_REQUEST_GEOMETRY_AND_OBSERVER_BRIDGE","frozen_before_gpu":True,
 "authorization":"User asked to directly pursue necessary follow-up and repair issues; model run is now necessary to bridge synthetic geometry to the existing paper workload. No actor, RTL, CPU8 or merge.",
 "hypothesis":"Determine real Qwen3-8B attention geometry and verify metadata-only observer preserves complete logits and greedy token IDs.",
 "model":"Existing Qwen3-8B Q8_0; bytes authenticated against historical ASSET_MANIFEST; no download",
 "input":"First previously exposed DEV_INPUTS entry HumanEval/42; all124 prompt IDs unchanged; fixed cap16, terminate on EOG",
 "runtime":"Same patched Vulkan DLL as PR128 cf6c8bf4; published pinned llama/base/cpu/ggml DLLs; no model graph rewrite.",
 "context":{"n_ctx":1024,"n_batch":512,"n_ubatch":1,"threads":8,"k_cache":"F16","v_cache":"F16","flash_attention":"disabled","offload_layers":999,"device":"B570 only for model offload"},
 "design":"One fresh native process; load one model, create three fresh contexts in CLEAN_A / METADATA_ONLY / CLEAN_B order.",
 "qualification":"All logits finite; full saved logits exact against CLEAN_A at every generated step; greedy IDs and output lengths match; observer asks present, callback always declines per-node evaluation, no completion callbacks; record actual KQ/KQV graph shapes and buffer devices.",
 "timing_limit":"Saved request/decode clocks are diagnostic and include capture or metadata overhead. No statistical speedup, attention-time fraction or hardware bottleneck claim.",
 "failure":"Stop current native attempt on first mismatch, error or cutoff. Preserve files and budget. No automatic GPU retry.",
 "budget":{"prior_charged_seconds":53.7774511,"total_seconds":300,"remaining_seconds":246.2225489,"internal_seconds":100,"parent_seconds":120,"admission_seconds":140,"charge":"all parent wall including model initialization, outputs and cleanup"},
 "decision":"Use real graph evidence to determine whether previous H8/Hkv8 and key1023-1025 micrograph conclusions transfer. Do not infer model qualification or optimization benefit from matching synthetic output.",
}
(r/"PREREGISTRATION.json").write_text(json.dumps(protocol,indent=2)+"\n")
print("Prepared one bounded native attempt; not launched.")
