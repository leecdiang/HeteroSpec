# Anonymous evidence index v0.8.7

Run `python3 -B verify.py` at this ZIP root. Standard library only, no models, GPU or network.
The five prior primary study projections, prior calculators and all derived input/result/CSV bytes are preserved. RTX V4 adds 285 A complete arrays and 171 B arrays/native timer intervals on 19 distinct prompts, preserving gate-before-cost interpretation and the original paired-prompt estimator.
This compact projection is made after known outcomes. It is not a prospective freeze, independent model reproduction, input-isolation proof, or authentication of original absolute time/omitted binaries. QPC and steady absolute counters are removed while native durations remain exact; author capsules retain full endpoints and logs. Content hashes may enable linkage and do not guarantee unlinkability.
INDEX.json separately identifies the unchanged full V2 H2 capsule and the V4 A/B anonymous parts indexes, hashes, lengths and CPU offline entry. Full capsules preserve tapes, raw logs, failure regressions and source. V3 terminal prefixes never enter V4's denominator; repetitions and A/B are not independent prompt cohorts.
