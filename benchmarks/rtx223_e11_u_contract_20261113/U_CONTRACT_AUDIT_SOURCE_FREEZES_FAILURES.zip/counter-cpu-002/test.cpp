#include <climits>
extern "C" bool e11_reserve(unsigned,const char*) noexcept;
extern "C" void reset_mock(unsigned,bool) noexcept;
extern "C" unsigned mock_used() noexcept;
extern "C" bool mock_dispatch() noexcept;
extern "C" unsigned mock_dispatch_count() noexcept;
int main(){
 reset_mock(500,false);for(int i=0;i<500;++i)if(!mock_dispatch())return 1;
 if(mock_dispatch()||mock_used()!=500||mock_dispatch_count()!=500)return 2;
 reset_mock(392,false);for(int i=0;i<392;++i)if(!mock_dispatch())return 3;
 if(mock_dispatch()||mock_used()!=392||mock_dispatch_count()!=892)return 4;
 reset_mock(14,true);if(mock_dispatch()||mock_used()!=0||mock_dispatch_count()!=892)return 5;
 reset_mock(14,false);if(e11_reserve(UINT_MAX,"B_quantizer")||mock_used()!=0)return 6;
 if(e11_reserve(0,"B_quantizer")||e11_reserve(1,"unknown")||mock_used()!=0)return 7;
 return 0;
}
