from common import *
p=R/'code/history_cohort.py'
shutil.copy2(p,R/'versions/history_cohort.preliminary.py')
for name in ['HISTORY_AUDIT_COMPLETE.json','HISTORY_CATALOG_COMPLETE.json']:
 shutil.copy2(R/name,R/'versions'/('PRELIMINARY_'+name))
s=p.read_text().replace("'dependencies'}","'dependencies','vocab'}")
s=s.replace("if name in mechanical or 'STATIC_QUERIES' in name:continue","if name in mechanical or 'STATIC_QUERIES' in name or ('tokenization' in name.lower() and 'stdout' in name.lower()):continue")
s=s.replace("'Binary source/runtime/archive files excluded from text matching; restored scientific input files audited.'","'Binary source/runtime/archive files excluded from text matching; restored scientific input files audited.','Prior corpus-wide zero-forward TOKENIZATION.stdout.jsonl is static corpus availability, not an executed or registered panel; actual schedules/records remain audited. Preliminary conservative audit overexcluded this static availability and selected no cohort.'")
p.write_text(s,encoding='utf8')
print('history scope correction only, no formal inputs selected and no scientific outputs used',flush=True)
