from pathlib import Path
import json,hashlib,subprocess,datetime
p=Path(__file__).resolve().parent;out=p/'capture-cpu-001';out.mkdir(exist_ok=False)
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
recipe=json.loads((p.parent/'rtx223-e10-fewrow/build-002/COMMANDS.json').read_bytes());env=recipe['environment'].copy();env['TEMP']=env['TMP']=str(out);cl=Path(env['PATH'].split(';')[0])/'cl.exe'
argv=[str(cl),'/nologo','/std:c++17','/O2','/EHsc','/MT','/fp:strict',str(p/'validate_capture_cpu.cpp'),'/Fe:'+str(out/'validate_capture_cpu.exe'),'/Fo:'+str(out/'validator.obj')]
(out/'INPUTS.json').write_text(json.dumps(dict(argv=argv,source_sha256=sha(p/'validate_capture_cpu.cpp'),header_sha256=sha(p/'u_oracle.hpp'),cl_sha256=sha(cl),CUDA_headers=False,CUDA_link=False),indent=2),encoding='utf8')
c=subprocess.run(argv,cwd=out,env=env,capture_output=True,timeout=30);(out/'compile.stdout.log').write_bytes(c.stdout);(out/'compile.stderr.log').write_bytes(c.stderr);assert c.returncode==0,c.stdout
old=p.parent/'rtx223-e08/numeric-v1/evidence/capture-003';prev=p.parent/'rtx223-e10-fewrow/evidence/profile/AC/Temp/e10-qualification-001'
args=[str(out/'validate_capture_cpu.exe'),str(old/'weight.bin'),str(old/'activation.f32'),str(prev/'U-r0-activation.bin'),str(prev/'U-r0-output.bin')]
c=subprocess.run(args,cwd=out,env=env,capture_output=True,timeout=30);(out/'e10-diagnostic.stdout.log').write_bytes(c.stdout);(out/'e10-diagnostic.stderr.log').write_bytes(c.stderr);assert c.returncode==0,c.stderr
result=json.loads(c.stdout);result.update(scope='CPU-only retrospective diagnostic under the NEW e11 set-valued contract;no alteration to e10 FAIL,no new GPU qualification',checker_sha256=sha(out/'validate_capture_cpu.exe'),argv=args,utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(out/'RESULT.json').write_text(json.dumps(result,indent=2),encoding='utf8');print(json.dumps(result))
