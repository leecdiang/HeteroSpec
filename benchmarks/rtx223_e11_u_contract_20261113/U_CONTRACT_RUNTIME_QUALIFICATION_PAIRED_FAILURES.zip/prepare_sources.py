"""Prepare distinct e11 sources and CPU tests; never executes numerical code."""
from pathlib import Path
import json,hashlib,subprocess,datetime
p=Path(__file__).resolve().parent;old=p.parent/'rtx223-e10-fewrow'
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
def write(q,v):
 with q.open('x',encoding='utf8') as f:json.dump(v,f,indent=2)
contract=dict(schema='heterospec.e11.A_B_C_contracts.v1',parent='01a4cf847bfc8340321564c66132680d4131bf0d',upstream_commit='0fb8f157702702f33f4e018de8701b2569a1bc28',device_uuid='GPU-6dd57db3-9aac-ccc8-bd69-225a5ea2c4dd',window=['2026-11-13T10:50:00+08:00','2026-11-13T14:30:00+08:00'],budget=dict(initial_qualification=14,one_diagnosed_qualification_repair=14,timing=416,margin=56,total=500,qualification_actual_max=8,timing_actual_max=392,unused_reservations_never_refunded=True),contracts=dict(A='unchanged oldB complete rawQ8_1/output bitwise',B='new joint shared inverse finite set;RN inverse +/-2 ULP and reciprocal +/-1;full source-derived double quantized dot gamma64 bound;raw determinism2 replays',C='extracted-device resident operator diagnostic,PDL0-equivalent,graphsOFF;not full default upstream backend or service'),oracle=dict(header_sha256=sha(p/'u_oracle.hpp'),cpu_test_source_sha256=sha(p/'oracle_cpu.cpp'),registration_sha256=sha(p/'NUMERICAL_CONTRACTS_ZH.md'),qualification_per_arm=2,e10='FAIL_PRESERVED_NO_RETROACTIVE_PASS'),timing=dict(blocks_per_boundary=12,alternating_order='BU,UB',repetitions_per_batch=5,warmups_per_arm=2,warmup_explicit=8,projection_explicit=144,complete_operator_explicit=240,total_explicit=392,post_batch='allrawquant_and_output_against_qualified_arm',data_selection='all48samples,noexclusion'),controls=dict(native_processes=1,outer_processes=2,process_commit_bytes=2147483648,output_bytes=33554432,per_explicit_prelaunch_deadline_seconds=109,native_job_seconds=119,outer_phase_seconds=120,ACL_security_changes=0),old4096='NOT_CLOSED',physical_lifecycle_launches=None,implicit_context_count=None,device_hang_cleanup_bound=None,model_and_capture=0,new_candidate_or_service=0)
write(p/'CONTRACT.json',contract)
s=(old/'main_body_v2.inc').read_text()
s='#include "u_oracle.hpp"\n#include <cfenv>\n'+s
s=s.replace('e10_reserve','e11_reserve').replace('heterospec-e10-fewrow-v1','heterospec-e11-ucontract-v1').replace('PASS_TWO_CONTRACT_DIAGNOSTIC','PASS_E11_TWO_CONTRACTS')
s=s.replace('static unsigned used=0,limit=0;','static unsigned used=0,limit=0,operations[4]={};')
s=s.replace('unsigned n,const char*)','unsigned n,const char*label)')
s=s.replace('used+=n;','used+=n;\n    const char* names[]={"B_quantizer","B_projection","U_quantizer","U_projection"};int id=-1;for(int i=0;i<4;++i)if(strcmp(names[i],label)==0)id=i;need(id>=0&&n==1,"unknown dispatch accounting");operations[id]+=n;')
s=s.replace('int wrong_q=0,wrong_scales=0,','int joint_fail=0,nonunique=0,min_witness=5,wrong_q=0,wrong_scales=0,')
s=s.replace('float amax=0;for(int k=0;k<32;++k)', 'float block_x[32];int block_q[32];float amax=0;for(int k=0;k<32;++k)')
s=s.replace('wrong_q+=got!=expected;', 'block_x[k]=getf(x,size_t(c*4096+b*32+k)*4);block_q[k]=got;wrong_q+=got!=expected;')
anchor='    }\n    const double u=std::ldexp(1.0,-24),gamma=64*u/(1-64*u);'
replacement='        auto check_block=e11_oracle::block(block_x,block_q,dy);joint_fail+=!check_block.pass;nonunique+=check_block.shared_inverse_witnesses>1;min_witness=std::min(min_witness,check_block.shared_inverse_witnesses);\n    }\n    const double u=std::ldexp(1.0,-24),gamma=64*u/(1-64*u);'
assert anchor in s;s=s.replace(anchor,replacement)
s=s.replace('bound_fail+=error>bound;', 'bound_fail+=!e11_oracle::output(value,sum,absolute);')
s=s.replace('{"U_CPU_quant_wrong_values",wrong_q}', '{"U_CPU_RN_quant_different_values_diagnostic_only",wrong_q},{"U_joint_quant_block_fail",joint_fail},{"U_joint_quant_nonunique_witness_blocks",nonunique},{"U_joint_quant_min_witnesses",min_witness}')
s=s.replace('"U_CPU_scale_over8ULP"','"U_CPU_RN_scale_over8ULP_diagnostic_only"')
s=s.replace('!wrong_q&&!wrong_scales&&!bound_fail','!joint_fail&&!bound_fail')
s=s.replace('limit=phase=="qualification"?14:320;', 'need(std::fegetround()==FE_TONEAREST,"CPU oracle requires RN mode");limit=phase=="qualification"?14:392;')
s=s.replace('for(int i=0;i<4;++i){if(mode)', 'for(int i=0;i<5;++i){if(mode)')
s=s.replace('{"batch_repetitions",4}', '{"batch_repetitions",5}').replace('{"per_operator_ms",ms/4}', '{"per_operator_ms",ms/5}')
s=s.replace('result["explicit_prelaunch_charged"]=used;', 'result["explicit_by_operation"]={{"B_quantizer",operations[0]},{"B_projection",operations[1]},{"U_quantizer",operations[2]},{"U_projection",operations[3]}};result["explicit_prelaunch_charged"]=used;')
with (p/'main_body.inc').open('x',encoding='utf8',newline='\n') as f:f.write(s)
with (p/'upstream_wrap.cu').open('x',encoding='utf8',newline='\n') as f:f.write((old/'upstream_wrap.cu').read_text().replace('e10_reserve','e11_reserve'))
s=(old/'build_diagnostic_v2.py').read_text().replace("out=here/'build-002'","out=here/'build-001'").replace('main_body_v2.inc','main_body.inc').replace("here/'C1_PARENT_VERIFIED.json'","here/'PARENTS_VERIFIED.json'")
s=s.replace("(out/'upstream_wrap.cu').write_bytes", "(out/'u_oracle.hpp').write_bytes((here/'u_oracle.hpp').read_bytes())\n(out/'upstream_wrap.cu').write_bytes")
s=s.replace("base=cmd[:cmd.index('-I'+str(prior))];nvcc=base[0];", "base=cmd[:cmd.index('-I'+str(prior))];base.append('-Xcompiler=/fp:strict');nvcc=base[0];")
with (p/'build_diagnostic.py').open('x',encoding='utf8',newline='\n') as f:f.write(s)
# Pure CPU oracle executable: no CUDA headers, link or dynamic load.
out=p/'oracle-cpu-001';out.mkdir();recipe=json.loads((old/'build-002/COMMANDS.json').read_bytes());env=recipe['environment'].copy();env['TEMP']=env['TMP']=str(out)
cl=Path(env['PATH'].split(';')[0])/'cl.exe';argv=[str(cl),'/nologo','/std:c++17','/O2','/EHsc','/MT','/fp:strict',str(p/'oracle_cpu.cpp'),'/Fe:'+str(out/'oracle_cpu.exe'),'/Fo:'+str(out/'oracle_cpu.obj')]
write(out/'INPUTS.json',dict(cl_sha256=sha(cl),header_sha256=sha(p/'u_oracle.hpp'),source_sha256=sha(p/'oracle_cpu.cpp'),argv=argv,environment=env,CUDA_headers=False,CUDA_link=False))
c=subprocess.run(argv,cwd=out,env=env,capture_output=True,timeout=30);(out/'compile.stdout.log').write_bytes(c.stdout);(out/'compile.stderr.log').write_bytes(c.stderr)
if c.returncode:raise RuntimeError('CPU oracle compile failure')
c=subprocess.run([str(out/'oracle_cpu.exe')],cwd=out,env=env,capture_output=True,timeout=10);(out/'test.stdout.log').write_bytes(c.stdout);(out/'test.stderr.log').write_bytes(c.stderr)
write(out/'RESULT.json',dict(pass_=c.returncode==0,exit_code=c.returncode,stdout=c.stdout.decode(),exe_sha256=sha(out/'oracle_cpu.exe'),CUDA_initializations=0,CUDA_headers=False,CUDA_link=False,numerical_DLL_loads=0))
assert c.returncode==0,c.stdout
print(c.stdout.decode())
