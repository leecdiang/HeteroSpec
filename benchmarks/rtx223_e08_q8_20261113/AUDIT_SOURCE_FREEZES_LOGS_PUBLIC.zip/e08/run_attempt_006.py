"""Reserve at most three new bootstrap attempts. Never reopens e07's B1 allowance."""
import sys,json,os,msvcrt,importlib.util
from pathlib import Path
root=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('r',root/'attempt-006/runner.py')
r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
state=Path('D:/HeteroSpec-PC/rtx223-e08')
state.mkdir(exist_ok=True)
h=r.win.CreateFile(str(state/'bootstrap-family.jsonl'),0xC0000000,1,None,4,0x80000080,None)
r.win.checked(h and h!=r.win.INVALID_HANDLE,'exclusive overnight family ledger')
f=os.fdopen(msvcrt.open_osfhandle(h,os.O_RDWR|os.O_BINARY),'r+b',buffering=0)
def record(event):
 raw=(json.dumps(dict(utc=r.win.utc(),family='RTX223-E08-BOOTSTRAP-MAX3',**event))+'\n').encode()
 if f.write(raw)!=len(raw):raise RuntimeError('family ledger short write')
 os.fsync(f.fileno())
try:
 data=f.read()
 rows=[json.loads(x) for x in data.splitlines()]
 reservations=[x for x in rows if x.get('event')=='RESERVED']
 if len(reservations)>=6:raise RuntimeError('all three attempts consumed')
 if reservations:
  prior=reservations[-1]['attempt']
  if not any(x.get('event')=='CLOSED' and x.get('attempt')==prior and x.get('confirmed_end') is True for x in rows):
   raise RuntimeError('prior attempt has no confirmed terminal state')
 n=len(reservations)+1
 if n!=6:raise RuntimeError('this frozen entry is only for attempt 001; prepare reviewed successor for another')
 record(dict(event='LIMIT_AMENDMENT',before=3,after=6,authorization=json.loads((root/'BOOTSTRAP_LIMIT_AMENDMENT.json').read_bytes())))
 record(dict(event='RESERVED',attempt=n,max_attempts=6,old_B1_included=False))
 status='PRECHECK_FAILED';confirmed=False
 try:
  r.native(str(root/'APPROVAL_006.json'),sys.argv[1]);status='COMPLETE'
 except BaseException as exc:
  print(str(exc),flush=True);status='FAILED'
 finally:
  journal=r.STATE/'attempt.jsonl'
  if journal.exists():
   items=[json.loads(x)['event'] for x in journal.read_bytes().splitlines()]
   tail=items[-1]
   confirmed=tail.get('owned_process_exit_confirmed') is True and tail.get('kind') in ('FAILED','COMPLETE')
  else:confirmed=True
  record(dict(event='CLOSED',attempt=n,status=status,confirmed_end=confirmed))
 if status!='COMPLETE':sys.exit(1)
finally:f.close()
