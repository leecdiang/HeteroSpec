from pathlib import Path
import hashlib,runpy,sys,json
p=Path(__file__).resolve().parent
plan=p/"CPU_PLAN_001.json"
assert hashlib.sha256(plan.read_bytes()).hexdigest()=="e52fe5c4d8c934cbbe9c6ebe3a844aea21e1141a8bea1ffa94c9a0743a412cd2"
for row in json.loads(plan.read_bytes())["controller_inputs"]:
 assert hashlib.sha256(Path(row["path"]).read_bytes()).hexdigest()==row["sha256"]
sys.argv=[str(p/"runner.py"),str(plan)]
runpy.run_path(str(p/"runner.py"),run_name="__main__")
