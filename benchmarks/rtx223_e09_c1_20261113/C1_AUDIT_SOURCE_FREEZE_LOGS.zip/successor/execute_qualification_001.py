from pathlib import Path
import hashlib,json,sys,runpy
p=Path(__file__).resolve().parent
plan=p/"QUALIFICATION_PLAN_001.json"
assert hashlib.sha256(plan.read_bytes()).hexdigest()=="5e573b9fb00f0f37ba008f83c84050e55167d40095b724b05ea6321464ff6975"
for row in json.loads(plan.read_bytes())["controller_inputs"]:
 assert hashlib.sha256(Path(row["path"]).read_bytes()).hexdigest()==row["sha256"]
sys.argv=[str(p/"runner.py"),str(plan)]
runpy.run_path(str(p/"runner.py"),run_name="__main__")
