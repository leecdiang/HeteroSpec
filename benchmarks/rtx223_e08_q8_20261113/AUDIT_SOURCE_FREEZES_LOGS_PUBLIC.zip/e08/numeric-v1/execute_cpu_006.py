from pathlib import Path
import hashlib,runpy,sys,json
p=Path(__file__).resolve().parent
plan=p/"CPU_PLAN_006.json"
assert hashlib.sha256(plan.read_bytes()).hexdigest()=="6a0609812b283a27a218267c0c150ad30a95d60a05bf5c2c59ad7daa873fcd42"
for row in json.loads(plan.read_bytes())["controller_inputs"]:
 assert hashlib.sha256(Path(row["path"]).read_bytes()).hexdigest()==row["sha256"]
sys.argv=[str(p/"runner-v6.py"),str(plan)]
runpy.run_path(str(p/"runner-v6.py"),run_name="__main__")
