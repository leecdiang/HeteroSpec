from pathlib import Path
import json,shutil
root=Path(__file__).parent
base=Path("C:/hs/b570-model-bridge-20261020162500")
for name in ["model_bridge.cpp","CMakeLists.txt","INPUT.json","MODEL_IDENTITY.json"]:
    shutil.copyfile(base/name,root/name)
(root/"build/Release").mkdir(parents=True,exist_ok=False)
for p in (base/"build/Release").iterdir():
    if p.suffix in [".exe",".dll"]:shutil.copyfile(p,root/"build/Release"/p.name)
protocol={
 "study":"BUILTIN_VULKAN_TIMESTAMP_OBSERVER_CALIBRATION","frozen_before_profile":True,
 "baseline":"C:/hs/b570-model-bridge-20261020162500/session-0",
 "adaptive_scope":"Clean baseline already observed. This is an exploratory observer calibration, not a blinded confirmatory performance study.",
 "native_identity":"Identical executable and runtime to successful model bridge; only whitelisted GGML_VK_PERF_LOGGER environment differs.",
 "design":"Existing CLEAN_A process, new PROFILE process, new CLEAN_B process. Each executes fresh-context clean/metadata-only/clean requests. Analyze third-context per-token decode times to avoid first-context compilation; use whole-request times only diagnostically because they contain raw I/O.",
 "profile_env":{"GGML_VK_PERF_LOGGER":"1","GGML_VK_PERF_LOGGER_FREQUENCY":"1000000","GGML_VK_PERF_LOGGER_CONCURRENT":"absent"},
 "qualification":"All48 complete logits must match original clean reference bytes across process; all greedy IDs identical; first mismatch stops next GPU process.",
 "calibration":"For third-context median of15 decode-completion times: clean A/B ratio must be within [0.90,1.10]; profile median must be within [0.90,1.10] of EACH clean median. Passing is only a necessary coarse observer check, not per-op perturbation calibration or proof of true critical-path share.",
 "attribution":"Parse forced final Vulkan timings separately for each context; aggregate F16 MUL_MAT_VEC attention geometries plus SOFT_MAX. Keep op-only GPU subtotal separate from host request time; no Amdahl extrapolation.",
 "failure":"Preserve failed process/qualification; no automatic GPU retry. Scientific calibration rejection is a result, not permission to retune the screen.",
 "budget":{"total_seconds":300,"prior_charged_seconds":75.347943,"remaining_seconds":224.652057,"parent_deadline_seconds":120,"minimum_remaining_admission":140,"charge":"full native parent wall, including initialization/capture/cleanup"},
 "excluded":["actor","RTL","CPU8","new model","PR merge"],
}
(root/"PREREGISTRATION.json").write_text(json.dumps(protocol,indent=2)+"\n")
s=(base/"RUN.ps1").read_text().replace(base.as_posix(),root.as_posix())
s=s.replace("53.9469028","75.347943").replace("246.0530972","224.652057")
s=s.replace("$session -lt 1","$session -lt 2")
s=s.replace("PR128_MODEL_GEOMETRY_BRIDGE","PR128_MODEL_PROFILE_CALIBRATION")
s=s.replace('$info.WorkingDirectory=$release', '''$info.WorkingDirectory=$release
 foreach($key in @('GGML_VK_PERF_LOGGER','GGML_VK_PERF_LOGGER_CONCURRENT','GGML_VK_PERF_LOGGER_FREQUENCY')){[void]$info.Environment.Remove($key)}
 if($session -eq 0){$info.Environment['GGML_VK_PERF_LOGGER']='1';$info.Environment['GGML_VK_PERF_LOGGER_FREQUENCY']='1000000'}''')
needle="if($allPassed){$ledger.status='ONE_MODEL_SESSION_COMPLETED';Save-Ledger}else{exit 1}"
s=s.replace(needle,"if($allPassed){$ledger.status='PROFILE_AND_CLEAN_COMPLETED';Save-Ledger}else{exit 1}")
needle=" if($native.status -ne 'GEOMETRY_AND_OBSERVER_QUALIFIED' -or -not $native.normal_cleanup_returned){$ledger.status='STOPPED_FIRST_NATIVE_FAILURE';Save-Ledger;$allPassed=$false;break}"
assert needle in s
s=s.replace(needle,needle+'''
 $referenceRoot='C:/hs/b570-model-bridge-20261020162500/session-0'
 $matches=$true
 foreach($file in Get-ChildItem -LiteralPath $dest -Filter '*.f32'){
  if((Get-FileHash -LiteralPath $file.FullName).Hash -ne (Get-FileHash -LiteralPath (Join-Path $referenceRoot $file.Name)).Hash){$matches=$false;break}
 }
 if(-not $matches){$ledger.status='STOPPED_CROSS_PROCESS_LOGITS_MISMATCH';Save-Ledger;$allPassed=$false;break}
''')
(root/"RUN.ps1").write_text(s)
print("Prepared calibration; no GPU started.")
