from pathlib import Path
import json,hashlib,zipfile,base64,shutil
r=Path(__file__).parent;p=Path(str(r).removesuffix("-r2"))
dest=Path("C:/Users/DIANG/Documents/ChatGPT/HeteroSpec/benchmarks/b570_draft_prefill_submission_v1")
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def archive(root):
    raw=[]
    for d in sorted(root.glob("qual-*")):
        if d.is_dir():
            for f in sorted(d.rglob("*.f32")):raw.append({"path":f.relative_to(root).as_posix(),"bytes":f.stat().st_size,"sha256":sha(f)})
    (root/"RAW_LOGITS_MANIFEST.json").write_text(json.dumps(raw,indent=2))
    with zipfile.ZipFile(root/"FULL_RAW_LOCAL.zip","w",zipfile.ZIP_DEFLATED)as z:
        for x in raw:z.write(root/x["path"],x["path"])
    with zipfile.ZipFile(root/"COMPACT_EVIDENCE.zip","w",zipfile.ZIP_DEFLATED)as z:
        for f in sorted(root.rglob("*")):
            rel=f.relative_to(root)
            if f.is_file()and "build"not in rel.parts and f.suffix in (".json",".log",".csv")and f.name not in ("GIT_PAYLOAD.json","PREREG_PAYLOAD.json","PACKAGE_MANIFEST.json","LOCAL_ARCHIVE.json"):
                z.write(f,rel.as_posix())
    (root/"LOCAL_ARCHIVE.json").write_text(json.dumps({"full_raw_path":str(root/"FULL_RAW_LOCAL.zip"),"bytes":(root/"FULL_RAW_LOCAL.zip").stat().st_size,"sha256":sha(root/"FULL_RAW_LOCAL.zip"),"raw_files":len(raw),"hosted_on_GitHub":False},indent=2))
for root,sub in ((p,dest),(r,dest/"attempt2")):
    archive(root);sub.mkdir(parents=True,exist_ok=True)
    for f in sorted(root.iterdir()):
        if f.is_file()and f.suffix in (".json",".md",".cpp",".inc",".py",".ps1",".txt",".patch",".csv",".svg",".png",".pdf")and f.name not in ("GIT_PAYLOAD.json","PREREG_PAYLOAD.json","PACKAGE_MANIFEST.json"):
            shutil.copy2(f,sub/f.name)
    shutil.copy2(root/"COMPACT_EVIDENCE.zip",sub/"COMPACT_EVIDENCE.zip")
manifest=[{"path":f.relative_to(dest).as_posix(),"bytes":f.stat().st_size,"sha256":sha(f)}for f in sorted(dest.rglob("*"))if f.is_file()and f.name!="PACKAGE_MANIFEST.json"]
(dest/"PACKAGE_MANIFEST.json").write_text(json.dumps(manifest,indent=2))
payload=[]
for f in sorted(dest.rglob("*")):
    if not f.is_file():continue
    b=f.read_bytes();binary=f.suffix in (".zip",".png",".pdf")
    payload.append({"path":"benchmarks/b570_draft_prefill_submission_v1/"+f.relative_to(dest).as_posix(),"encoding":"base64"if binary else"utf-8","content":base64.b64encode(b).decode()if binary else b.decode("utf-8-sig"),"bytes":len(b),"sha":hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()})
(r/"GIT_PAYLOAD.json").write_text(json.dumps(payload))
print(json.dumps({"files":len(payload),"payload_chars":len((r/"GIT_PAYLOAD.json").read_text()),"failed_raw":97,"qualified_raw":346}))
