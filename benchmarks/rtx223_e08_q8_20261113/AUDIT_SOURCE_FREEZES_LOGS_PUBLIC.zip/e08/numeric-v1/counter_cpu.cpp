#include "hs_launch_budget.hpp"
#include <windows.h>
#include <cstring>
int main(int argc,char**argv){
 if(argc!=3)return 20;SetEnvironmentVariableA("HS_E08_LAUNCH_LOG",argv[2]);
 if(std::strcmp(argv[1],"unarmed")==0)return hs_launch_budget_try_v1("CPU")<0?0:21;
 if(hs_launch_budget_configure_v1(567,0,3,"CPU_EXPLICIT_ONLY")!=1)return 22;
 if(std::strcmp(argv[1],"reset")==0)return hs_launch_budget_configure_v1(567,0,3,"RESET")<0?0:23;
 for(int i=0;i<3;i++)hs_launch_budget_before_launch_v1("CPU_NO_CUDA");
 if(std::strcmp(argv[1],"full")==0){hs_launch_budget_snapshot_v1_t s{};hs_launch_budget_snapshot_v1(&s);return s.admitted_attempts==3?0:24;}
 if(std::strcmp(argv[1],"overflow")==0)hs_launch_budget_before_launch_v1("CPU_MUST_STOP_BEFORE_FOURTH");
 return 25;
}
