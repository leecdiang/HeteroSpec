from pathlib import Path
import hashlib,sys,runpy
p=Path(__file__).resolve().parent
assert hashlib.sha256((p/'cleanup_profile.py').read_bytes()).hexdigest()=='d40a47f89a8698359dae715802b50978ab2e67d85480147c6b85fd6b4aa1a029'
sys.argv=[str(p/'cleanup_profile.py'),'apply-after-owned-processes-ended']
runpy.run_path(str(p/'cleanup_profile.py'),run_name='__main__')
