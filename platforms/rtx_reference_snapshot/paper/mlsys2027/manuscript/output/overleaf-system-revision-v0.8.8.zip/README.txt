GLOBAL SYSTEM REVISION -- v0.8.8
Build from the ZIP root with pdfLaTeX: latexmk -pdf main.tex
Separate appendix: latexmk -pdf appendix.tex
This self-contained source ZIP supports editing and PDF reconstruction.
The anonymous evidence index is a separate reviewer-facing artifact.
The internal hardware-only build is a section-removal/reference proof only.
No model, measurement hardware, network or external repository is needed.
Prediction equality, reference qualification, sampled immediate effects and
continuation effects retain distinct study identities. The new same-set RTX discriminator compares target-only UB2 and replay.
New serialized RTX
latency is qualified for its instrumented boundary and is slower than target.
Anonymous derived evidence cannot authenticate original remote freeze times
or omitted weights/runtime/compiler/driver bytes. No functional pass@k claim.
This revises the prior frozen manuscript in response to its completed reviews.
Prior review scores apply only to the prior artifact. No new model executions.
