from pathlib import Path
import json,hashlib,shutil,zipfile,base64,re,datetime
p=Path(__file__).resolve().parent;e=p/'evidence';d=p/'delivery';d.mkdir(exist_ok=False);w=d/'windows_20261113';w.mkdir();sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
for name in ['CMakeLists.txt','native_worker.cpp','native_reference.cpp']:shutil.copy2(p/name,d/name)
plan=(p/'original/PLAN.md').read_text(encoding='utf8');plan=plan.replace('Status: DESIGN ONLY — no GPU work, runtime qualification or performance result.','Status: EXECUTED on Windows. See windows_20261113/RESULT_REPORT_ZH.md and IMPLEMENTATION_PROTOCOL_ZH.md. The design/proposed-budget text below is preserved as the preregistration, not current authorization/status.')
plan+='\n\n## Execution closeout\nUser approved this campaign in the execution chat. Both panels completed:192formal,220totalrequests,51370actualrows,18deployments,1085.38seconds model window. Qualifier uses6deployments(total18) for independent native+two fresh adapter processes/reset. Original long bin was unfillable; predeclared deterministic fallback froze26..161-token formal prompts before inference. P ratio .678474 is full-model equal-work execution cost;G .676136 is separately reported with different trajectories. Large cross-contract vector differences remain;no quality/reference equivalence claim. See the complete report,source,rawrecords and scope limits in windows_20261113/. No new GPU work is queued.\n'
(d/'PLAN.md').write_text(plan,encoding='utf8')
(d/'RUNBOOK_ZH.md').write_text('''# #244本机执行已收尾

已按用户独立授权完成两臂资格、P128/G64正式请求。实际220请求、51370rows、18模型部署，GPU窗口约18.09分钟。完整报告见[windows_20261113/RESULT_REPORT_ZH.md](windows_20261113/RESULT_REPORT_ZH.md)。原设计/CPU-only runbook与全部9个原文件以PR939b0ee51的精确版本保留在审计包。

本机执行源快照、编译日志、失败、账本、所有正式request/输出、完整资格对比与图均在windows_20261113/。大体积全词表F32留在本机，公开RAW_F32_LOCAL_INDEX绑定16个原始文件；不包含模型/厂商DLL/全主机私人命令行。

不要重跑现场campaign入口：18次部署已耗尽，8次请求余额并不授权追加模型加载或重复面板。现场脚本是本机路径与旧资产绑定的实际快照，不是通用自动安装器。复现需映射原始R资产、固定M源码和模型，在新独立合同/授权下使用。不要用run_session.py新建空账绕开本累计ledger。

R薄port保留原完整libllama.a与所有原CUDA/CPU DLL，内部ubatch1/reserve1；M完整build固定0fb8f157、ubatch32、graph/PDL允许，FA关闭/F16KV/ctx1024/2threads共同包络，GGML_NATIVE=OFF已声明。不是全部factory defaults或最优现代配置。恢复步骤/计时边界见IMPLEMENTATION_PROTOCOL_ZH.md和构建脚本。

P约32.15%降时是不同数值合同的完整模型固定工作成本；G全部cap128且仅20/32跨臂token轨迹相同，不称质量非劣。R/M完整诊断差异很大，原始数值保留；未定位差异机制。正式输入仅26–161token，长输入性能未测。21CPU测试普通和-O通过，Windows真实编译链接及两臂原生资格通过；CPU mocks不是GPU正确性证据。

无待处理GPU队列或管理员控制器，已释放RTX锁。用户授权仅终止过绑定的OnDeviceModel utility PID29020，保护本对话主进程PID28000；无设置/ACL更改。旧实验额度、失败、数据不改，不合并、不改论文或投稿。
''',encoding='utf8')
(d/'HANDOFF_ZH.md').write_text('''# #244执行完成的交接

从windows_20261113/RESULT_REPORT_ZH.md、RESULT.json、P/G_ANALYSIS.json及RAW_RUN_AUDIT.zip读取最终结果。P/G都完成，220请求/51370rows/18部署；不因余下8个请求而追加模型加载。原始停止和旧账前缀保持；PR235FAIL/PR237算子记录不改。

本轮已停止GPU，无排队任务。源码快照包含现场绝对路径/旧资产依赖，禁止直接重跑旧helper或终止旧PID。正式输入很短，M/R数值差异明显，质量/长prompt/跨窗口结论未建立。报告与全部负信息供作者审阅；不自动开展后续优化、服务面板或投稿。
''',encoding='utf8')
for name in ['RESULT_REPORT_ZH.md','IMPLEMENTATION_PROTOCOL_ZH.md','campaign.py','campaign_continue.py','native_reference.cpp','build_legacy.py','build_modern.py','finish_modern.py','prepare_inputs.py','prepare_selected.py','analyze_outputs.py','plot_results.py','release_utility.py']:
 shutil.copy2(p/name,w/name)
for name in ['RESULT.json','P_ANALYSIS.json','G_ANALYSIS.json','ALL_PAIRED_SAMPLES.csv','P_G_SUMMARY.json','P_BLOCK_DIAGNOSTIC.json','G_BLOCK_DIAGNOSTIC.json','PHASE_MEANS.json','G_TRAJECTORY_DIFFERENCES.json','G_WITHIN_ARM_REPEAT.json','CROSS_ARM_FIXED_DIAGNOSTIC_ERRORS.json','NUMERICAL_DIFFERENCE_AUDIT.json','R-QUALIFICATION.json','M-QUALIFICATION.json','R-HISTORICAL_FIXTURE.json','PANEL_FROZEN.json','INPUT_COVERAGE_LIMIT.json','ROOT_EXPOSURE_CHECK.json','PRIOR_S3_ID_INDEX.json','RESOURCE_CONSUMPTION.json','FINAL_VERIFICATION.json','CLEANUP.json','ENGINEERING_NOTES.json','RAW_F32_LOCAL_INDEX.json','EXECUTION_MANIFEST_PRELOAD_002.json','UTILITY_RELEASE.json','COARSE_CLOCK_POWER.csv']:
 shutil.copy2(e/name,w/name)
shutil.copy2(e/'ledger.jsonl',w/'ledger.jsonl');(w/'figures').mkdir()
for q in (e/'figures').iterdir():shutil.copy2(q,w/'figures'/q.name)
notes=dict(normal=dict(command='python -I -B -S -m unittest discover -s rtx244-full-deployment -p test_*.py -v',tests=21,returncode=0),optimized=dict(command='python -O -I -B -S -m unittest discover -s rtx244-full-deployment -p test_*.py -v',tests=21,returncode=0),tests_source={n:sha(p/n) for n in ['experiment.py','run_session.py','test_experiment.py','test_runner.py']},scope='CPU parsing/scheduling/analysis/process fault checks only;native R/M qualification is separate')
(w/'CPU_TESTS.json').write_text(json.dumps(notes,indent=2),encoding='utf8')
sources=[];archive=w/'RAW_RUN_AUDIT.zip'
def add(z,q,name):
 raw=q.read_bytes()
 if re.search(rb'(?:sk-[A-Za-z0-9_-]{20,}|gh[pousr]_[A-Za-z0-9]{30,}|Bearer [A-Za-z0-9._-]{30,})',raw):raise RuntimeError('possible secret '+str(q))
 z.writestr(name,raw);sources.append(dict(path=name,bytes=len(raw),sha256=sha(q)))
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for q in p.glob('*'):
  if q.is_file() and '.private.' not in q.name and q.suffix in ['.py','.cpp','.md','.txt','.json']:add(z,q,'source/'+q.name)
 for q in (p/'original').iterdir():add(z,q,'original_PR939b0ee51/'+q.name)
 for q in sorted(e.rglob('*')):
  if q.is_file() and q.suffix in ['.json','.jsonl','.tsv','.csv','.log'] and '.private.' not in q.name:add(z,q,'evidence/'+q.relative_to(e).as_posix())
 for folder in ['build-R','build-R2','build-M']:
  for q in (p/folder).glob('*'):
   if q.is_file() and q.suffix in ['.json','.log','.cpp','.txt']:add(z,q,folder+'/'+q.name)
 for name in ['RAW_MANIFEST.json','MATH_META.json']:add(z,p/'inputs'/name,'inputs/'+name)
 for folder,filename in [('rtx223-e08/attempt-006','winjob.py'),('rtx223-e11-u-contract','observation_v3.py')]:add(z,p.parent/folder/filename,'existing_helpers_unmodified/'+filename)
manifest=dict(archive=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,entries=sources,raw_P_G_included=True,raw_full_vocab_f32='local files only,see RAW_F32_LOCAL_INDEX',excluded=['model/weights','vendor EXE/DLL/LIB','raw full-host process command lines'],existing_helpers='Only AtomicJob/DeviceLock/Management used;unused old ETW/AppContainer definitions are unmodified provenance,not an execution framework in this run')
(w/'AUDIT_MANIFEST.json').write_text(json.dumps(manifest,indent=2),encoding='utf8')
(p/'publish_audit_blob.private.json').write_text(json.dumps(dict(encoding='base64',content=base64.b64encode(archive.read_bytes()).decode())),encoding='utf8')
(w/'DELIVERY_MANIFEST.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),files=[dict(path=q.relative_to(d).as_posix(),sha256=sha(q),bytes=q.stat().st_size) for q in sorted(d.rglob('*')) if q.is_file()]),indent=2),encoding='utf8')
print(json.dumps(dict(files=sum(q.is_file() for q in d.rglob('*')),audit_bytes=archive.stat().st_size,audit_sha256=sha(archive))))
