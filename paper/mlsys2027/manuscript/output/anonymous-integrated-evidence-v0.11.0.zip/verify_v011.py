#!/usr/bin/env python3
"""CPU verification of compact, retained evidence; never executes a model.
The two 1,005-record collections have different compositions and overlap.
They must not be added together or treated as new independent observations.
"""
import hashlib, json, os, shutil, subprocess, sys, tempfile, zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def main():
    manifest=json.loads((ROOT/'SHA256SUMS.json').read_text())
    for name,sha in manifest.items():
        assert not Path(name).is_absolute() and '..' not in Path(name).parts,name
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==sha,name
    with tempfile.TemporaryDirectory(prefix='evidence-v011-') as tmp:
        root=Path(tmp); old=root/'historical';old.mkdir()
        with zipfile.ZipFile(ROOT/'historical-v0.10.0.zip') as z:z.extractall(old)
        env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
        def run(script,*args):
            p=subprocess.run([sys.executable,'-B',str(script),*args],cwd=script.parent,env=env,capture_output=True,text=True)
            if p.returncode: raise RuntimeError(p.stdout+p.stderr)
        run(old/'verify_v010.py')
        shutil.copytree(ROOT/'selection',root/'selection')
        case=root/'selection';doc=case/'benchmarks/diagnostic_selection_feasibility_v1';scripts=case/'scripts/analysis/diagnostic_selection_feasibility_v1'
        expected={n:(doc/n).read_bytes() for n in ('RECOMPUTED.json','REPLAY_RESULTS.json','ACTION_CATALOG.json','TEST_RESULTS.json')}
        run(scripts/'audit.py','--from-inputs');run(scripts/'replay.py');run(scripts/'test_analysis.py')
        for n,b in expected.items():assert (doc/n).read_bytes()==b,n
        contexts=json.loads((doc/'inputs/OUTCOMES.json').read_text());ctx=contexts[0]
        by={(r['task'],r['condition'],r['rep']):r for r in ctx['records']}
        def eq(a,b):return a['ids']==b['ids'] and a['endpoint']==b['endpoint']
        def boundary(a):return (a['endpoint'],len(a['ids']),a['ids'][-1])
        pair_counts={}
        for a,b in [('U2','N1'),('U2','N0'),('N0','N1')]:
            pairs=[(by[t,a,r],by[t,b,r]) for t in ctx['tasks'] for r in (1,2,3)]
            pair_counts[a+'/'+b]={'joint':sum(eq(x,y) for x,y in pairs),'boundary':sum(boundary(x)==boundary(y) for x,y in pairs),'reason':sum(x['endpoint']==y['endpoint'] for x,y in pairs)}
        assert pair_counts=={'U2/N1':{'joint':57,'boundary':57,'reason':57},'U2/N0':{'joint':51,'boundary':54,'reason':57},'N0/N1':{'joint':51,'boundary':54,'reason':57}}
        pattern={}
        for task in ctx['tasks']:
            key=''.join('1' if eq(by[task,c,1],by[task,'R',1]) else '0' for c in ('N0','N1','U2'))
            pattern.setdefault(key,[]).append(task)
        assert len(pattern['111'])==16 and pattern['011']==['HumanEval/15'] and pattern['100']==['HumanEval/25'] and pattern['000']==['HumanEval/18']
        replay=json.loads((doc/'REPLAY_RESULTS.json').read_text())['rows']
        summary=[{k:r[k] for k in ('context','mode','decision','additional_available_records')} for r in replay if r['mode'] in ('P2','enumeration')]
    print(json.dumps({'status':'PASS','scope':'Export integrity, paired endpoints, figure groups, original paid replay and historical calculators; no model/raw-archive rerun','fresh_bridge_records':171,'paired_results':pair_counts,'figure_task_groups':{k:len(v) for k,v in pattern.items()},'selection_tests':10,'selection':summary},indent=2))

if __name__=='__main__':main()
