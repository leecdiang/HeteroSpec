from pathlib import Path
import json,hashlib
p=Path(__file__).parent;r=Path(str(p)+"-r2")
out=[]
def add(f,base,folder):
    b=f.read_bytes()
    out.append({"path":folder+"/"+f.relative_to(base).as_posix(),"content":b.decode("utf-8-sig"),"encoding":"utf-8"})
for n in ["BUDGET_LEDGER.json","qual-0.PROCESS_RECEIPT.json","qual-0.stdout.log","qual-0.stderr.log","qual-0/result.json","FAILURE_RAW_RECHECK.json","prepare_retry.py"]:
    add(p/n,p,"benchmarks/b570_draft_prefill_submission_v1")
for f in sorted(r.iterdir()):
    if f.is_file() and f.suffix in (".py",".cpp",".inc",".patch",".txt",".json",".md",".ps1") and f.name not in ("PREREG_PAYLOAD.json",):
        add(f,r,"benchmarks/b570_draft_prefill_submission_v1/attempt2")
(r/"PREREG_PAYLOAD.json").write_text(json.dumps(out))
print(len(out))
