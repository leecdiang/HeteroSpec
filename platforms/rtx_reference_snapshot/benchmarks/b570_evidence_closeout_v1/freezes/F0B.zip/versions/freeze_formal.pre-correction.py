from common import *
import collections
p=R/'code/seal_freeze.py';s=p.read_text().replace("'raw','records']","'raw','records','tokenizer','datasets','history_sources','history_evidence']")
p.write_text(s,encoding='utf8')
audit=load(R/'HISTORY_AUDIT_COMPLETE.json');catalog=load(R/'HISTORY_CATALOG_COMPLETE.json')
sources=set(audit['id_evidence'].values())|{x['evidence_source'] for x in audit['description_evidence'].values()}
snap=[]
for name in sorted(sources):
 p=Path(name);b=p.read_bytes();h=hashlib.sha256(b).hexdigest();assert h==catalog[name]['sha256']
 out=R/'history_evidence'/h;out.parent.mkdir(exist_ok=True);out.write_bytes(b)
 snap.append(dict(original_path=name,relative_path=str(out.relative_to(R)).replace('\\','/'),sha256=h,bytes=len(b)))
save(R/'HISTORY_EXCLUSION_SNAPSHOT.json',dict(status='PASS_ALL_REPORTED_ID_AND_DESCRIPTION_EXCLUSION_SOURCES',sources=snap,catalog_sha256=sha(R/'HISTORY_CATALOG_COMPLETE.json'),full_catalog_file_count=len(catalog),negative_presence_scope='Complete accessible corpus checked at audit time; historical files remain external byte bindings, matched exclusion sources retained in this bundle.',unknown_hosts_disclosed=True))
save(R/'OBSERVABILITY.json',dict(status='FORMAL_COUNTS_FIXED',counts_counter_semantics_sha256=sha(R/'COUNTER_SEMANTICS.json'),formal_phase_elapsed_hooks=False,formal_heavy_callbacks=False,formal_full_state_readback=False,formal_experimental_etw=False,formal_added_sync=False,physical_residency='UNKNOWN',independent_decoder=None,model_status=load(R/'MODEL.json')['status'],model_file_sha256=sha(R/'MODEL.json'),ETW_source_bound=False,actual_watchdog_scope='Formal controller owned-lifecycle budget only; no native phase hooks or GPU barriers.',source_identity_sha256=load(R/'SOURCE_IDENTITY.json')['sha256']))
p=R/'TOKENIZER_BINDING.json';j=load(p);j['cohort_dataset_splits']={x['id']:x['dataset_split'] for x in load(R/'COHORT_SELECTION.json')['selected']};save(p,j)
# Bind the exact complete native conditions, scope and resolved static statistics before formal startup.
save(R/'F0B_PRECOMMIT.json',dict(stage='F0B',status='PREPARED_REQUIRES_COMMIT_PUSH_ACTUAL_GIT_READBACK',utc=now(),design_head='92d08d80bd8e8f567ec02c3b1d5b04dd452b3efe',base_source_head='4db9bc501fa01c76db50721e7d11e9a0d1e53782',all_five_arms_fixed=True,formal_requests=1200,formal_warmups=50,core_units_used=234,profile_units_used=100,formal_retry_limit=0,plan_sha256=load(R/'FORMAL_PLAN.json')['design_sha256'],formal_plan_digest=hashlib.sha256(json.dumps(load(R/'FORMAL_PLAN.json'),ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest(),model_digest=hashlib.sha256(json.dumps(load(R/'MODEL.json'),ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest(),cohort_population_note_sha256=sha(R/'COHORT_POPULATION_NOTE.json'),all_start_guards='F0B_REMOTE_READBACK.json actual Git bytes PASS required',before_first_formal_warmup=True,source_actor='code/formal.py + code/runtime.py',statistical_actor='PR90 closeout.py/mechanism.py exact design checkout',unit_hardcap=1634,owned_gpu_seconds_hardcap=28800))
print('F0B all evidence/config prepared',flush=True)
os.execv(sys.executable,[sys.executable,'-X','utf8',str(R/'code/seal_freeze.py'),'F0B'])
