"""Recreate only the previously approved zero-capability task profile. Keep prior records."""
import ctypes as C, json, os
from ctypes import wintypes as W
from pathlib import Path
from datetime import datetime,timezone
root=Path(__file__).resolve().parent
old=json.loads((root.parent/'rtx223-e07/acl/PROFILE_CREATED.json').read_bytes())
u=C.WinDLL('userenv')
p=C.c_void_p()
f=u.CreateAppContainerProfile
f.argtypes=[W.LPCWSTR,W.LPCWSTR,W.LPCWSTR,C.c_void_p,W.DWORD,C.POINTER(C.c_void_p)]
f.restype=C.c_long
rc=f(old['package'],old['package'],'Authorized independent upstream diagnostic',None,0,C.byref(p))
if rc:raise RuntimeError(hex(rc&0xffffffff))
a=C.WinDLL('advapi32');t=W.LPWSTR()
a.ConvertSidToStringSidW.argtypes=[C.c_void_p,C.POINTER(W.LPWSTR)]
if not a.ConvertSidToStringSidW(p,C.byref(t)) or t.value!=old['package_sid']:
 raise RuntimeError('unexpected package SID')
folder=W.LPWSTR()
u.GetAppContainerFolderPath.argtypes=[W.LPCWSTR,C.POINTER(W.LPWSTR)]
u.GetAppContainerFolderPath.restype=C.c_long
if u.GetAppContainerFolderPath(t,C.byref(folder)):raise RuntimeError('profile path')
out=dict(old,profile=folder.value,created_utc=datetime.now(timezone.utc).isoformat(),authorization='Current415-kernel upstream diagnostic authorization reuses the approved identical zero-capability package; existing staging ACL unchanged')
with (root/'PROFILE_CREATED.json').open('x',encoding='utf8') as h:json.dump(out,h,indent=2);h.flush();os.fsync(h.fileno())
Path(folder.value,'Temp').mkdir(exist_ok=True)
print('Created authorized zero-capability profile; existing staging SID ACL unchanged')
