// Mechanism-only common target frontend for pinned llama.cpp b10839.
#include "arg.h"
#include "common.h"
#include "sampling.h"
#include "llama.h"
#include "nlohmann/json.hpp"
#include <clocale>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <limits>
#include "log.h"

#include "observer.h"
#include "phase.h"
using json = nlohmann::ordered_json;

int main(int argc, char ** argv) {
    std::setlocale(LC_NUMERIC, "C");
    common_params params;
    common_init();
    if (!common_params_parse(argc, argv, params, LLAMA_EXAMPLE_COMPLETION)) return 1;
    if (params.n_ctx != 1024 || params.n_batch != 512 ||
        (params.n_ubatch != 128 && (params.n_ubatch < 1 || params.n_ubatch > 8)) || (params.n_predict < 128 || params.n_predict > 512) ||
        params.sampling.temp != 0 || params.sampling.seed != 123 || params.warmup) {
        std::cerr << "Frozen mechanism parameter contract violated\n"; return 2;
    }
    prefill_observer observer;
    if(observer.instrument){params.cb_eval=prefill_observer::callback;params.cb_eval_user_data=&observer;}
    auto continuation_cp=common_context_params_to_llama(params);
    params.n_outputs_max=512;params.n_outputs_max_per_seq=1;
    common_log_set_verbosity_thold(4);
    llama_backend_init();
    llama_numa_init(params.numa);
    params.n_ubatch=observer.prefill_ub;
    auto init = common_init_from_params(params);
    auto * ctx = init->context();
    auto * model = init->model();
    auto * sampler = init->sampler(0);
    if (!ctx || !model || !sampler) return 3;
    const auto * vocab = llama_model_get_vocab(model);
    auto * source_target=ctx;
    common_log_set_verbosity_thold(3);
    std::cout<<"HS_READY\n"<<std::flush;
    std::string line;
    while(std::getline(std::cin,line)){
    const auto whole_start=ggml_time_us();
    const auto req=json::parse(line);observer.reset(req);
    ctx=source_target;
    llama_b570_pilot_bind_phase_ubatch(ctx,128);
    llama_memory_clear(llama_get_memory(ctx),true);llama_synchronize(ctx);
    common_sampler_reset(init->sampler(0));sampler=init->sampler(0);
    auto reset_target=prefill_observer::positions(ctx);
    std::vector<llama_token> input;
    input=req.at("prompt_ids").get<std::vector<llama_token>>();
    if(input.empty()||input.size()+params.n_predict>1024)return 4;
    for (auto id : input) if (id < 0 || id >= llama_vocab_n_tokens(vocab)) return 5;
    const char * output_path = observer.path.c_str();
    if (!output_path) return 6;
    json result;
    result["schema"] = "heterospec.b570.mechanism.harness.v08";
    result["prompt_ids"] = input;
    result["context"] = {{"n_ctx",llama_n_ctx(ctx)},{"n_batch",llama_n_batch(ctx)},
                         {"n_ubatch",llama_n_ubatch(ctx)},{"sequence_id",0},
                         {"flash_attention","off"},{"seed",123},{"greedy",true}};
    result["partitions"] = json::array();
    result["decisions"] = json::array();
    observer.phase="prefill";
    std::vector<llama_token> all;
    int n_past = 0;
    const bool matched=false;
    if(matched){
        observer.decode(ctx,llama_batch_get_one(input.data(),input.size()-1),"target");
        observer.decode(ctx,llama_batch_get_one(&input.back(),1),"target");
        all=input;n_past=input.size();
    }else{
    for(size_t i=0;i<input.size();i+=512){
        const int size=std::min(size_t(512),input.size()-i);
        std::vector<llama_token> chunk(input.begin()+i,input.begin()+i+size);
        all.insert(all.end(),chunk.begin(),chunk.end());
        for(auto id:chunk)common_sampler_accept(sampler,id,false);
        observer.begin(ctx,llama_batch_get_one(chunk.data(),size));
        if(!common_prompt_batch_decode(ctx,all,size,n_past,512,"",false))return 7;
        observer.end(ctx,0);
    }}
    llama_synchronize(ctx);
    const auto generation_start=ggml_time_us();
    int pending=-1; json pending_scores;
    const bool transfer=std::getenv("HS_NO_TRANSFER")==nullptr && matched;
    pending_scores=observer.top(ctx,-1);pending=common_sampler_sample(sampler,ctx,-1);
    const pj phase_binding=pilot_phase(ctx,observer,1,pending);
    observer.phase="continuation";
    std::vector<llama_token> generated;
    std::vector<bool> eog;
    for (int i=0;i<params.n_predict;++i) {
        const float * logits = pending>=0 && i==0 ? nullptr : llama_get_logits_ith(ctx,-1);
        if (!logits && !(pending>=0 && i==0)) return 8;
        int top1=-1,top2=-1;
        // Ascending IDs preserve the greedy sampler's first-ID tie convention.
        if(logits && observer.instrument) for (int id=0;id<llama_vocab_n_tokens(vocab);++id) {
            if (top1<0 || logits[id]>logits[top1]) { top2=top1;top1=id; }
            else if (top2<0 || logits[id]>logits[top2]) top2=id;
        }
        if(!logits && observer.instrument){top1=pending_scores["top1"];top2=pending_scores["top2"];}
        const float first=observer.instrument?(logits?logits[top1]:pending_scores["top1_score"].get<float>()):0,second=observer.instrument?(logits?logits[top2]:pending_scores["top2_score"].get<float>()):0;
        const llama_token id=(pending>=0 && i==0)?pending:common_sampler_sample(sampler,ctx,-1);
        common_sampler_accept(sampler,id,true);
        const bool stop=llama_vocab_is_eog(vocab,id);
        generated.push_back(id);eog.push_back(stop);
        observer.commit(ctx,id,stop,false,-1,-1,{{"top1",top1},{"top2",top2},{"top1_score",first},{"top2_score",second}});
        result["decisions"].push_back({{"output_index",i},{"sequence_position",n_past},
            {"committed_id",id},{"eog",stop},{"raw_target_top1",top1},
            {"raw_target_top2",top2},{"top1_logit",first},{"top2_logit",second},
            {"margin",first-second},{"n_past",n_past}});
        if (stop || i==params.n_predict-1) break;
        all.push_back(id);
        result["partitions"].push_back({{"kind","decode"},{"position",n_past},
                                        {"input_ids",std::vector<llama_token>{id}},{"n_tokens",1}});
        observer.begin(ctx,llama_batch_get_one(&all.back(),1));
        if (!common_prompt_batch_decode(ctx,all,1,n_past,512,"",false)) return 9;
        observer.end(ctx,0);
    }
    llama_synchronize(ctx);
    const auto generation_end=ggml_time_us();
    if(ctx!=source_target){common_sampler_free(sampler);llama_free(ctx);}
    const auto whole_end=ggml_time_us();
    result["generated_ids"]=generated;
    result["eog"]=eog;
    observer.finish(generated,eog,input);
    std::ofstream out(output_path+std::string(".mechanism.json"),std::ios::binary);
    out << result.dump(2) << "\n";
    if (!out) return 10;
    out.close();
    pj metrics={{"phase_binding",phase_binding},{"candidate_family","CANONICAL_PREFILL_INPLACE_PHASE_BINDING"},{"target_reservation",512},{"request_id",req.at("request_id")},{"capture",observer.path},{"generation_ms",(generation_end-generation_start)/1000.0},{"whole_request_ms",(whole_end-whole_start)/1000.0},{"raw_count",generated.size()},{"drafted",0},{"accepted",0},{"reset_target",reset_target},{"target_continuation_ub",continuation_cp.n_ubatch},{"threads",params.cpuparams.n_threads},{"batch_threads",params.cpuparams_batch.n_threads}};
    std::ofstream metrics_file(observer.path+".metrics.json",std::ios::binary);metrics_file<<metrics.dump(2)<<"\n";metrics_file.close();
    std::cout<<"HS_RESULT "<<metrics.dump()<<"\n"<<std::flush;
    }
    return 0;
}
