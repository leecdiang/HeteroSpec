from pathlib import Path
import json,hashlib,runpy,sys
p=Path(__file__).resolve().parent
plan=p/'CPU_PLAN_003.json'
assert hashlib.sha256(plan.read_bytes()).hexdigest()=='82f4e5e1dcf87f58e0a12a2a11891e0f9c141ffb4c33d5425fca8919c433cdb7'
for row in json.loads(plan.read_bytes())['controller_inputs']:
 assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256']
runpy.run_path(str(p/'create_profile.py'),run_name='__main__')
sys.argv=[str(p/'runner_v3.py'),str(plan)]
runpy.run_path(str(p/'runner_v3.py'),run_name='__main__')
