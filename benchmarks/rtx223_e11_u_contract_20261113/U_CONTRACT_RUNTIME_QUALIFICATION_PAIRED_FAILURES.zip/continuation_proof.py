"""Pure-CPU proof that an already charged timing reservation is unspent."""
def audit(events,attempt,native,contract_sha):
 def need(ok,why):
  if not ok:raise RuntimeError(why)
 need(events[0]['kind']=='READY' and events[0]['limit']==500 and events[0]['contract_sha256']==contract_sha,'original contract identity')
 need(events[-1]['kind']=='STOPPED' and events[-1]['reserved']==430,'prior controller must be closed430')
 need(not any('CONTINU' in x['kind'] for x in events),'continuation already claimed')
 reserved=[x for x in events if x['kind']=='RESERVED_BEFORE_TASK']
 need(sum(x['reserved'] for x in reserved)==430,'do not reset/refund original reservations')
 timing=[x for x in reserved if x['request']=='003-timing.json'];need(len(timing)==1 and timing[0]['reserved']==416,'original timing416')
 exits=[x for x in events if x['kind']=='TASK_EXIT' and x['request']=='003-timing.json']
 need(len(exits)==1 and exits[0]['status']=='FAILED' and exits[0]['owned_exit_confirmed'],'prior timing task exit')
 records=[x['event'] for x in attempt]
 need(records[-1]['kind']=='FAIL' and records[-1]['failure']=='foreign compute context' and records[-1]['owned_process_exit_confirmed'],'preserve exact admission failure')
 need(not any(x.get('kind') in ('OWNED_SUSPENDED','PERMIT') for x in records),'prior native creation/permit would make unspent proof invalid')
 ends=[x for x in records if x.get('kind')=='EXIT'];need(len(ends)==1 and ends[0]['code'] is None and ends[0]['confirmed'],'no native process existed')
 need(native['status']=='PASS_E11_TWO_CONTRACTS' and native['explicit_prelaunch_charged']==8,'reuse qualified operands,do not rerun')
 need(native['explicit_by_operation']==dict(B_quantizer=2,B_projection=2,U_quantizer=2,U_projection=2),'qualification counts')
 return dict(total_limit=500,total_reserved_unchanged=430,qualification_permits=8,prior_timing_permits=0,existing_timing_reservation=416,new_reservation=0,next_timing_explicit_limit=392,maximum_total_after_success=400,refund=0,one_continuation_only=True)
