"""Create read-only work counters and observational switches; arithmetic/core path unchanged."""
from common import *
old=R/'versions/PR88-worker.cpp'
assert sha(old)=='858f5976bb0c0164e8bf8e8678913cd1f815be64e9be7e928ca1db7d5554ad95'
h=R/'native/candidate-src/llama-context.h';s=h.read_text(encoding='utf8');anchor='struct llama_context {'
assert s.count(anchor)==1
s=s.replace(anchor,anchor+"""
    // PR90: read-only integer observations of actual successful decode micrographs.
    bool b570_work_enabled = false;
    uint64_t b570_micrographs = 0, b570_micrograph_rows = 0;
    std::map<uint32_t, uint64_t> b570_micrograph_widths;
""");h.write_text(s,encoding='utf8')
p=R/'native/candidate-src/llama-context.cpp';s=p.read_text(encoding='utf8')
anchor='        // plot the computation graph in dot format (for debugging purposes)'
assert s.count(anchor)==1
s=s.replace(anchor,"""        if (b570_work_enabled) {
            ++b570_micrographs;
            b570_micrograph_rows += ubatch.n_tokens;
            ++b570_micrograph_widths[ubatch.n_tokens];
        }

"""+anchor)
s+="""
extern "C" __declspec(dllexport) void llama_b570_work_enable(llama_context * ctx, bool enable) {
    ctx->b570_work_enabled = enable;
    ctx->b570_micrographs = ctx->b570_micrograph_rows = 0;
    ctx->b570_micrograph_widths.clear();
}
extern "C" __declspec(dllexport) uint64_t llama_b570_work_graphs(const llama_context * ctx) { return ctx->b570_micrographs; }
extern "C" __declspec(dllexport) uint64_t llama_b570_work_rows(const llama_context * ctx) { return ctx->b570_micrograph_rows; }
extern "C" __declspec(dllexport) uint64_t llama_b570_work_width(const llama_context * ctx, uint32_t w) {
    auto it = ctx->b570_micrograph_widths.find(w); return it == ctx->b570_micrograph_widths.end() ? 0 : it->second;
}
""";p.write_text(s,encoding='utf8')
s=old.read_text(encoding='utf8')
def repl(a,b):
 global s
 assert s.count(a)==1,(a,s.count(a))
 s=s.replace(a,b)
repl('using json=nlohmann::ordered_json;',r'''extern "C" __declspec(dllimport) void llama_b570_work_enable(llama_context *,bool);
extern "C" __declspec(dllimport) uint64_t llama_b570_work_graphs(const llama_context *);
extern "C" __declspec(dllimport) uint64_t llama_b570_work_rows(const llama_context *);
extern "C" __declspec(dllimport) uint64_t llama_b570_work_width(const llama_context *,uint32_t);
using json=nlohmann::ordered_json;
std::string observation_mode;
std::string counter_hash;
bool counted(){return observation_mode!="baseline";}
bool heavy(){return observation_mode=="heavy";}
bool timed(){return observation_mode=="lite"||heavy();}
json hist_empty(){return json::object();}
void hist_add(json & h,int key,int value=1){std::string k=std::to_string(key);h[k]=h.value(k,0)+value;}
struct Work {
 json w,f,spans;std::chrono::steady_clock::time_point request_start;
 Work(int prompt):request_start(std::chrono::steady_clock::now()) {
  w=json::object();
  for(auto n:{"prompt_ids_count","output_ids_count","proposal_generated","proposal_verified","accepted_committed","first_mismatch_rejected","unexamined_after_mismatch","terminal_discarded","unverified_before_verify","initial_target_committed","bonus_committed","correction_committed","fallback_committed","verify_cycles","verification_seed_rows","draft_continuation_calls","draft_continuation_rows","draft_proposal_calls","draft_proposal_rows","draft_catchup_calls","draft_catchup_rows","rollback_calls","target_prefill_calls","draft_prefill_calls","target_verification_rows","target_ordinary_rows","target_micrographs","target_micrograph_rows","draft_micrographs","draft_micrograph_rows","sampling_calls","phase_binding_calls","kv_trim_calls","inherited_explicit_sync_calls"})w[n]=0;
  w["prompt_ids_count"]=prompt;w["counter_semantics_sha256"]=counter_hash;
  for(auto n:{"accepted_prefix_hist","cycle_progress_hist","verification_caller_width_hist","target_physical_width_hist","target_prefill_physical_width_hist","target_continuation_physical_width_hist","draft_physical_width_hist","attempted_positions","accepted_positions"})w[n]=hist_empty();
  f=json::object();for(auto n:{"target_prefill_ids","draft_prefill_ids","draft_continuation_rows","reconcile_output_ids","rollback_calls","request_channel","target_continuation_calls_w1","target_continuation_calls_w2"})f[n]=0;f["request_channel"]=1;
  spans=json::array();
 }
 void inc(const std::string & n,int value=1){if(counted())w[n]=w[n].get<int64_t>()+value;}
 void span(const std::string & label,std::chrono::steady_clock::time_point begin,const std::string & scope) {
  if(timed())spans.push_back({{"phase",label},{"begin_ms",std::chrono::duration<double,std::milli>(begin-request_start).count()},{"end_ms",std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-request_start).count()},{"completion_scope",scope},{"gpu_event_ms",nullptr}});
 }
};
Work * work=nullptr;
''')
repl('void start(){samples.clear();violation=false;max_gap_ms=0;active=true;sample("ENGINEERING_BEGIN");timer=std::thread([&]{try{while(active){sample("ENGINEERING_PERIODIC");std::this_thread::sleep_for(std::chrono::milliseconds(5));}}catch(...){violation=true;}});}',
'void start(){samples.clear();violation=false;max_gap_ms=0;active=true;sample("REQUEST_BEGIN");if(heavy())timer=std::thread([&]{try{while(active){sample("HEAVY_PERIODIC");std::this_thread::sleep_for(std::chrono::milliseconds(5));}}catch(...){violation=true;}});}')
repl('{"requested_period_ms",5}','{"requested_period_ms",heavy()?json(5):json(nullptr)}')
repl('cp.cb_eval=observe_compute;cp.cb_eval_user_data=this;','cp.cb_eval=heavy()?observe_compute:nullptr;cp.cb_eval_user_data=heavy()?this:nullptr;')
repl('decodes=0;compute_violation=false;','decodes=0;llama_b570_work_enable(ctx,counted());if(work)work->inc("inherited_explicit_sync_calls");compute_violation=false;')
a='  memory->sample("BEFORE_"+role+"_"+phase);int rc=llama_decode(ctx,b);++decodes;llama_batch_free(b);if(rc)throw std::runtime_error("Actual native decode failure:"+std::to_string(rc));llama_synchronize(ctx);memory->sample("AFTER_"+role+"_"+phase);if(compute_violation)throw std::runtime_error("RESIDENCY_VIOLATION_CPU_MODEL_COMPUTE");'
b=r'''  auto phase_begin=clock_type::now();
  uint64_t g0=llama_b570_work_graphs(ctx),r0=llama_b570_work_rows(ctx);std::vector<uint64_t> widths(513);if(counted())for(int w=1;w<=512;++w)widths[w]=llama_b570_work_width(ctx,w);
  if(heavy())memory->sample("BEFORE_"+role+"_"+phase);
  int rc=llama_decode(ctx,b);++decodes;llama_batch_free(b);if(rc)throw std::runtime_error("Actual native decode failure:"+std::to_string(rc));
  if(heavy()){llama_synchronize(ctx);memory->sample("AFTER_"+role+"_"+phase);}
  if(compute_violation)throw std::runtime_error("RESIDENCY_VIOLATION_CPU_MODEL_COMPUTE");
  if(work&&counted()){
   std::string lower=role=="TARGET"?"target":"draft";work->inc(lower+"_micrographs",int(llama_b570_work_graphs(ctx)-g0));work->inc(lower+"_micrograph_rows",int(llama_b570_work_rows(ctx)-r0));
   if(phase=="PREFILL"){work->inc(lower+"_prefill_calls");work->f[lower+"_prefill_ids"]=work->f[lower+"_prefill_ids"].get<int>()+int(ids.size());}
   else if(role=="DRAFT"){work->inc("draft_continuation_calls");work->inc("draft_continuation_rows",int(ids.size()));std::string kind=phase=="PROPOSE"?"draft_proposal":"draft_catchup";work->inc(kind+"_calls");work->inc(kind+"_rows",int(ids.size()));work->f["draft_continuation_rows"]=work->f["draft_continuation_rows"].get<int>()+int(ids.size());}
   else {work->f["target_continuation_calls_w"+std::to_string(ids.size())]=work->f["target_continuation_calls_w"+std::to_string(ids.size())].get<int>()+1;work->inc(phase=="VERIFY"?"target_verification_rows":"target_ordinary_rows",int(ids.size()));}
   for(int w=1;w<=512;++w){auto delta=llama_b570_work_width(ctx,w)-widths[w];if(delta){hist_add(work->w[lower+"_physical_width_hist"],w,int(delta));if(role=="TARGET")hist_add(work->w[phase=="PREFILL"?"target_prefill_physical_width_hist":"target_continuation_physical_width_hist"],w,int(delta));}}
  }
  if(work&&timed())work->span(role+"_"+phase,phase_begin,heavy()?"COMPLETED_WITH_HEAVY_SYNC_NOT_FOR_CALIBRATION":"ASYNC_DECODE_ENQUEUE_ONLY_NOT_COMPLETED_COMPONENT_WALL");
'''
repl(a,b)
repl(' int sample(int index){int id=llama_sampler_sample(sampler,ctx,index);',' int sample(int index){auto begin=clock_type::now();if(work)work->inc("sampling_calls");int id=llama_sampler_sample(sampler,ctx,index);if(work)work->span(role+"_SAMPLE",begin,"NATIVE_SAMPLER_WITH_EXISTING_LOGITS_WAIT");')
repl(' void trim(int pos){if(!llama_memory_seq_rm',' void trim(int pos){if(work)work->inc("kv_trim_calls");if(!llama_memory_seq_rm')
repl('if(argc!=9)throw std::runtime_error("Arguments: profile target draft|NONE ub mode k trace_dir probe|resident");','if(argc!=10)throw std::runtime_error("Arguments: profile target draft|NONE ub mode k trace_dir probe|resident observation_mode");')
repl('int ub=std::stoi(argv[4]),k=std::stoi(argv[6]);','int ub=std::stoi(argv[4]),k=std::stoi(argv[6]);observation_mode=argv[9];if(observation_mode!="baseline"&&observation_mode!="counts"&&observation_mode!="lite"&&observation_mode!="heavy")throw std::runtime_error("Unknown observation mode");{std::ifstream f(std::filesystem::path(argv[0]).parent_path()/"COUNTER_HASH.txt");std::getline(f,counter_hash);if(counter_hash.size()!=64)throw std::runtime_error("Counter semantics binding missing");}')
repl('int64_t threshold;if(profile=="STANDARD_Q6")threshold=536870912;else if(profile=="TIGHT_Q8")threshold=134217728;else throw std::runtime_error("Unknown profile");','int64_t threshold=536870912;if(profile!="STANDARD_Q6")throw std::runtime_error("PR90 only STANDARD_Q6");')
repl('if(k<1||k>3||action!="probe"&&action!="resident")','if(k!=1||action!="probe"&&action!="resident")')
repl('if(ub!=32&&ub!=128&&ub!=512)','if(ub!=128&&ub!=512)')
repl('if(mode=="ordinary"&&draft!="NONE")','if(draft!="NONE"&&df!="Llama-3.2-1B-Instruct-Q4_K_M.gguf")throw std::runtime_error("PR90 only Q4 draft");if(mode!="ordinary"&&ub!=512)throw std::runtime_error("PR90 fixed matched/candidate UB512");if(mode=="ordinary"&&draft!="NONE")')
repl('int cap=req.at("cap");bool capture=req.at("capture");','int cap=req.at("cap");bool capture=req.at("capture");if(capture&&!heavy())throw std::runtime_error("Full capture only heavy engineering");Work current(int(inp.size()));work=&current;')
repl('memory.start();tgt.prefill(inp);if(dft)dft->prefill(inp);','memory.start();tgt.prefill(inp);memory.require("TARGET_PREFILL");if(dft){dft->prefill(inp);memory.require("DRAFT_PREFILL");}')
repl('if(mode=="vulkan_batched_repair"){auto pos=','if(mode=="vulkan_batched_repair"){work->inc("phase_binding_calls");auto bind_begin=clock_type::now();auto pos=')
repl('{"to_ub",1}});}}\n   std::vector<int> out;','{"to_ub",1}});}work->span("PHASE_BINDING",bind_begin,"CPU_BINDING_ONLY_NO_NEW_SYNC");memory.require("AFTER_PHASE_BINDING");}\n   std::vector<int> out;')
repl('bool done=commit(next);','work->inc("initial_target_committed");bool done=commit(next);')
repl('++base;next=tgt.sample(-1);done=commit(next);continue;','++base;next=tgt.sample(-1);work->inc("fallback_committed");done=commit(next);continue;')
repl('proposal.push_back(p);++proposed;','proposal.push_back(p);++proposed;work->inc("proposal_generated");')
repl('tgt.decode(batch,base,true,"VERIFY");','tgt.decode(batch,base,true,"VERIFY");work->inc("proposal_verified",int(proposal.size()));work->inc("verification_seed_rows");work->inc("verify_cycles");if(counted())hist_add(work->w["verification_caller_width_hist"],int(batch.size()));int progress_before=int(out.size());')
repl('int decision=tgt.sample(int(j));decisions.push_back(decision);done=commit(decision);if(j<proposal.size()&&decision==proposal[j]){++accepted;++n;if(done)break;}else{next=decision;break;}',
r'''int decision=tgt.sample(int(j));decisions.push_back(decision);if(j<proposal.size()&&counted())hist_add(work->w["attempted_positions"],int(j));
     done=commit(decision);if(j<proposal.size()&&decision==proposal[j]){++accepted;++n;work->inc("accepted_committed");if(counted())hist_add(work->w["accepted_positions"],int(j));if(done){work->inc("terminal_discarded",int(proposal.size())-int(j)-1);break;}}
     else {if(j<proposal.size()){work->inc("first_mismatch_rejected");work->inc("unexamined_after_mismatch",int(proposal.size())-int(j)-1);work->inc("correction_committed");}else work->inc("bonus_committed");next=decision;break;}''')
repl('base=keep;++rollbacks;','base=keep;++rollbacks;work->inc("rollback_calls");if(counted()){hist_add(work->w["accepted_prefix_hist"],n);hist_add(work->w["cycle_progress_hist"],int(out.size())-progress_before);work->f["rollback_calls"]=work->f["rollback_calls"].get<int>()+1;}')
repl('llama_synchronize(tgt.ctx);if(dft)llama_synchronize(dft->ctx);auto mem=memory.stop();','llama_synchronize(tgt.ctx);work->inc("inherited_explicit_sync_calls");if(dft){llama_synchronize(dft->ctx);work->inc("inherited_explicit_sync_calls");}memory.require("REQUEST_COMPLETE");auto mem=memory.stop();if(counted()){work->w["output_ids_count"]=out.size();work->f["reconcile_output_ids"]=out.size();}')
repl('   emit(result); // Complete IDs travel before any disk persistence; controller hashes afterward.',
r'''   result["observation_mode"]=observation_mode;result["actual_condition"]={{"prefill_ub",ub},{"continuation_ub",llama_n_ubatch(tgt.ctx)},{"output_capacity",mode=="ordinary"?1:4},{"maximum_k",dft?1:0},{"logical_batch",512},{"n_ctx",1024},{"threads",10},{"kv","F16"},{"flash_attention",false}};
   result["workload"]=counted()?work->w:json(nullptr);result["feature_units"]=counted()?work->f:json(nullptr);
   result["observation"]={{"phase_timers",timed()},{"heavy_capture",capture},{"etw",false},{"added_sync",heavy()}};
   result["elapsed_hooks"]=timed()?work->spans:json(nullptr);result["component_completed_wall"]=nullptr;result["GPU_completion_event_ms"]=nullptr;
   result["component_timing_status"]=timed()?"ASYNC_ENQUEUE_SPANS_NOT_COMPLETED_WALL_PARTITION":"DISABLED_COUNTS_CHANNEL";
   emit(result); // Complete IDs travel before any disk persistence; controller hashes afterward.''')
repl('if(memory.violation)throw std::runtime_error("MEMORY_BLOCKED:ENGINEERING_PEAK");emit({"','if(memory.violation)throw std::runtime_error("MEMORY_BLOCKED:ENGINEERING_PEAK");work=nullptr;emit({"') if False else None
(R/'native/worker.cpp').write_text(s,encoding='utf8')
# Build all private core translation units against the extended observation-only layout.
p=R/'native/CMakeLists.txt';s=p.read_text(encoding='utf8').replace('b570-memory-worker','b570-evidence-worker');p.write_text(s,encoding='utf8')
sem=dict(schema='heterospec.b570.pr90.counter_semantics.v1',proposal_fate='five mutually exclusive final fates; accepted means committed before cap/EOG; first mismatch and unexamined separated',output_conservation='initial+accepted+bonus+correction+fallback; EOG included',draft_continuation='actual proposal decode plus sync/catch-up calls and rows; draft UB1',target_physical_work='actual successful process_ubatch calls in llama_context::decode and actual ubatch.n_tokens; not logical k+1 concurrency',rollback_calls='one reconciled speculative cycle; kv_trim_calls retains both target/draft trim calls',width_hist='actual occupied query rows from native ubatch execution; no GPU completion time inferred',observation='baseline disables new work counters, counts integer summaries only, lite retains enqueue/sample CPU timestamps without new synchronization, heavy callbacks and full KV byte readback; no experimental ETW when proof unavailable',memory='counts/lite/baseline native load/pre-request/request begin/prefill/phase/end checkpoints; heavy retains5ms and per-decode observations; minima are sampled/checkpoint scope, never continuous residency',timing='Whole request always includes mandatory checks, control, synchronization and pipe endpoint parsing. Per-decode added observer sync removed outside heavy; original reset/final lifecycle and native sampler logits waits preserved.')
save(R/'COUNTER_SEMANTICS.json',sem);(R/'build/Release/COUNTER_HASH.txt').write_text(sha(R/'COUNTER_SEMANTICS.json')+'\n',encoding='ascii')
save(R/'OBSERVATION_IMPLEMENTATION.json',dict(status='SOURCE_PREPARED_NOT_YET_NATIVE_QUALIFIED',counter_semantics_sha256=sha(R/'COUNTER_SEMANTICS.json'),old_worker_sha256=sha(old),new_worker_sha256=sha(R/'native/worker.cpp'),numeric_arithmetic_files_changed=False,private_context_fields_and_successful_micrograph_integer_counter_only=True,core_arithmetic_unchanged_but_new_DLL_bytes_expected=True,phase_elapsed_completion_scope='ASYNC_ENQUEUE_ONLY_LITE_NO_COMPLETED_PARTITION_NO_ADDED_SYNC'))
print('Prepared observation/control sources',flush=True)
