from pathlib import Path
import hashlib,runpy,sys,json
p=Path(__file__).resolve().parent
plan=p/"CPU_PLAN_005.json"
assert hashlib.sha256(plan.read_bytes()).hexdigest()=="21917c9f4b81189bd6cf42cd4e4575f86bd56c56be2cca5cf815f67dc3bac6e8"
for row in json.loads(plan.read_bytes())["controller_inputs"]:
 assert hashlib.sha256(Path(row["path"]).read_bytes()).hexdigest()==row["sha256"]
sys.argv=[str(p/"runner-v5.py"),str(plan)]
runpy.run_path(str(p/"runner-v5.py"),run_name="__main__")
