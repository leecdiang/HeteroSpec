import runpy,sys
from pathlib import Path
p=Path(__file__).resolve().parent
sys.argv=[str(p/"cleanup_profile.py"),"apply-after-owned-processes-ended"]
runpy.run_path(str(p/"cleanup_profile.py"),run_name="__main__")
