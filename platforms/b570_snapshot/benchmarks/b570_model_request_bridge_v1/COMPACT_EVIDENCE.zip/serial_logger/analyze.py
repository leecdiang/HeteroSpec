"""CPU-only recomputation of saved model logits, metadata and timestamp calibration."""
import json,pathlib,hashlib,re,statistics,struct
root=pathlib.Path(__file__).parent
bridge=pathlib.Path("C:/hs/b570-model-bridge-20261020162500")
failed=pathlib.Path("C:/hs/b570-model-bridge-20261020162000")
def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
folders=[bridge/"session-0",root/"session-0",root/"session-1"]
records=[read(p/"result.json") for p in folders]
allchecks=[];runs=[]
for label,folder,data in zip(["CLEAN_A","PROFILE","CLEAN_B"],folders,records):
    assert data["status"]=="GEOMETRY_AND_OBSERVER_QUALIFIED" and data["normal_cleanup_returned"]
    assert data["model"]=={"heads":32,"kv_heads":8,"layers":36}
    assert len(data["runs"])==3
    for run in data["runs"]:
        assert len(run["steps"])==16 and run["context_cleanup_returned"]
        for step in run["steps"]:
            idx=step["step"];p=folder/f"run-{run['run']}-step-{idx}.f32"
            reference=bridge/"session-0"/f"run-0-step-{idx}.f32"
            assert sha(p)==sha(reference)
            values=memoryview(p.read_bytes()).cast("f")
            best=max(range(len(values)),key=values.__getitem__)
            assert best==step["token_id"] and best==records[0]["runs"][0]["steps"][idx]["token_id"]
            allchecks.append({"process":label,"run":run["run"],"step":idx,"bytes":p.stat().st_size,"sha256":sha(p),"token_id":best})
    observer=data["runs"][1]
    assert observer["observer_asks"]>0 and observer["observer_unexpected_completions"]==0
    attn=observer["signatures"]
    assert attn and all("B570" in x["device"] for x in attn)
    qks=[x for x in attn if re.fullmatch(r"kq-\d+",x["name"])]
    assert len(qks)==72
    assert all(x["ne"]==[256,1,32,1] and x["sources"][0]["ne"]==[128,256,8,1] and x["sources"][1]["ne"]==[128,1,32,1] for x in qks)
    # Predeclared third-context decode-only median. Excludes prompt and raw writes.
    times=[x["decode_completed_seconds"] for x in data["runs"][2]["steps"] if "decode_completed_seconds" in x]
    assert len(times)==15
    runs.append({"process":label,"median_decode_seconds":statistics.median(times),"decode_seconds":times,
     "third_context_request_diagnostic_seconds":data["runs"][2]["request_diagnostic_seconds"],
     "observer_attention_signatures":len(attn),"qk_signatures":len(qks)})
a,p,b=[r["median_decode_seconds"] for r in runs]
ratios={"clean_b_over_a":b/a,"profile_over_clean_a":p/a,"profile_over_clean_b":p/b}
calibration=all(.9<=v<=1.1 for v in ratios.values())
tables=[]
log=(root/"session-0.stderr.log").read_text()
for block in log.split("Vulkan Timings:\n")[1:]:
    rows=[]
    for line in block.splitlines():
        m=re.fullmatch(r"(.+): (\d+) x ([\d.eE+-]+) us = ([\d.eE+-]+) us(?: .*)?",line)
        if m:rows.append({"op":m[1],"count":int(m[2]),"mean_us":float(m[3]),"total_us":float(m[4])})
        total=re.fullmatch(r"Total time: ([\d.eE+-]+) us\.",line)
        if total:
            whole=float(total[1]);break
    assert rows and abs(sum(x["total_us"] for x in rows)-whole)/whole<1e-4
    selected=[x for x in rows if x["op"] in ["MUL_MAT_VEC f16 m=128 n=1 k=256 batch=32","MUL_MAT_VEC f16 m=256 n=1 k=128 batch=32","SOFT_MAX"]]
    assert len(selected)==3 and all(x["count"]==36*(124+15) for x in selected)
    core=sum(x["total_us"] for x in selected)
    quant=sum(x["total_us"] for x in rows if "MUL_MAT" in x["op"] and "q8_0" in x["op"])
    tables.append({"context":len(tables),"total_timestamp_us":whole,"attention_core_us":core,
     "attention_core_fraction_in_instrumented_gpu_subtotal":core/whole,
     "quantized_matvec_us":quant,"quantized_matvec_fraction_in_instrumented_gpu_subtotal":quant/whole,"rows":rows})
assert len(tables)==3
# Require same frozen artifacts after execution.
for runroot in [bridge,root]:
    for x in read(runroot/"BUILD_MANIFEST.json")["files"]:assert sha(pathlib.Path(x["path"]))==x["sha256"]
receipt=read(root/"BUDGET_LEDGER.json")
failure=read(failed/"BUDGET_LEDGER.json")
assert receipt["status"]=="PROFILE_AND_CLEAN_COMPLETED"
report={"status":"ANALYSIS_COMPLETE","gpu_execution":False,"complete_logit_arrays_checked":len(allchecks),
 "logit_values_per_array":allchecks[0]["bytes"]//4,"checks":allchecks,"runs":runs,
 "geometry":{"Hq":32,"Hkv":8,"d":128,"physical_key":256,"query":1,"layers":36,"prompt_tokens":124,"generated_tokens":16},
 "calibration_ratios":ratios,"coarse_calibration_pass":calibration,"threshold":"All three ratios in [0.90,1.10], frozen before PROFILE",
 "profile_tables":tables,
 "attribution_status":"INSTRUMENTED_GPU_SUBTOTAL_ONLY; NOT_NATURAL_REQUEST_CRITICAL_PATH",
 "limitations":["one previously exposed prompt","one device/date","only15 dependent decode steps per process","clean baseline already observed at preregistration","no inference of bandwidth or compute limit from op labels","timestamp logger inserts barriers; coarse median gate cannot calibrate per-op perturbations"],
 "failed_attempt_charged_seconds":failure["sessions"][0]["charged_seconds"],
 "cumulative_charged_seconds":receipt["cumulative_charged_seconds"],"remaining_seconds":receipt["remaining_seconds"],
 "decision":"No q2/q4 mapping is exercised by this reference request. Preserve QB baseline; do not prioritize attention mapping hardware from these results."}
(root/"ANALYSIS.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps({k:v for k,v in report.items() if k not in ["checks","profile_tables","limitations"]},indent=2))
print(json.dumps([{"context":t["context"],"attention_fraction":t["attention_core_fraction_in_instrumented_gpu_subtotal"],"q8_matvec_fraction":t["quantized_matvec_fraction_in_instrumented_gpu_subtotal"]} for t in tables],indent=2))
