from pathlib import Path
import hashlib,runpy,sys,json
p=Path(__file__).resolve().parent
plan=p/"QUALIFICATION_PLAN_001.json"
assert hashlib.sha256(plan.read_bytes()).hexdigest()=="182f76f5251cf1ac7e7629e096a33a4258af051e3ad7eb84975a4dc0d5baa783"
for row in json.loads(plan.read_bytes())["controller_inputs"]:
 assert hashlib.sha256(Path(row["path"]).read_bytes()).hexdigest()==row["sha256"]
sys.argv=[str(p/"runner-v6.py"),str(plan)]
runpy.run_path(str(p/"runner-v6.py"),run_name="__main__")
