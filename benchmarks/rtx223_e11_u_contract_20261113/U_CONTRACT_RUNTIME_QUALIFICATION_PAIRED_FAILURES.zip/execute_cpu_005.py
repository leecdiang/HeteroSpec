from pathlib import Path
import json,hashlib,runpy,sys
p=Path(__file__).resolve().parent
plan=p/'CPU_PLAN_005.json'
assert hashlib.sha256(plan.read_bytes()).hexdigest()=='4f0c774e7eb2bc9e89d69ea69658d45f326c574d07b285f74eb4447a40173d18'
for row in json.loads(plan.read_bytes())['controller_inputs']:
 assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256']
runpy.run_path(str(p/'create_profile_002.py'),run_name='__main__')
sys.argv=[str(p/'runner_v5.py'),str(plan)]
runpy.run_path(str(p/'runner_v5.py'),run_name='__main__')
