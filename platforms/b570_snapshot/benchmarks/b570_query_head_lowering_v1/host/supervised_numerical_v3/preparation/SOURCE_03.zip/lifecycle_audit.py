"""Reconstruct real monitoring intervals; never apply v3 to old receipts."""
from legacy import load,sha,need
from timing import Coverage
from workers import rows

def audit(folder):
    life=load(folder/'LIFECYCLE.json')
    need(life.get('schema')=='SUPERVISION_V3','only new v3 receipts accepted; no legacy reclassification')
    commit=load(folder/'RECEIPT_COMMITTED.json')
    need(life['stop'] is None and life['returncode']==0 and life['GO_sent'] and life['post_audit_success'],'failed process/supervision/output audit')
    begin,exit_ns=life['launch_begin_ns'],life['exit_observed_ns']
    need(begin<=life['spawn_returned_ns']<=exit_ns<=life['post_audit_begin_ns']<=life['post_audit_end_ns']<=life['lifecycle_write_begin_ns']<=commit['lifecycle_write_completed_ns'],'ordered explicit phase boundaries')
    need(sha(folder/'LIFECYCLE.json')==commit['lifecycle_sha256'],'committed lifecycle identity')
    exit_record=load(folder/'EXIT_OBSERVED.json');need(exit_record['exit_observed_ns']==exit_ns,'actual exit confirmation record')
    need(life['creation_FILETIME']==life['process_times']['creation_FILETIME'] and life['process_times']['exit_FILETIME']>0,'OS lifecycle evidence')
    coverage=Coverage(begin)
    for row in rows(folder/'MONITOR.jsonl'):coverage.event(row,exit_ns)
    result=coverage.terminal(exit_ns);need(result==life['coverage'],'independent interval reconstruction')
    need(len(life['control_processes'])==2 and all(p['returncode']==0 for p in life['control_processes']),'CPU control process cleanup')
    need((folder/'POST_AUDIT.json').exists() and (folder/'GATE_MODULES.json').exists() and (folder/'CLOSING_MODULES.json').exists(),'mandatory independent identity/output audit artifacts')
    need(life['post_exit_audit_seconds']==(life['post_audit_end_ns']-life['post_audit_begin_ns'])/1e9,'separate audit clock')
    return dict(coverage=result,observed_native_lifetime_seconds=(exit_ns-begin)/1e9,
        post_exit_audit_seconds=life['post_exit_audit_seconds'],engineering_seconds_before_commit=commit['slot_engineering_seconds_before_commit'])
