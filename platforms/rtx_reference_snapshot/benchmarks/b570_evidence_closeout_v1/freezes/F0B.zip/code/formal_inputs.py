from common import *
sys.path.insert(0,str(REPO/'scripts/platform/b570_evidence_closeout_v1'))
import closeout
selected=load(R/'COHORT_SELECTION.json')['selected'];audit=load(R/'HISTORY_AUDIT_COMPLETE.json')
bins=R/'tokenizer/bin';bins.mkdir(parents=True,exist_ok=True)
src=Path('C:/hs/jsa-b570-run-v1/tokenizer-build/Release')
for p in src.iterdir():
 if p.suffix in ['.exe','.dll']:shutil.copy2(p,bins/p.name)
shutil.copy2(Path('C:/hs/b570-evidence-pr88-restored-v1/recovery_tools/tokenizer/tokenizer.cpp'),bins.parent/'tokenizer.cpp')
deps=Path('C:/hs/jsa-b570-run-v1/python-deps')
for name in ['jinja2','markupsafe']:
 shutil.copytree(deps/name,R/'tokenizer/python-deps'/name,dirs_exist_ok=True)
sys.path.insert(0,str(R/'tokenizer/python-deps'))
from jinja2 import Environment,StrictUndefined
v=json.loads((R/'vocab/Llama_target_Q6_K.jsonl').read_text().splitlines()[0])
env=Environment(undefined=StrictUndefined);env.globals['raise_exception']=lambda msg:(_ for _ in ()).throw(RuntimeError(msg));template=env.from_string(v['chat_template'])
token=lambda i:bytes.fromhex(v['table'][i]['text_hex']).decode('utf8')
def formatted(raw):return template.render(messages=[dict(role='user',content=raw)],add_generation_prompt=True,bos_token=token(v['bos']),eos_token=token(v['eos']))
rows=[]
for t in selected:
 raw=('Complete the following Python programming task. Return only the completed Python code, without Markdown fences.\n\n' if t['domain']=='MBPP' else 'Solve the following math problem. Show your reasoning and give the final answer.\n\n')+t['description']
 rows.append(dict(id=t['id'],raw_prompt=raw,formatted_prompt=formatted(raw),cap=128))
exe=bins/'b570-tokenizer.exe';model=Path('C:/hs/b570-mem-run-v1/models/Meta-Llama-3.1-8B-Instruct-Q6_K.gguf')
assert sha(model)==load(DOC/'DESIGN.json')['assets']['Llama']['models']['target']['sha256']
q=subprocess.run([str(exe),str(model)],input=''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in rows).encode(),capture_output=True,creationflags=subprocess.CREATE_NO_WINDOW,cwd=bins)
(R/'FORMAL_TOKENIZER.stdout.jsonl').write_bytes(q.stdout);(R/'FORMAL_TOKENIZER.stderr.log').write_bytes(q.stderr);assert q.returncode==0
native=[json.loads(line) for line in q.stdout.splitlines()];assert native[0]==v
for t,x in zip(rows,native[1:],strict=True):
 assert t['id']==x['id'] and x['forward_calls']==0
 t['prompt_ids']=x['prompt_ids'];assert 0<len(t['prompt_ids'])<=768
 for key in ['raw_prompt','formatted_prompt']:
  t[key+'_sha256']=hashlib.sha256(t[key].encode()).hexdigest()
 t['prompt_ids_sha256']=hashlib.sha256(json.dumps(t['prompt_ids'],separators=(',',':')).encode()).hexdigest()
ha={k:audit[k] for k in ['completed','by_id_and_description','unknown_hosts_disclosed','training_unseen_claim','excluded_ids']}
ha['evidence_sha256']=sha(R/'HISTORY_AUDIT_COMPLETE.json')
value=dict(study_id='b570_evidence_closeout_v1',tasks=[{k:t[k] for k in ['id','domain','description','selection_hash']} for t in selected],families=dict(Llama=rows),history_audit=ha,forwards=0,target_template_sha256=hashlib.sha256(v['chat_template'].encode()).hexdigest(),tokenizer_binary_sha256=sha(exe))
save(R/'CONFIRMATION_INPUTS.json',value)
plan=closeout.schedule(load(DOC/'DESIGN.json'),value);save(R/'FORMAL_PLAN.json',plan)
save(R/'TOKENIZER_BINDING.json',dict(status='PASS_NATIVE_VOCAB_ONLY_24',native_forward_calls=0,owned_gpu_units=0,source_sha256=sha(bins.parent/'tokenizer.cpp'),runtime=[dict(path=str(p.relative_to(R)).replace('\\','/'),sha256=sha(p)) for p in bins.iterdir()],jinja_source_files=[dict(path=str(p.relative_to(R)).replace('\\','/'),sha256=sha(p)) for p in (R/'tokenizer/python-deps').rglob('*.py')],native_stdout_sha256=sha(R/'FORMAL_TOKENIZER.stdout.jsonl'),max_prompt_ids=max(len(t['prompt_ids']) for t in rows),native_template_inherited_add_bos=True,double_bos_matches_PR88=True))
print('24 new frozen inputs and1200 request plan generated',[t['id'] for t in rows],flush=True)
