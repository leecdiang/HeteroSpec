#include <windows.h>
#include <stdexcept>
#include <climits>
static void need(bool v,const char*s){if(!v)throw std::runtime_error(s);}
static unsigned used=0,limit=0;static ULONGLONG deadline=0;
extern "C" void e10_reserve(unsigned n,const char*) {
    need(n&&used<=limit&&n<=limit-used,"explicit budget refused before dispatch");
    need(GetTickCount64()<deadline,"prelaunch deadline reached");used+=n;
}

int main(){limit=14;deadline=GetTickCount64()+10000;for(int i=0;i<14;++i)e10_reserve(1,"CPU");try{e10_reserve(1,"CPU");return 1;}catch(const std::exception&){}used=0;deadline=GetTickCount64()-1;try{e10_reserve(1,"CPU");return 2;}catch(const std::exception&){}if(used)return 3;deadline=GetTickCount64()+10000;try{e10_reserve(UINT_MAX,"CPU");return 4;}catch(const std::exception&){}return 0;}