AUTHOR-REVIEW SOURCES: not a submitted or final author-approved manuscript.
All TeX inputs, figures, class/style files and bibliography are at this level.
Use a complete TeX Live installation. Build each document with pdflatex.
For main/supplement: pdflatex, bibtex, pdflatex, pdflatex.
The included .bbl files also support builds without rerunning BibTeX.
Numeric citations use the standard TeX Live unsrtnat style.
The official CAS files are unchanged; their complete original distribution
and license notices are in the companion author-review package.
Final author declarations and data deposit/access terms remain pending.
