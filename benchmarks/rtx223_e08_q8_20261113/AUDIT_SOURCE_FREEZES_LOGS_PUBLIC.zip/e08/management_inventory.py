"""Read-only target-device occupancy and module delta. No CUPTI, numerical root or CUDA API."""
import sys,ctypes as C,json,os
from pathlib import Path
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'attempt-002'))
import observation as o
def modules():
 k=C.WinDLL('kernel32',use_last_error=True)
 snap=o.function(k,'CreateToolhelp32Snapshot',o.W.HANDLE,o.W.DWORD,o.W.DWORD)(0x18,os.getpid())
 if snap==o.W.HANDLE(-1).value:raise RuntimeError('snapshot')
 first=o.function(k,'Module32FirstW',o.W.BOOL,o.W.HANDLE,C.POINTER(o.Module))
 nxt=o.function(k,'Module32NextW',o.W.BOOL,o.W.HANDLE,C.POINTER(o.Module))
 close=o.function(k,'CloseHandle',o.W.BOOL,o.W.HANDLE)
 m=o.Module();m.size=C.sizeof(m);items=[]
 try:
  if not first(snap,C.byref(m)):raise RuntimeError('first')
  while True:
   items.append(m.path)
   if not nxt(snap,C.byref(m)):
    if C.get_last_error()!=18:raise RuntimeError('incomplete')
    return sorted(items)
 finally:close(snap)
before=modules()
mg=o.Management(Path('C:/Windows/System32/nvml.dll'))
try:
 mg.start()
 sample=mg.sample(root)
 after=modules()
 result=dict(scope='authorized_readonly_management_inventory',before=before,after=after,delta=sorted(set(after)-set(before)),sample=sample,temperature=mg.temperature,cupti_loads=0,numeric_root_loads=0,cuda_api_calls=0,physical_work='UNKNOWN')
 with (root/'MANAGEMENT_IMAGE_DELTA.json').open('x',encoding='utf8') as f:json.dump(result,f,indent=2)
finally:mg.close()
