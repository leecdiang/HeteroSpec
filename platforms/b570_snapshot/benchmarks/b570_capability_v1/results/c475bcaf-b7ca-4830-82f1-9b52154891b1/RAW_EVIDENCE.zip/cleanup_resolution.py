import ctypes as C,json,os,sys,time
from ctypes import wintypes as W
from pathlib import Path
root=Path(sys.argv[1]);k=C.WinDLL('kernel32',use_last_error=True)
class FT(C.Structure):_fields_=[('low',W.DWORD),('high',W.DWORD)]
k.OpenProcess.argtypes=[W.DWORD,W.BOOL,W.DWORD];k.OpenProcess.restype=W.HANDLE
k.WaitForSingleObject.argtypes=[W.HANDLE,W.DWORD];k.WaitForSingleObject.restype=W.DWORD
k.GetProcessTimes.argtypes=[W.HANDLE,C.POINTER(FT),C.POINTER(FT),C.POINTER(FT),C.POINTER(FT)]
k.CloseHandle.argtypes=[W.HANDLE]
events=[json.loads(s) for s in (root/'development/r0-a1/WATCHDOG.jsonl').read_text().splitlines()]
known=[r for r in events if r['event'] in ['WATCHDOG_START','SUPERVISOR_CREATED_SUSPENDED','RESIDUAL_RETAINED']]
result=[]
for r in known:
    h=k.OpenProcess(0x101000,False,r['pid'])
    if not h:
        error=C.get_last_error();state='NO_SUCH_PID' if error==87 else 'UNKNOWN';result.append(dict(pid=r['pid'],created_filetime=r['created_filetime'],state=state,win32_error=error));continue
    try:
        ts=[FT() for _ in range(4)]
        if not k.GetProcessTimes(h,*[C.byref(t) for t in ts]):raise C.WinError(C.get_last_error())
        created=str((ts[0].high<<32)|ts[0].low);exited=str((ts[1].high<<32)|ts[1].low)
        state='OLD_IDENTITY_GONE_PID_REUSED' if created!=r['created_filetime'] else 'SIGNALED_EXIT' if k.WaitForSingleObject(h,0)==0 and int(exited)>0 else 'LIVE_OR_UNKNOWN'
        result.append(dict(pid=r['pid'],created_filetime=r['created_filetime'],current_created_filetime=created,exit_filetime=exited,state=state))
    finally:k.CloseHandle(h)
out=dict(query_pid=os.getpid(),at_ns=time.perf_counter_ns(),identities=result,all_known_not_live=all(r['state'] in ['NO_SUCH_PID','OLD_IDENTITY_GONE_PID_REUSED','SIGNALED_EXIT'] for r in result),scope='Read-only post-failure closure resolution; does not manufacture missing historical exit times or upgrade failed attempt')
with (root/'development/r0-a1/CLEANUP_RESOLUTION.json').open('x') as f:json.dump(out,f,indent=2);f.write('\n')
print(json.dumps(out));sys.exit(0 if out['all_known_not_live'] else 1)
