"""Freeze restricted staging/controller; no profile creation, CUDA or ACL writes."""
from pathlib import Path
import json,hashlib,shutil,subprocess,datetime,os
p=Path(__file__).resolve().parent;study=p.parent;old=study/'rtx223-e10-fewrow'
sha=lambda q:hashlib.sha256(Path(q).read_bytes()).hexdigest()
def write(q,v):
 with q.open('x',encoding='utf8',newline='\n') as f:json.dump(v,f,indent=2)
build=json.loads((p/'build-001/BUILD.json').read_bytes());assert not build['input_changes'] and not build['unbound_dependencies'] and all(x['returncode']==0 for x in build['stages'])
stage=study/'rtx223-e07/staging-B1/e11-ucontract-001';stage.mkdir(exist_ok=False)
shutil.copy2(p/'build-001/operator-upstream.exe',stage/'operator-ucontract.exe')
oldstage=json.loads((old/'STAGING.json').read_bytes())
for name in ['weight.bin','activation.f32','backend-output.f32','activation_q8_1.bin']:shutil.copy2(Path(oldstage['stage'])/name,stage/name)
files=[]
for q in sorted(stage.iterdir()):files.append(dict(path=str(q),sha256=sha(q),bytes=q.stat().st_size,file_id=dict(volume=q.stat().st_dev,inode=q.stat().st_ino)))
write(p/'STAGING.json',dict(stage=str(stage),profile=oldstage['profile'],package=oldstage['package'],files=files,model_files_copied=0,ACL_changes=0))
dep=json.loads((old/'DEPLOYMENT.json').read_bytes());write(p/'DEPLOYMENT.json',dep)
s=(old/'runner.py').read_text().replace('Fresh C1 phase gate','Fresh e11 independent-contract phase gate').replace('rtx223-e10-fewrow','rtx223-e11-u-contract').replace('E10_UPSTREAM_DIAGNOSTIC','E11_U_CONTRACT').replace('e10_observation','e11_observation').replace('PASS_TWO_CONTRACT_DIAGNOSTIC','PASS_E11_TWO_CONTRACTS')
s=s.replace("need(granted and job.exit_code()==0,'native result failed/incomplete')", "need(granted,'native execution was not granted');native_exit=job.exit_code()")
s=s.replace("  if phase!='CPU':\n   result=json.loads", "  if phase!='CPU':\n   need(native_exit==0,'native result failed/incomplete;full ETW drain attempted first')\n   result=json.loads")
with (p/'runner.py').open('x',encoding='utf8',newline='\n') as f:f.write(s)
s=(old/'admin_controller.py').read_text().replace('Durable415-family','Durable500-family').replace('rtx223-e10-fewrow','rtx223-e11-u-contract').replace('RTX223-E10-FEWROW-Runner','RTX223-E11-UCONTRACT-Runner').replace('limit=415','limit=500').replace('reserved+n<=415','reserved+n<=500').replace('n in (14,355)','n in (14,416)').replace("seen=set();reserved=0","seen=set();reserved=0;qualification_attempts=0;timing_attempts=0")
s=s.replace("  hard=120 if kind=='NUMERICAL' else 30;", "  if kind=='NUMERICAL':\n   if n==14:\n    w.need(qualification_attempts<2 and timing_attempts==0,'qualification attempt limit/order');qualification_attempts+=1\n   else:\n    w.need(qualification_attempts>=1 and timing_attempts==0,'timing attempt limit/order');timing_attempts+=1\n  hard=120 if kind=='NUMERICAL' else 30;")
with (p/'admin_controller.py').open('x',encoding='utf8',newline='\n') as f:f.write(s)
s=(old/'create_profile.py').read_text().replace('Authorized independent upstream diagnostic','Authorized e11 independent U-contract diagnostic')
with (p/'create_profile.py').open('x',encoding='utf8',newline='\n') as f:f.write(s)
inputs=[p/x for x in ['runner.py','observation.py','Collect-Host.ps1','CONTRACT.json','STAGING.json','DEPLOYMENT.json','PARENT_REUSE_VERIFIED.json','PARENTS_VERIFIED.json','create_profile.py','u_oracle.hpp','NUMERICAL_CONTRACTS_ZH.md','oracle-cpu-001/RESULT.json','capture-cpu-001/RESULT.json','build-001/BUILD.json']]
inputs += [study/'rtx223-e08'/x for x in ['attempt-006/runner.py','attempt-006/winjob.py','build/PYTHON_INPUTS.json']]
plan=dict(phase='CPU',app_launch_reservation=0,receipt_dir='D:/HeteroSpec-PC/rtx223-e11-u-contract/cpu-001',output_dir=str(Path(oldstage['profile'])/'Temp/e11-cpu-001'),argv=[str(study/'rtx223-e07/staging-B1/cpu-probe.exe')],controller_inputs=[dict(path=str(q),sha256=sha(q)) for q in inputs])
write(p/'CPU_PLAN_001.json',plan)
entry=p/'execute_cpu_001.py';text="from pathlib import Path\nimport json,hashlib,runpy,sys\np=Path(__file__).resolve().parent\nplan=p/'CPU_PLAN_001.json'\nassert hashlib.sha256(plan.read_bytes()).hexdigest()=="+repr(sha(p/'CPU_PLAN_001.json'))+"\nfor row in json.loads(plan.read_bytes())['controller_inputs']:\n assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256']\nrunpy.run_path(str(p/'create_profile.py'),run_name='__main__')\nsys.argv=[str(p/'runner.py'),str(plan)]\nrunpy.run_path(str(p/'runner.py'),run_name='__main__')\n"
with entry.open('x',encoding='utf8',newline='\n') as f:f.write(text)
(p/'admin-queue').mkdir()
# CPU request is intentionally NOT queued until owned full-backend compilation ends.
write(p/'CPU_REQUEST_001.json',dict(script=str(entry),sha256=sha(entry),reservation=0,kind='CPU_ONLY'))
s=(old/'Launch-Controller.ps1').read_text().replace('Upstream few-row diagnostic only,415 independent explicit reservations','e11 independent U-contract operator diagnostic only,500 independent explicit reservations')
with (p/'Launch-Controller.ps1').open('x',encoding='utf8',newline='\n') as f:f.write(s)
release=inputs+[p/'admin_controller.py',entry,p/'Launch-Controller.ps1',p/'CPU_PLAN_001.json',p/'CPU_REQUEST_001.json',p/'build-001/operator-upstream.exe']
write(p/'CONTROL_RELEASE.json',dict(files=[dict(path=str(q),sha256=sha(q)) for q in release],scope='500 explicit,120s,one fixed device,extracted B/U only,CPU-first,no security/ACL changes',no_request_queued=True))
print(json.dumps(dict(staged_exe_sha256=sha(stage/'operator-ucontract.exe'),controller_sha256=sha(p/'admin_controller.py'),queue_empty=True)))
