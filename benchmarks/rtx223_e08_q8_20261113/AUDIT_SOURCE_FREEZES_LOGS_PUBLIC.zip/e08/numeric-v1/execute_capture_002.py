from pathlib import Path
import hashlib,runpy,sys,json
p=Path(__file__).resolve().parent
plan=p/"CAPTURE_PLAN_002.json"
assert hashlib.sha256(plan.read_bytes()).hexdigest()=="cafb8099634bc09f914732e21fa7137ef062c9bcd771eeb8889060590ed2389f"
for row in json.loads(plan.read_bytes())["controller_inputs"]:
 assert hashlib.sha256(Path(row["path"]).read_bytes()).hexdigest()==row["sha256"]
sys.argv=[str(p/"runner-v5.py"),str(plan)]
runpy.run_path(str(p/"runner-v5.py"),run_name="__main__")
