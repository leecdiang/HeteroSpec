DIAGNOSTIC REVISION -- v0.9.0
Build with pdfLaTeX: latexmk -pdf main.tex
Separate appendix: latexmk -pdf appendix.tex
Self-contained document dependencies and their hash manifest are included.
Evidence: anonymous-evidence-index-v0.9.0.zip, verify_v090.py for new
post-study extents/budgets; unchanged verify.py for earlier study replay.
Reproduction programs describe tested outputs, not a validated correction.
New ceilings are conditional arithmetic, not measured optimizations.
No models, network or measurement hardware are needed for these entries.
The hardware-only document is an internal section-removal proof.
Shared numerical routines and omitted state/assets constrain independence.
Old review scores are tied to old artifacts, not this edited version.
