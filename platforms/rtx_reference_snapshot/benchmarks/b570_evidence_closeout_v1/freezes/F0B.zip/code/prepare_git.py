import urllib.request,hashlib,zipfile,json,subprocess,os
from pathlib import Path
r=Path('C:/hs/b570-evidence-run-v1')
u='https://github.com/git-for-windows/git/releases/download/v2.56.0.windows.2/MinGit-2.56.0.2-64-bit.zip'
p=r/'tools/MinGit.zip'
with urllib.request.urlopen(u,timeout=30) as src,p.open('wb') as out:
 while b:=src.read(4*1024*1024):out.write(b)
h=hashlib.file_digest(p.open('rb'),'sha256').hexdigest();assert h=='da35e72aa21c005a5a0d298cfbae110bc1609a815730ea0dde84b01a1b3cd3be'
with zipfile.ZipFile(p) as z:assert z.testzip() is None;z.extractall(r/'tools/mingit')
g=r/'tools/mingit/cmd/git.exe'
q=subprocess.run([str(g),'--version'],capture_output=True,text=True,encoding='utf8');assert q.returncode==0,q.stderr
x=dict(url=u,sha256=h,bytes=p.stat().st_size,version=q.stdout.strip(),original_bundled_runtime_untouched=True,isolated_extracted_path=str(g))
(r/'GIT_TRANSPORT_TOOL.json').write_text(json.dumps(x,indent=2),encoding='utf8');print(q.stdout,flush=True)
