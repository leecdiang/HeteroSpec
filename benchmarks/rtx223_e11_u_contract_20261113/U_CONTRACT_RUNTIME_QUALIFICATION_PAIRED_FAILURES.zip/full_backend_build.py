"""CPU compilation only. Suppress CMake's CUDA ABI execution, not runtime isolation."""
from pathlib import Path
import json,os,hashlib,shutil,time,ctypes as C,importlib.util
p=Path(__file__).resolve().parent;study=p.parent
sha=lambda q:hashlib.file_digest(Path(q).open('rb'),'sha256').hexdigest()
out=p/'full-backend-001';out.mkdir(exist_ok=False);src=out/'src';shutil.copytree(p/'u',src)
recipe=json.loads((study/'rtx223-e10-fewrow/build-002/COMMANDS.json').read_bytes());env=recipe['environment'].copy();env['TEMP']=env['TMP']=str(out)
cmake=p/'tools/cmake-3.31.8-windows-x86_64/bin/cmake.exe';ninja=p/'tools/ninja/ninja.exe';nvcc=Path(recipe['commands'][0][1][0]);cl=Path(env['PATH'].split(';')[0])/'cl.exe'
env['PATH']=str(cmake.parent)+';'+str(ninja.parent)+';'+env['PATH']
# CMake 3.31 calls a CUDA ABI binary even for non-native target architectures.
# FORCED skips that test; nvcc identity/compile/link have independent evidence.
args=[str(cmake),'-S',str(src),'-B',str(out/'build'),'-G','Ninja','-DCMAKE_MAKE_PROGRAM='+str(ninja),'-DCMAKE_BUILD_TYPE=Release','-DCMAKE_C_COMPILER='+str(cl),'-DCMAKE_CXX_COMPILER='+str(cl),'-DCMAKE_CUDA_COMPILER='+str(nvcc),'-DCMAKE_CUDA_HOST_COMPILER='+str(cl),'-DCUDAToolkit_ROOT='+str(nvcc.parent.parent),'-DCMAKE_CUDA_ARCHITECTURES=120a-real','-DCMAKE_CUDA_COMPILER_FORCED=TRUE','-DGGML_NATIVE=OFF','-DGGML_CUDA=ON','-DLLAMA_BUILD_TESTS=OFF','-DLLAMA_BUILD_EXAMPLES=OFF','-DLLAMA_BUILD_TOOLS=OFF','-DLLAMA_BUILD_SERVER=OFF','-DLLAMA_CURL=OFF','-DGGML_CCACHE=OFF']
inputs={str(q):dict(sha256=sha(q),bytes=q.stat().st_size) for folder in [src,p/'tools/cmake-3.31.8-windows-x86_64',p/'tools/ninja'] for q in folder.rglob('*') if q.is_file()}
inputs[str(Path(__file__))]=dict(sha256=sha(__file__),bytes=Path(__file__).stat().st_size)
(out/'INPUTS.json').write_text(json.dumps(inputs,indent=2),encoding='utf8')
sp=importlib.util.spec_from_file_location('job',study/'rtx223-e08/attempt-006/winjob.py');w=importlib.util.module_from_spec(sp);sp.loader.exec_module(w)
def run(argv,name,seconds):
 job=w.AtomicJob();lim=w.EXTENDED_LIMIT();lim.BasicLimitInformation.LimitFlags=0x2000|0x100|0x8;lim.BasicLimitInformation.ActiveProcessLimit=32;lim.ProcessMemoryLimit=12*1024**3;w.checked(w.SetJob(job.job,9,C.byref(lim),C.sizeof(lim)),'CPU build own Job')
 start=time.monotonic();timedout=False
 try:
  job.create(argv,out,env);job.resume()
  with (out/(name+'.stdout.log')).open('xb') as a,(out/(name+'.stderr.log')).open('xb') as b:
   while job.exit_code() is None:
    for fd,f in [(job.output,a),(job.error,b)]:
     part=job.read(fd)
     if part:f.write(part)
    if time.monotonic()-start>seconds:job.kill();timedout=True
    time.sleep(.02)
   for fd,f in [(job.output,a),(job.error,b)]:
    while True:
     part=job.read(fd)
     if not part:break
     f.write(part)
  rc=job.exit_code();active=job.active()
  return dict(stage=name,argv=argv,returncode=rc,seconds=time.monotonic()-start,timedout=timedout,owned_active_at_exit=active)
 finally:job.close()
results=[run(args,'configure',120)]
if results[0]['returncode']==0:results.append(run([str(cmake),'--build',str(out/'build'),'--target','ggml-cuda','--parallel','2'],'build',900))
changes=[q for q,row in inputs.items() if sha(q)!=row['sha256']]
new=[str(q.relative_to(src)) for q in src.rglob('*') if q.is_file() and str(q) not in inputs]
report=dict(stages=results,preexisting_input_changes=changes,new_generated_source_files=new,CUDA_initializations=0,numerical_library_loads=0,application_kernel_calls=0,backend_run='NOT_RUN',default_runtime='NOT_MEASURED',CPU_Job='kill-on-close32processes,12GiBperprocess,2compile jobs',CMake_CUDA_ABI_autoprobe='explicitly bypassed with CMAKE_CUDA_COMPILER_FORCED;source native helper never executed',configuration='single sm120a build,GGML_NATIVE OFF;runtime PDL/graph defaults unchanged',source_commit='0fb8f157702702f33f4e018de8701b2569a1bc28')
(out/'RESULT.json').write_text(json.dumps(report,indent=2),encoding='utf8');print(json.dumps(report,indent=2))
