# Anonymous B570 reserved-sequence supplement

This package contains the 24 reserved HumanEval task IDs, three runs per task, and complete generated-token-ID arrays for the frozen UB1 predictor, UB128 reference, and live serialized path. The ID endpoint is capped at 128 generated IDs or an earlier inclusive EOG. It contains no experiment commands, host names, source paths, repository identifiers, absolute timestamps, prompt text, or user information.

Run `python3 verify.py` in this directory. It independently recomputes compact-array SHA-256 digests, all 72 complete predicted/live equalities, 60 reference/live equalities, 24 prompt classifications, the four reference-divergent tasks, and their 12 first-divergence positions. This is a deterministic audit of existing arrays, not a new model run.

The prediction-file SHA-256 in the paper identifies the original frozen file. Sanitization changes its bytes, so this package cannot recreate that file-level digest or independently prove when that file was frozen. The paper reports the recorded chronology separately.
