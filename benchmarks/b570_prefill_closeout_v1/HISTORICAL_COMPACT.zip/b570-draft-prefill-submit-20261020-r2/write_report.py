from pathlib import Path
import json
r=Path(__file__).parent
def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
a=read(r/"ANALYSIS.json");s=read(r/"STAGE_SUMMARY.json");l=read(r/"BUDGET_LEDGER.json")
old=read(Path(str(r).removesuffix("-r2"))/"BUDGET_LEDGER.json")
table="\n".join(f'| {x["input_id"]} | {100*(1-x["service_BULK1_over_dualBASE"]):+.3f}% | {100*(x["service_BASEA_over_BASEB"]-1):+.3f}% |'for x in a["per_input"])
passed=a["decision"]=="PRACTICAL_FINITE_PANEL_SCREEN_PASS"
disposition=("The candidate passes the declared two-input practical screen. Retain it as a qualified candidate for these inputs; broader cost confirmation is still required."if passed else"The candidate does not establish a practical request-cost improvement. Retain the original software baseline and preserve this negative result; do not advertise submission batching as a speedup.")
text=f"""# Exact-reference draft prefill submission result

**{a["decision"]}**

The candidate replaces one draft llama_decode call per prompt token with one logical prompt batch. The physical microbatch remains1, threads8, original GPU arithmetic/DLLs, weights, target prefill, verification, sampling and state protocol. Only the last prompt token produces logits. This is API submission batching, not q>1 draft arithmetic.

## Admission and preserved failure

Original reference: PR134 `51febaddcf49bb18565e568cf964a6e5c78876c9`. Study preregistration: `d1e52cf07cddd31e5f06e5d09f77c63ee63988be`; observer repair registered before retry in `55797f3a3ce7ba2965aded609d7ca68ac24323eb`; complete qualification and estimator committed before timing in `e44c4df04c895b55ef734ee7b0659189158f95ab`.

Attempt1 failed its shape assertion, exited normally with code2 and was not timed. Its Qcur prefix also matched permuted views and mistook the16-head axis for query count. Its97 produced raw vectors matched in an offline diagnostic, but no PASS was transferred.

Attempt2 reads query axis1 of consumed kq MUL_MAT nodes and persists Qcur/kq shapes before checking. All four original inputs pass afresh: **346 complete target/draft logits vectors byte-identical to PR134 QB**, including rejected verification rows; complete IDs, EOG flags, length, terminal token, stop reason and speculative cycle traces identical. Observed draft prefill q=1. No mathematical reference change or tolerance relaxation.

## Complete request-cost screen

Two inputs were chosen prospectively: HumanEval/38 (181 prompt tokens,64-token CAP) and HumanEval/115 (349 prompt tokens,41-token EOG). Three independent native processes, three balanced arm orders, **18 measured requests and9 separate warmups**. BASE_A and BASE_B are the same original QB implementation. BULK1 is the submission candidate. Every timed endpoint and state trace matches the original reference; timed requests do not record full logits or install observers.

| Fixed input | BULK1 service reduction vs dual-BASE | BASE_A / BASE_B imbalance |
|---|---:|---:|
{table}

Equal-input geometric mean service ratio: **{a["service_BULK1_over_dualBASE"]:.8f}**, reduction **{100*(1-a["service_BULK1_over_dualBASE"]):+.4f}%**.
Request-only ratio: **{a["request_BULK1_over_dualBASE"]:.8f}**.
Largest input-aggregate A/A imbalance: **{100*a["largest_aggregate_AA_imbalance"]:.4f}%**.
Declared screen: improvement greater than max(2%, A/A imbalance) and a lower cost in every session aggregate. Threshold **{100*a["threshold"]:.4f}%**; session ratios `{a["per_session_ratios"]}`.

No sample exclusion, significance-based stopping or population confidence interval. Qualification covers four inputs; cost evidence covers only these two. There is no contemporaneous R arm in this screen, so no new target-only net-benefit claim is made.

## Cost location

Descriptive synchronized host-phase means over the same measured requests:

- Draft prefill dual-BASE **{s["draft_prefill_BASE_seconds"]:.6f}s**, BULK1 **{s["draft_prefill_BULK1_seconds"]:.6f}s**, reduction **{100*s["draft_prefill_reduction"]:+.3f}%**.
- BULK1 total draft prefill/decode **{s["draft_decode_plus_prefill_BULK1_seconds"]:.6f}s**.
- Target verification dual-BASE **{s["target_verify_BASE_seconds"]:.6f}s**, BULK1 **{s["target_verify_BULK1_seconds"]:.6f}s**.

These phase fields locate cost but do not isolate API setup, synchronization, scheduler reuse, driver overhead or a hardware throughput limit. The separate CPU-policy screen found no practical improvement from changing draft thread parameters8 to1. Its four-input/64-request result remains separate.

**Disposition:** {disposition}

## Cost boundary and limitations

Primary service includes fresh context construction/reservation, both prefills, generation, logits/sampling, state handling, synchronization and context teardown. Shared model load is separately recorded and excluded; validation/file writing follows the service timer. Qualification timings are not performance samples. No production cold-start, cache-residency guarantee, background exclusivity or general workload claim.

This narrows two software hypotheses. It does not establish a strong-software ceiling or justify hardware solely from the residual draft cost. A future reference-preserving query-parallel prefill implementation would be a separate candidate requiring its own full-byte admission; it is not implemented or inferred here.

## Evidence and accounting

Attempt2 retained346 raw logits files; failed attempt1 retained97. Compact archives contain results, shape evidence, logs and process receipts. Full raw archives remain on the local platform with SHA256/size manifests; they are not publicly hosted raw-data certification.

Attempt1 charge **{old["new_charged_seconds"]:.7f}s**, attempt2 **{l["new_charged_seconds"]:.7f}s**; submission study combined **{old["new_charged_seconds"]+l["new_charged_seconds"]:.7f}s** of the original1800-second envelope. Historical cumulative **{l["all_history_cumulative_seconds"]:.7f}s**, including prior studies and failed execution. No budget reset, actor, RTL, CPU8 expansion or merge.
"""
(r/"RESULT.md").write_text(text,encoding="utf-8")
(r/"PAPER_ADDENDUM.md").write_text(f"""# Software baseline counterfactuals after PR134

We evaluated two software-only interventions without changing the original floating-point reference. Changing draft CPU thread parameters from8 to1 preserved346 full target/draft logits vectors but increased four-input geometric-mean service cost by0.39935% in64 balanced requests; it did not pass the2% practical screen. Source inspection also showed that embedding GET_ROWS/SET_ROWS already request one CPU task, so the parameter change is not evidence of a changed active worker count.

Separately, combining draft prompt submissions into one logical API batch while retaining physical microbatch1 preserved346 vectors across all four inputs. In a prospectively selected two-input screen with18 measured requests,9 warmups, three independent processes and identical-code controls, its service ratio to the dual baseline was{a["service_BULK1_over_dualBASE"]:.6f} (reduction{100*(1-a["service_BULK1_over_dualBASE"]):+.3f}%). Draft prefill averaged{s["draft_prefill_BASE_seconds"]:.3f}s in the baseline and{s["draft_prefill_BULK1_seconds"]:.3f}s in the candidate. The declared screen returned {a["decision"]}.

These are bounded software counterfactuals, not a general software ceiling or a hardware opportunity claim. Service includes context lifetime and both prefills, but excludes shared model loading. The original failed shape observer is retained; its repair changed instrumentation only. Fixed exposed inputs, one platform/date and the smaller submission cost panel limit inference. Do not pool these timings with PR134 or RTX results.
""",encoding="utf-8")
print(text[:4500])
