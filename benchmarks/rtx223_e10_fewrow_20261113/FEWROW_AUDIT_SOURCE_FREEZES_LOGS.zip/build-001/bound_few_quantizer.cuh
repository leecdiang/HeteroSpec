template <mmq_q8_1_ds_layout ds_layout>
static __global__ void quantize_mmq_few_q8_1(
        const float * x_ptr, void * vy_ptr, const int64_t ne00, const int64_t s01, const int64_t s02, const int64_t s03,
        const int ne1, const int ne2) {
    ggml_cuda_pdl_lc();
    const float * GGML_CUDA_RESTRICT x  = x_ptr;
    int4        * GGML_CUDA_RESTRICT vy = (int4 *) vy_ptr;
    const int64_t i0 = ((int64_t)blockDim.x*blockIdx.y + threadIdx.x)*4;

    if (i0 >= ne00) {
        return;
    }
    ggml_cuda_pdl_sync();

    const int64_t i2 = blockIdx.z % ne2;
    const int64_t i3 = blockIdx.z / ne2;
    const float4  xi = (int) blockIdx.x < ne1 ? *(const float4 *) (x + i3*s03 + i2*s02 + blockIdx.x*s01 + i0) : make_float4(0.0f, 0.0f, 0.0f, 0.0f);

    // the 32 values of a sub-block are held by 8 threads
    float amax = fmaxf(fmaxf(fabsf(xi.x), fabsf(xi.y)), fmaxf(fabsf(xi.z), fabsf(xi.w)));
    amax = warp_reduce_max<8>(amax);

    const float d_inv = 127.0f / amax;
    char4 q;
    q.x = roundf(xi.x*d_inv);
    q.y = roundf(xi.y*d_inv);
    q.z = roundf(xi.z*d_inv);
    q.w = roundf(xi.w*d_inv);
    const float d = 1.0f / d_inv;

    // as in quantize_mmq_q8_1: the sum of the quantized values; the int warp_reduce_sum reduces the whole warp on Ampere+
    [[maybe_unused]] float sum = 0.0f;
    if constexpr (ds_layout != MMQ_Q8_1_DS_LAYOUT_D4) {
        sum = d*warp_reduce_sum<8>(float(q.x + q.y + q.z + q.w));
    }

    const int s = i0 % QK_K / QK8_1;          // sub-block
    const int k = i0 % QK8_1;                 // first value in sub-block
    const int g = blockIdx.x % MMQ_FEW_NCOLS; // column in group
    int4 * yg = vy + ((blockIdx.z*(ne00/QK_K) + i0/QK_K)*(gridDim.x/MMQ_FEW_NCOLS) + blockIdx.x/MMQ_FEW_NCOLS)*MMQ_FEW_Q8_1_INT4;
    ((int *) (yg + (s/2)*WARP_SIZE + 4*g + (k % 16)/4))[2*(s % 2) + k/16] = *(const int *) &q;
    if (k == 0) {
        int4 * ds = yg + 4*WARP_SIZE + 4*(g/2) + s/2;
        if constexpr (ds_layout == MMQ_Q8_1_DS_LAYOUT_D4) {
            ((float *) ds)[2*(s % 2) + g % 2] = d;
        } else {
            ((half2 *) ds)[2*(s % 2) + g % 2] = make_half2(d, sum);
        }
    }
}
