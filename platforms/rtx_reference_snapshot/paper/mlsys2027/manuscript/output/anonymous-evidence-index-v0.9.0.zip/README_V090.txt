V0.9.0 EXTENSION -- POST-STUDY DIAGNOSTICS
Run python3 -B verify_v090.py for new retained-record analysis.
It checks the extended manifest and calculates trajectory extents,
358H prompt-estimator ceilings and M4 two-fixed-mode opportunity.
All 30 prior v0.8.8 members retain their original bytes. Their verify.py
is available for full prior replay, but was not rerun in this revision.
Outcomes were known. No new inference, samples, bootstrap or intervals.
Positions/repeats are correlated. 358H budgets fix baseline/work/progress
and assume zero other cost; no optimization is achieved.
RTX hindsight array selection is not a predictor; the M4 two-mode
comparison does not bound arbitrary within-request switching.
No raw KV/sampler, omitted binaries or trusted time are authenticated.
The old README/INDEX/hash list identify prior scope; this extension uses
INDEX_V090.json and SHA256SUMS_V090.json.
