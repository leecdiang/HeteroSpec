from pathlib import Path
import json,hashlib,sys,runpy
p=Path(__file__).resolve().parent
plan=p/'TIMING_PLAN_003.json'
assert hashlib.sha256(plan.read_bytes()).hexdigest()=='3b2188880699ab0f33199c16b7e66719070ac76827e2e637a296f8354000c63c'
for row in json.loads(plan.read_bytes())['controller_inputs']:
 assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256']
sys.argv=[str(p/'runner_v5.py'),str(plan)]
runpy.run_path(str(p/'runner_v5.py'),run_name='__main__')
