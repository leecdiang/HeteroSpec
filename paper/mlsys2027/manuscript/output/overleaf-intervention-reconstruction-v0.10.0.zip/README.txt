INTERVENTION RECONSTRUCTION -- v0.10.0
Build: latexmk -pdf main.tex; latexmk -pdf appendix.tex
Self-contained document dependencies and SHA256SUMS.json included.
Separate anonymous-intervention-evidence-v0.10.0.zip: run python -B verify_v010.py.
It validates all endpoint-bounded intervention arrays, B570 untruncated
native captures and preserved historical cost arithmetic; it runs no models.
Distinct frozen descriptions predict the tested native interventions.
B570 restores its exposed cohort; RTX fails its recovery/no-regression target.
Prediction/reference/cost comparisons have separate contracts.
Source and full raw-audit provenance are in a separate author packet.
Shared numerical routines and omitted assets limit independent replication.
