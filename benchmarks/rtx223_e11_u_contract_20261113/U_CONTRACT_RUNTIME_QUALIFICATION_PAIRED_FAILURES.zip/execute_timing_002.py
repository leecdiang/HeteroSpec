from pathlib import Path
import json,hashlib,sys,runpy
p=Path(__file__).resolve().parent
plan=p/'TIMING_PLAN_002.json'
assert hashlib.sha256(plan.read_bytes()).hexdigest()=='9f923e5ec500b08f742192495b677a91b3c555057176cfc31193ae36fd4fab58'
for row in json.loads(plan.read_bytes())['controller_inputs']:
 assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256']
sys.argv=[str(p/'runner_v4.py'),str(plan)]
runpy.run_path(str(p/'runner_v4.py'),run_name='__main__')
