from pathlib import Path
import hashlib,runpy,sys,json
p=Path(__file__).resolve().parent
plan=p/"CPU_PLAN_004.json"
assert hashlib.sha256(plan.read_bytes()).hexdigest()=="02fba1f35f9267bf3285128ee4cfcc37092448512899486a5fa60c5a8d5edb58"
for row in json.loads(plan.read_bytes())["controller_inputs"]:
 assert hashlib.sha256(Path(row["path"]).read_bytes()).hexdigest()==row["sha256"]
sys.argv=[str(p/"runner-v4.py"),str(plan)]
runpy.run_path(str(p/"runner-v4.py"),run_name="__main__")
