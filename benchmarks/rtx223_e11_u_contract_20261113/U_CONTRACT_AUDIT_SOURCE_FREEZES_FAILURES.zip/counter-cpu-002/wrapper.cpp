extern "C" bool e11_reserve(unsigned,const char*) noexcept;
static unsigned fake=0;
extern "C" bool mock_dispatch() noexcept {if(!e11_reserve(1,"U_projection"))return false;++fake;return true;}
extern "C" unsigned mock_dispatch_count() noexcept{return fake;}
