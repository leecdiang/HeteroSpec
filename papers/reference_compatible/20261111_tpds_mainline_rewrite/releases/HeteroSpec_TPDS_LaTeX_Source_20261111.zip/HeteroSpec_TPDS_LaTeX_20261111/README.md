# TPDS LaTeX compilation source

This compact package contains the two document roots, all TeX inputs, bibliography,
IEEEtran class/style, generated table macros and vector figure PDFs.

Use a current TeX Live installation, including xr with its nocite option, and run:

```sh
bash build.sh --tex-only
```

The main paper must be built first because the supplement imports its figure
labels. The script compiles both PDFs in that order. Python is used only to check
the compilation logs. Use the full author package for numeric inputs, plotting
scripts, editable SVGs, PNG previews and review records. `bash build.sh` without
`--tex-only` is for that full package.
