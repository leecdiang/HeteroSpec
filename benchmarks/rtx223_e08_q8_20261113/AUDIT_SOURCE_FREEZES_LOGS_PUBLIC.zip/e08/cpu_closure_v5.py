"""Real restricted CPU probe plus process/image ETW, without NVML or any numerical DLL."""
import sys,json,hashlib,ctypes as C,os
from pathlib import Path
from datetime import datetime,timezone
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root.parent/'rtx223-e07/runner-v3'))
import runner as r
import observation as ob
def identity(path):
 p=Path(path).resolve(strict=True);st=p.stat()
 return dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=st.st_size,
             file_id=dict(volume=st.st_dev,inode=st.st_ino))
class CPUObserver(ob.Observer):
 def start(self):
  self.etw=ob.open_pinned(self.by_name['observation.dll']['path'])
  self.begin=ob.function(self.etw,'hs_trace_start',ob.W.DWORD)
  self.bind_trace=ob.function(self.etw,'hs_trace_bind',ob.W.DWORD,ob.W.DWORD)
  self.read_trace=ob.function(self.etw,'hs_trace_next',ob.W.DWORD,C.POINTER(ob.TraceRecord),ob.W.DWORD)
  self.end_trace=ob.function(self.etw,'hs_trace_stop',ob.W.DWORD,C.POINTER(ob.W.DWORD))
  self.health=ob.function(self.etw,'hs_trace_health',ob.W.DWORD)
  self.session=True
  ob.require(self.begin()==0,'ETW start failed')
 def _watermarks(self):pass
 def _image(self,raw):
  path=raw
  for device,drive in self.drives.items():
   if raw.casefold().startswith(device+'\\'):path=drive+raw[len(device):];break
  ob.require(os.path.isabs(path),'relative image')
  item=identity(path)
  self.discovered[item['path']]=item
  return item
 def checkpoint(self,stage):
  import time
  if stage=='METER':time.sleep(2)
  self.poll()
 def finish(self):
  lost=(ob.W.DWORD*3)()
  rc=self.end_trace(lost);self.session=False
  ob.require(rc==0 and not any(lost),'ETW incomplete')
  self._events()
  ob.require(self.counts[1]==self.counts[2]==1,'missing endpoints')
  return dict(valid=True)
out=root/'cpu-closure-005'
stage=root.parent/'rtx223-e07/staging-B1'
dll=root.parent/'rtx223-e07/etw/build-002/observation.dll'
manifest={'observation.dll':identity(dll)}
o=CPUObserver(dict(device_uuid=r.UUID,output_dir=str(out),manifest=manifest),lambda x:None)
o.discovered={}
log=r.Journal(out,dict(scope='CPU_RESTRICTED_IMAGE_DISCOVERY'))
o.emit=log.record
job=r.win.AtomicJob()
targets=r.protected_models()
plan=json.loads((root.parent/'rtx223-e07/acl/STAGING_APPLIED.json').read_bytes())
paths=[Path(x['path']) for x in plan['files'] if Path(x['path']).suffix.lower()=='.dll']
paths += [Path('C:/Windows/System32')/n for n in ('nvcuda.dll','nvml.dll')]
result=dict(scope='CPU_APPCONTAINER_ONLY',runner_context=r.runner_context(),observed_utc=r.win.utc(),package=r.PACKAGE,
 cpu_probe_sha256=identity(stage/'cpu-probe.exe')['sha256'],protected_model_paths=len(targets),readable_image_count=12,
 principal_model_read_denied=False,job_active_limit=1,pass_=False,management_library_loads=0,numerical_DLL_loads=0)
try:
 result['pass']=r.execute(job,log,o,[stage/'cpu-probe.exe'],stage,{'SystemRoot':'C:\\Windows','TEMP':plan['temp'],'TMP':plan['temp'],'LOCALAPPDATA':plan['profile']},'cpu-fake',work=10,hard=20,package=r.PACKAGE,protected=targets,readable_images=paths)=='COMPLETE'
 result['principal_model_read_denied']=result['pass']
finally:
 job.close();log.close()
 result['images']=list(o.discovered.values())
 result['counts']=o.counts
 with (root/'CPU_CLOSURE_005.json').open('x',encoding='utf8') as f:json.dump(result,f,indent=2)
print(json.dumps(result,indent=2))
