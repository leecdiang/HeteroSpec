"""Prepare one bounded continuation; no GPU launch or safety-policy relaxation."""
from pathlib import Path
import json,hashlib,importlib.util,copy
p=Path(__file__).resolve().parent;sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
def write(q,v):
 with q.open('x',encoding='utf8',newline='\n') as f:json.dump(v,f,indent=2)
s=(p/'observation.py').read_text();pos=s.index('\n\nclass Management:')
helper='''

def checked_watermarks(sample, baseline_used, pid, first):
    try:
        validate_watermarks(sample, baseline_used, pid, first)
    except Exception as exc:
        raise RuntimeError(str(exc) + "; observed_compute_pids=" + repr(sample[4]) + "; expected_owned_pid=" + str(pid)) from exc
'''
s=s[:pos]+helper+s[pos:]
s=s.replace('        validate_watermarks(first, self.baseline, 0, True)','        checked_watermarks(first, self.baseline, 0, True)')
s=s.replace('        validate_watermarks(first, first[2], 0, True)','        self.emit({"observer":"raw_compute_inventory","pids":first[4],"owned_pid":0})\n        checked_watermarks(first, first[2], 0, True)')
s=s.replace('                validate_watermarks(data, self.baseline, self.pid, False)','                checked_watermarks(data, self.baseline, self.pid, False)')
with (p/'observation_v2.py').open('x',encoding='utf8',newline='\n') as f:f.write(s)
s=(p/'runner_v3.py').read_text().replace("HERE/'observation.py'","HERE/'observation_v2.py'").replace("HERE/'CPU_SMOKE_PASS.json'","HERE/'CPU_SMOKE_PASS_V4.json'").replace("HERE/'runner_v3.py'","HERE/'runner_v4.py'")
with (p/'runner_v4.py').open('x',encoding='utf8',newline='\n') as f:f.write(s)
def module(name,path):
 sp=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);return m
old=module('old_ob',p/'observation.py');new=module('new_ob',p/'observation_v2.py');proof=module('proof',p/'continuation_proof.py')
G=1024**3;cases=[((12*G,11*G,G,30*G,[]),0,True),((12*G,11*G,G,30*G,[123]),0,True),((12*G,11*G,G,30*G,[123]),123,False),((12*G,11*G,G,30*G,[124]),123,False),((12*G,G,11*G,30*G,[]),123,False),((12*G,11*G,G,30*G,[0]),0,True)]
for sample,pid,first in cases:
 results=[]
 for fn in (old.validate_watermarks,new.checked_watermarks):
  try:fn(sample,0,pid,first);results.append(True)
  except RuntimeError:results.append(False)
 assert results[0]==results[1]
events=[json.loads(x) for x in Path('D:/HeteroSpec-PC/rtx223-e11-u-contract/family.jsonl').read_bytes().splitlines()];events.append(dict(kind='STOPPED',reserved=430))
attempt=[json.loads(x) for x in Path('D:/HeteroSpec-PC/rtx223-e11-u-contract/timing-001/attempt.jsonl').read_bytes().splitlines()]
native=json.loads((Path(json.loads((p/'STAGING_V3.json').read_bytes())['profile'])/'Temp/e11-qualification-001/result.json').read_bytes());digest=sha(p/'CONTRACT.json')
valid=proof.audit(events,attempt,native,digest)
negative=[]
mutated=copy.deepcopy(events);mutated[-1]['reserved']=0;negative.append((mutated,attempt))
mutated=copy.deepcopy(events);mutated.insert(-1,dict(kind='CONTINUATION_CLAIMED'));negative.append((mutated,attempt))
bad=copy.deepcopy(attempt);bad.insert(-1,dict(event=dict(kind='OWNED_SUSPENDED')));negative.append((events,bad))
bad=copy.deepcopy(attempt);bad[-1]['event']['owned_process_exit_confirmed']=False;negative.append((events,bad))
for e,a in negative:
 try:proof.audit(e,a,native,digest)
 except RuntimeError:pass
 else:raise RuntimeError('continuation negative test admitted')
write(p/'CONTINUATION_CPU_TESTS.json',dict(pass_=True,watermark_policy_identical=True,watermark_cases=len(cases),negative_budget_proof_cases=len(negative),positive_proof=valid,CUDA_initializations=0,old_failure_PID='not recorded;unknown;not whitelisted'))
plan=json.loads((p/'CPU_PLAN_003.json').read_bytes());plan.update(receipt_dir='D:/HeteroSpec-PC/rtx223-e11-u-contract/cpu-002',output_dir=str(Path(json.loads((p/'STAGING_V3.json').read_bytes())['profile'])/'Temp/e11-cpu-002'))
mapping={str(p/'runner_v3.py'):p/'runner_v4.py',str(p/'observation.py'):p/'observation_v2.py'}
for row in plan['controller_inputs']:
 if row['path'] in mapping:row.update(path=str(mapping[row['path']]),sha256=sha(mapping[row['path']]))
plan['controller_inputs'] += [dict(path=str(p/x),sha256=sha(p/x)) for x in ['CONTINUATION_CPU_TESTS.json','continuation_proof.py','PROFILE_CREATED.json']]
write(p/'CPU_PLAN_004.json',plan)
entry=p/'execute_cpu_004.py';text="from pathlib import Path\nimport json,hashlib,runpy,sys\np=Path(__file__).resolve().parent\nplan=p/'CPU_PLAN_004.json'\nassert hashlib.sha256(plan.read_bytes()).hexdigest()=="+repr(sha(p/'CPU_PLAN_004.json'))+"\nfor row in json.loads(plan.read_bytes())['controller_inputs']:\n assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256']\nprofile=json.loads((p/'PROFILE_CREATED.json').read_bytes())\nassert profile['create_hresult']==0 and profile['capabilities']==0 and Path(profile['profile']).exists()\nsys.argv=[str(p/'runner_v4.py'),str(plan)]\nrunpy.run_path(str(p/'runner_v4.py'),run_name='__main__')\n"
with entry.open('x',encoding='utf8',newline='\n') as f:f.write(text)
queue=p/'admin-queue-continuation';queue.mkdir()
write(queue/'005-cpu-readmit.json',dict(script=str(entry),sha256=sha(entry),reservation=0,kind='CPU_ONLY'))
print(json.dumps(dict(CPU_tests_pass=True,logical_timing_reservation=416,additional_reserved=0,protected_policy_unchanged=True)))
