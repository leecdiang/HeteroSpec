"""CPU compile/link only. Preserve frozen e08 input bytes and all failed builds."""
from pathlib import Path
import os,json,hashlib,subprocess,importlib.util,re,time
here=Path(__file__).resolve().parent;old=here.parent/'rtx223-e08/numeric-v1/operator-build-005';runtime=here.parent/'rtx223-round1-resume-20261112-e04/runtime'
out=here/'build-001';out.mkdir(exist_ok=False);(out/'generated').mkdir()
sha=lambda f:hashlib.file_digest(Path(f).open('rb'),'sha256').hexdigest()
def write(f,v):f.write_text(json.dumps(v,indent=2),encoding='utf8')
for name in ('bound_mmvq_prefix.cuh','bound_quantizer.cuh'):(out/name).write_bytes((old/name).read_bytes())
for name in ('c1_serial_groups.cuh','explicit_budget.hpp'):(out/name).write_bytes((here/name).read_bytes())
s=(old/'operator_probe.cu').read_text(encoding='utf8').replace('#include "two_group_q8.cuh"','#include "c1_serial_groups.cuh"\n#include "explicit_budget.hpp"').replace('hs_two_group_q8','hs_c1_serial_groups_q8')
s=s.replace('static int used=0,limit=0;\nstatic void reserve(int n){need(n>0&&used+n<=limit,"explicit application budget exceeded before dispatch");used+=n;}', 'static ApplicationBudget budget;\nstatic const uint32_t &used=budget.used,&limit=budget.limit;\nstatic void reserve(uint32_t n){budget.reserve(n);}')
s=s.replace('job.at("timing_blocks")==6','job.at("timing_blocks")==12').replace('limit=phase=="qualification"?14:355;','budget.configure(phase=="qualification"?14:320);')
s=s.replace('for (int arm=0;arm<3;++arm) for(int repeat=0;repeat<1;++repeat)', 'for (int arm=1;arm<3;++arm) for(int repeat=0;repeat<2;++repeat)')
a=s.index('        const int orders[6][3]');b=s.index('            if(mode==0)',a)
s=s[:a]+'''        for (int mode=0;mode<2;++mode) for(int block=0;block<12;++block) for(int position=0;position<2;++position) {
            int arm=1+((block+position)%2);
'''+s[b:]
s=s.replace('repetition<5','repetition<4').replace('{"batch_repetitions",5}','{"batch_repetitions",4}').replace('ms/5','ms/4')
needle='''            result["paired_timings"].push_back'''
s=s.replace(needle,'''            std::vector<char> batch_a(abytes),batch_y(ybytes);
            check(cudaMemcpy(batch_a.data(),da,abytes,cudaMemcpyDeviceToHost));
            check(cudaMemcpy(batch_y.data(),dy,ybytes,cudaMemcpyDeviceToHost));
            bool batch_exact=batch_a==captured_a && batch_y==expected;
            result["post_batch_bitwise"].push_back({{"mode",mode},{"block",block},{"arm",arm},{"activation_exact",batch_a==captured_a},{"output_exact",batch_y==expected}});
            need(batch_exact,"post-timing bitwise failure; no valid performance conclusion");
'''+needle)
s=s.replace('result["warmup_operator_calls"]=phase=="timing"?3:0','result["warmup_operator_calls"]=phase=="timing"?4:0')
s=s.replace('"achieved_occupancy","unknown"','"achieved_occupancy","NOT_MEASURED"').replace('"dram_bytes","unknown"','"dram_bytes","NOT_MEASURED"').replace('"l2_traffic","unknown"','"l2_traffic","NOT_MEASURED"')
s=s.replace('result["status"]="PASS_OPERATOR_ONLY";', 'result["arms"]={"A","B","C1"};result["status"]="PASS_OPERATOR_ONLY";')
src=out/'operator_probe.cu';src.write_text(s,encoding='utf8')
recipe=json.loads((old/'COMMAND.json').read_bytes());cmd=[x.replace(str(old),str(out)) for x in recipe['command']]
cmd += ['-MD','-MF',str(out/'actual_dependencies.d'),'--keep','--keep-dir',str(out/'generated')]
required={'PATH','INCLUDE','LIB','CUDA_PATH','SYSTEMROOT','WINDIR','COMSPEC','NUMBER_OF_PROCESSORS','PROCESSOR_ARCHITECTURE','PROCESSOR_IDENTIFIER','PATHEXT','OS'}
env={k:v for k,v in recipe['environment'].items() if k.upper() in required};env['TEMP']=env['TMP']=str(out);env['VSLANG']='1033'
write(out/'COMMAND.json',dict(command=cmd,environment=env,arithmetic_A_B='byte-identical original headers; original launch_arm A/B source unchanged',candidate='one serial-group variant, no register cap or tuning sweep'))
inputs=json.loads((old/'FREEZE.json').read_bytes())['inputs']
for f in [*out.iterdir(),Path(__file__),here/'CONTRACT.json',here/'PARENT_REUSE_VERIFIED.json']:
 if f.is_file():inputs[str(f)]={'sha256':sha(f),'bytes':f.stat().st_size}
write(out/'FREEZE.json',dict(inputs=inputs,parent_freeze_sha256=sha(old/'FREEZE.json'),capture_reused=True,CUDA_calls=0))
spec=importlib.util.spec_from_file_location('closure',runtime/'input_closure_v2.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);held=m.ReadFreeze();t=time.monotonic()
try:
 for path,row in inputs.items():
  held.add(path)
  if sha(path)!=row['sha256']:raise RuntimeError('old/new frozen input drift '+path)
 with (out/'build.log').open('xb') as log:r=subprocess.run(cmd,cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600)
 changes=[path for path,row in inputs.items() if sha(path)!=row['sha256']]
 # Dependencies are checked against frozen membership. Generated CUDA files stay in this output.
 depstatus='NOT_GENERATED';unbound=[]
 if (out/'actual_dependencies.d').exists():
  text=(out/'actual_dependencies.d').read_text(encoding='utf8');deps=m.parse_nvcc_dep(text,out/'operator_probe.obj',src) if False else None
  # nvcc target may be the exe; parse the delimiter with its drive-aware parser.
  words=[];logical=re.sub(r'\\\r?\n',' ',text).strip();pos=logical.find(': ')
  if pos<0:raise RuntimeError('dependency delimiter missing')
  words=m.make_words(logical[pos+1:])
  allowed={str(Path(x).resolve()).lower() for x in inputs}
  unbound=[x for x in words if str(Path(x).resolve()).lower() not in allowed and not Path(x).resolve().is_relative_to(out/'generated')]
  depstatus='PASS' if not unbound else 'UNBOUND_DEPENDENCIES'
 result=dict(returncode=r.returncode,input_changes=changes,dependency_status=depstatus,unbound=unbound,seconds=time.monotonic()-t,executable_sha256=sha(out/'operator_probe.exe') if (out/'operator_probe.exe').exists() else None,CUDA_initializations=0,model_loads=0,kernels=0,freeze_sha256=sha(out/'FREEZE.json'))
 write(out/'BUILD.json',result);print(json.dumps(result,indent=2),flush=True)
finally:held.release()
