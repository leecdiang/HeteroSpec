$ErrorActionPreference='Stop'
$root='C:/hs/b570-zero-gpu-repair-v1-20261016'
$self=[Diagnostics.Process]::GetCurrentProcess()
$started=[long]([decimal][Diagnostics.Stopwatch]::GetTimestamp()*1000000000/[Diagnostics.Stopwatch]::Frequency)
$psi=[Diagnostics.ProcessStartInfo]::new()
$psi.FileName='C:/Users/DIANG/AppData/Local/Programs/Python/Python312/python.exe'
$psi.Arguments='-B -u "C:/hs/b570-zero-gpu-repair-v1-20261016/repo/benchmarks/b570_zero_gpu_repair_v1/host/outer_task_ledger_v2.py"'
$psi.UseShellExecute=$false
$psi.CreateNoWindow=$true
$psi.EnvironmentVariables['TEMP']="$root/tmp"
$psi.EnvironmentVariables['TMP']="$root/tmp"
$child=[Diagnostics.Process]::Start($psi)
$open=@{boundary='Explicit development ledger rebootstrap, before new commands; old ledger and pending requests remain untouched';wrapper_pid=$PID;wrapper_creation_FILETIME=$self.StartTime.ToUniversalTime().ToFileTimeUtc();broker_pid=$child.Id;broker_creation_FILETIME=$child.StartTime.ToUniversalTime().ToFileTimeUtc();launch_ns=$started;argv=@($psi.FileName,$psi.Arguments)}
$open | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath "$root/task/BOOTSTRAP_V2_OPEN.json" -Encoding UTF8
try{$child.WaitForExit()}
finally{if(-not $child.HasExited){$child.Kill();$child.WaitForExit(30000)}}
@{wrapper_pid=$PID;wrapper_creation_FILETIME=$self.StartTime.ToUniversalTime().ToFileTimeUtc();broker_pid=$child.Id;broker_creation_FILETIME=$child.StartTime.ToUniversalTime().ToFileTimeUtc();broker_exit_FILETIME=$child.ExitTime.ToUniversalTime().ToFileTimeUtc();broker_exit_code=$child.ExitCode;exit_observed_ns=[long]([decimal][Diagnostics.Stopwatch]::GetTimestamp()*1000000000/[Diagnostics.Stopwatch]::Frequency);wrapper_exit_FILETIME=$null;wrapper_scope='Outer tool exit receipt closes wrapper; its own future OS exit is not self-certified'} | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath "$root/task/BOOTSTRAP_V2_CLOSED.json" -Encoding UTF8
exit $child.ExitCode
