#include <windows.h>
#include <cstring>
static unsigned used=0,limit=0,operations[4]={};static ULONGLONG deadline=0;
static const char* refusal_reason=nullptr;
extern "C" bool e11_reserve(unsigned n,const char*label) noexcept {
    if(!n||used>limit||n>limit-used){refusal_reason="explicit budget refused before dispatch";return false;}
    if(GetTickCount64()>=deadline){refusal_reason="prelaunch deadline reached";return false;}
    const char* names[]={"B_quantizer","B_projection","U_quantizer","U_projection"};int id=-1;
    for(int i=0;i<4;++i)if(strcmp(names[i],label)==0)id=i;
    if(id<0||n!=1){refusal_reason="unknown dispatch accounting";return false;}
    used+=n;operations[id]+=n;return true;
}

extern "C" void reset_mock(unsigned cap,bool expired) noexcept {used=0;limit=cap;deadline=GetTickCount64()+(expired?-1:10000);for(auto &x:operations)x=0;refusal_reason=nullptr;}
extern "C" unsigned mock_used() noexcept{return used;}
