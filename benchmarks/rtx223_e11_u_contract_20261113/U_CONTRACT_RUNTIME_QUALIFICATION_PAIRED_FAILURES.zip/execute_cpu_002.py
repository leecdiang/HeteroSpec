from pathlib import Path
import json,hashlib,runpy,sys
p=Path(__file__).resolve().parent
plan=p/'CPU_PLAN_002.json'
assert hashlib.sha256(plan.read_bytes()).hexdigest()=='4e80cf22a5fb741165494350fa35c89e170be51aa0cf9ebe9f7dbca70f4fd64e'
for row in json.loads(plan.read_bytes())['controller_inputs']:
 assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256']
runpy.run_path(str(p/'create_profile.py'),run_name='__main__')
sys.argv=[str(p/'runner_v2.py'),str(plan)]
runpy.run_path(str(p/'runner_v2.py'),run_name='__main__')
