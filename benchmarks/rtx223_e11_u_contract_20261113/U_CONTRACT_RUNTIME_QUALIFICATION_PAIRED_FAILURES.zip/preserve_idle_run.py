"""Preserve second approved profile and current phase receipts; CPU file I/O only."""
from pathlib import Path
import json,hashlib,shutil,datetime
p=Path(__file__).resolve().parent
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
record=json.loads((p/'PROFILE_CREATED_002.json').read_bytes())
profile=Path(record['profile']); rows=[]
for q in sorted(profile.parent.rglob('*')):
 if q.is_file():
  target=p/'evidence-idle/profile'/q.relative_to(profile.parent)
  target.parent.mkdir(parents=True,exist_ok=True)
  if target.exists():assert target.read_bytes()==q.read_bytes()
  else:shutil.copy2(q,target)
  rows.append(dict(original=str(q),preserved=str(target),sha256=sha(q),bytes=q.stat().st_size))
state=Path('D:/HeteroSpec-PC/rtx223-e11-u-contract')
for name in ['cpu-003','timing-003']:
 source=state/name
 if not source.exists():continue
 target=p/'evidence-idle'/name;target.mkdir(parents=True,exist_ok=True)
 for q in source.iterdir():
  if q.is_file():shutil.copy2(q,target/q.name);assert sha(q)==sha(target/q.name)
with (p/'PROFILE_DATA_PRESERVED_002.json').open('x',encoding='utf8') as f:
 json.dump(dict(files=rows,utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),f,indent=2)
print(json.dumps(dict(preserved_files=len(rows))))
