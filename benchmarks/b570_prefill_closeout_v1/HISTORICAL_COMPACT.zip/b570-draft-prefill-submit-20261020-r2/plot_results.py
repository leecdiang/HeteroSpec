from pathlib import Path
import json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
r=Path(__file__).parent;a=json.loads((r/"ANALYSIS.json").read_text());s=json.loads((r/"STAGE_SUMMARY.json").read_text())
plt.rcParams.update({"font.size":10,"svg.fonttype":"none","axes.spines.top":False,"axes.spines.right":False})
fig,axs=plt.subplots(1,2,figsize=(11,4.5),layout="constrained")
for i,inp in enumerate(a["per_input"]):
    rows=[x for x in a["paired_blocks"]if x["input_id"]==inp["input_id"]]
    for j,x in enumerate(rows):
        axs[0].scatter(i+(j-1)*.12,100*(x["service_BULK1_over_dualBASE"]-1),color="#126a9b",s=36,label="Candidate / dual baseline"if i==j==0 else None)
        axs[0].scatter(i+(j-1)*.12,100*(x["service_BASEA_over_BASEB"]-1),color="#888888",marker="x",s=30,label="Identical-code A/A"if i==j==0 else None)
    axs[0].scatter(i,100*(inp["service_BULK1_over_dualBASE"]-1),color="#b34f00",marker="D",s=55,label="Input geometric mean"if i==0 else None)
axs[0].axhline(0,color="#444444",lw=.8);axs[0].axhline(-2,color="#999999",lw=.8,ls="--")
axs[0].set_xticks([0,1],["HE/38","HE/115"]);axs[0].set_ylabel("Service difference (%) — lower is better")
axs[0].set_title("Complete request, three sessions");axs[0].legend(fontsize=8,loc="best")
vals=[s["draft_prefill_BASE_seconds"],s["draft_prefill_BULK1_seconds"]]
axs[1].bar(["Dual baseline","One API batch"],vals,color=["#888888","#126a9b"],width=.55)
for i,v in enumerate(vals):axs[1].text(i,v,f"{v:.3f}s",ha="center",va="bottom")
axs[1].set_ylabel("Draft prefill time (seconds)");axs[1].set_title("Descriptive phase cost");axs[1].set_ylim(0,max(vals)*1.15)
for ax in axs:ax.grid(axis="y",alpha=.2);ax.set_axisbelow(True)
fig.suptitle("B570 draft prefill submission batching; physical q=1 unchanged\nTwo fixed inputs · 18 measured requests · no population confidence interval",fontsize=12)
for suffix in ("png","svg","pdf"):fig.savefig(r/f"REQUEST_COST_PANEL.{suffix}",dpi=180)
print("Wrote PNG/SVG/PDF")
