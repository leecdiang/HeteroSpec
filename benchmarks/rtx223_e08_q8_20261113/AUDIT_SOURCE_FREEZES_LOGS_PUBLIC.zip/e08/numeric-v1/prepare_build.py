"""Separate compile/link session. Never load a numerical DLL or call CUDA."""
import os,sys,json,hashlib,subprocess,time,re,importlib.util
from pathlib import Path
here=Path(__file__).resolve().parent;study=here.parents[1]
runtime=study/'rtx223-round1-resume-20261112-e04/runtime'
front=runtime.parent/'e04/frontend/run-v4'
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2),encoding='utf8')
out=here/'build-001';out.mkdir(exist_ok=False);(out/'temp').mkdir()
source=(runtime/'source-v1/ggml/src/ggml-cuda/hs_launch_budget.cu').read_text()
source=source.replace('#if !defined(HS_LB_CPU_TEST_ONLY)','#if 0')
source=source.replace('limit > 4096','limit > 567').replace('reservation > limit-inherited','reservation == 0 || reservation > 64 || reservation > limit-inherited')
source=source.replace('return reject(LB_OPAQUE);','return state.configured.load() && !state.terminal.load() ? OK : reject(UNARMED);')
source=source.replace('    failstop(hs_launch_budget_deny_opaque_try_v1(route),\n             "HeteroSpec narrow launch profile refuses opaque CUDA/library route before call");','    const int code=hs_launch_budget_deny_opaque_try_v1(route);\n    if(code!=OK) failstop(code,"application-only controller not configured");')
source=source.replace('state_type state;', 'HANDLE log_handle=INVALID_HANDLE_VALUE;\nstd::mutex log_lock;\nstate_type state;')
source=source.replace('    state.limit.store(limit);', '''    char path[32768];
    if(!GetEnvironmentVariableA("HS_E08_LAUNCH_LOG",path,sizeof(path)))return reject(CONFIGURATION);
    log_handle=CreateFileA(path,GENERIC_WRITE,FILE_SHARE_READ,nullptr,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,nullptr);
    if(log_handle==INVALID_HANDLE_VALUE)return reject(CONFIGURATION);
    state.limit.store(limit);''')
source=source.replace('    const int code=hs_launch_budget_try_v1(site);','''    std::lock_guard<std::mutex> lock(log_lock);
    const int code=hs_launch_budget_try_v1(site);''')
source=source.replace('    if (code != OK) failstop(code, "HeteroSpec launch budget refused before explicit CUDA launch");','''    if (code != OK) failstop(code, "HeteroSpec launch budget refused before explicit CUDA launch");
    char line[2048];int length=snprintf(line,sizeof(line),"%llu %s\\n",(unsigned long long)state.admitted.load(),site);
    DWORD written=0;
    if(length<=0||length>=sizeof(line)||!WriteFile(log_handle,line,DWORD(length),&written,nullptr)||written!=length||!FlushFileBuffers(log_handle))
        failstop(reject(CONFIGURATION),"prelaunch evidence short/uncertain write");''')
a=source.index('    return "{\\"abi\\":1');b=source.index('\n}',a)
source=source[:a]+'    return "{\\"abi\\":1,\\"contract\\":\\"E08_EXPLICIT_APPLICATION_ONLY\\",\\"full_lifecycle_physical_upper_bound\\":false,\\"opaque_internal_work\\":\\"UNKNOWN_ALLOWED\\",\\"graphs\\":\\"DENY\\",\\"reset\\":false}";'+source[b:]
budget=out/'application_budget.cpp';budget.write_text(source,encoding='utf8')
capture=out/'capture.cpp';capture.write_bytes((here/'capture.cpp').read_bytes())
header=out/'hs_launch_budget.hpp';header.write_bytes((runtime/'source-v1/ggml/src/ggml-cuda/hs_launch_budget.hpp').read_bytes())
compiled=json.loads((runtime/'build-v2/COMPILE_RECEIPTS.json').read_bytes())
env=json.loads((runtime.parent/'e04/freeze/v2/ENVIRONMENT.json').read_bytes());env['TEMP']=env['TMP']=str(out/'temp')
cc=compiled[-1]['argv'][:];cc[cc.index('/sourceDependencies')+1]=str(out/'budget-deps.json');cc[cc.index('/c')+1]=str(budget);cc[-1]='/Fo:'+str(out/'budget.obj')
link=json.loads((runtime.parent/'e04/freeze/v2/LINK_COMMAND.json').read_bytes())
link=[s.replace(str(runtime/'build-v2/bin/ggml-cuda.dll'),str(out/'ggml-cuda.dll')).replace(str(runtime/'build-v2/ggml-cuda.lib'),str(out/'ggml-cuda.lib')).replace(compiled[-1]['object'],str(out/'budget.obj')) for s in link]
rsp=out/'LINK.rsp';rsp.write_text('\n'.join(subprocess.list2cmdline([s]) for s in link[1:]),encoding='utf8')
r=json.loads((front/'RECIPE.json').read_bytes());fc=r['cores']['loop4']['compile'][:];fl=r['cores']['loop4']['link'][:]
fc[fc.index('-c')+1]=str(capture);fc[fc.index('-o')+1]=str(out/'capture.obj');fc[fc.index('-MF')+1]=str(out/'capture.d')
fc.insert(fc.index('-c'),'-I'+str(runtime/'source-v1/ggml/src'));fc.insert(fc.index('-c'),'-I'+str(runtime/'source-v1/ggml/src/ggml-cuda'))
for i,s in enumerate(fl):
 if s.endswith('worker.obj'):fl[i]=str(out/'capture.obj')
 for key,name in (('-PDB:','capture.pdb'),('-OUT:','capture.exe'),('-IMPLIB:','capture.lib'),('/map:','capture.map')):
  if s.startswith(key):fl[i]=key+str(out/name)
fenv=r['environment'].copy()
for key in ('TEMP','TMP','ZIG_GLOBAL_CACHE_DIR','ZIG_LOCAL_CACHE_DIR'):
 p=out/key;p.mkdir(exist_ok=True);fenv[key]=str(p)
write(out/'COMMANDS.json',dict(budget_compile=cc,root_link=link,capture_compile=fc,capture_link=fl,env=env,front_env=fenv))
inputs=dict(json.loads((runtime.parent/'e04/freeze/v2/FREEZE.json').read_bytes())['inputs'])
for row in compiled[:-1]:
 if sha(row['object'])!=row['object_sha256']:raise RuntimeError('old arithmetic object changed')
 inputs[row['object']]={'sha256':row['object_sha256'],'bytes':Path(row['object']).stat().st_size,'role':'reused_unmodified_e04_object'}
for p in [*Path(r['toolchain']).rglob('*'),*(front/'deps').rglob('*'),here/'CONTRACT.json',Path(__file__),*out.glob('*')]:
 if p.is_file():inputs[str(p.resolve())]={'sha256':sha(p),'bytes':p.stat().st_size}
write(out/'FREEZE.json',dict(inputs=inputs,arithmetic_objects_reused=144,new_host_controller_objects=1,scope='explicit application only; no original contract change'))
spec=importlib.util.spec_from_file_location('closure',runtime/'input_closure_v2.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);held=m.ReadFreeze()
codes=[]
try:
 for p,entry in inputs.items():
  held.add(p)
  if sha(p)!=entry['sha256']:raise RuntimeError('frozen input changed '+p)
 for name,args,e in [('budget-compile',cc,env),('root-link',[link[0],'@'+str(rsp)],env),('capture-compile',fc,fenv),('capture-link',fl,fenv)]:
  t=time.monotonic()
  with (out/(name+'.log')).open('xb') as log:cp=subprocess.run(args,env=e,cwd=out,stdout=log,stderr=subprocess.STDOUT,timeout=600)
  codes.append(dict(stage=name,returncode=cp.returncode,seconds=time.monotonic()-t));print(codes[-1],flush=True)
  if cp.returncode:break
 changes=[p for p,v in inputs.items() if sha(p)!=v['sha256']]
 write(out/'BUILD.json',dict(stages=codes,input_changes=changes,outputs={p.name:sha(p) for p in out.glob('*.exe')}|{p.name:sha(p) for p in out.glob('*.dll')},GPU_calls=0,DLL_loads=0,freeze_sha256=sha(out/'FREEZE.json')))
finally:held.release()
