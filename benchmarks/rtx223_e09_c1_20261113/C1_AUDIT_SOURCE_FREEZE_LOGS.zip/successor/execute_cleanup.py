from pathlib import Path
import hashlib,sys,runpy
p=Path(__file__).resolve().parent
assert hashlib.sha256((p/"cleanup_profile.py").read_bytes()).hexdigest()=="0fb7aea76f27ac48615e06b0103828593eda8a9e3d4e84433eac1ca9c996c022"
sys.argv=[str(p/"cleanup_profile.py"),"apply-after-owned-processes-ended"]
runpy.run_path(str(p/"cleanup_profile.py"),run_name="__main__")
