"""Amend phase identities without changing the frozen500 controller or contracts."""
from pathlib import Path
import json,hashlib,shutil,struct,math,re,os
p=Path(__file__).resolve().parent;study=p.parent
sha=lambda q:hashlib.sha256(Path(q).read_bytes()).hexdigest()
def write(q,v):
 with q.open('x',encoding='utf8',newline='\n') as f:json.dump(v,f,indent=2)
old=json.loads((p/'STAGING.json').read_bytes());stage=study/'rtx223-e07/staging-B1/e11-ucontract-002';stage.mkdir(exist_ok=False)
for row in old['files']:
 q=Path(row['path']);shutil.copy2(p/'build-002/operator-upstream.exe' if q.suffix=='.exe' else q,stage/q.name)
records=[dict(path=str(q),sha256=sha(q),bytes=q.stat().st_size,file_id=dict(volume=q.stat().st_dev,inode=q.stat().st_ino)) for q in sorted(stage.iterdir())]
write(p/'STAGING_V2.json',dict(stage=str(stage),profile=old['profile'],package=old['package'],files=records,model_files_copied=0,ACL_changes=0))
s=(p/'runner.py').read_text().replace("HERE/'STAGING.json'","HERE/'STAGING_V2.json'").replace("sha(HERE/'runner.py')","sha(HERE/'runner_v2.py')")
with (p/'runner_v2.py').open('x',encoding='utf8',newline='\n') as f:f.write(s)
ptx=p/'build-002/generated/upstream_wrap/upstream_wrap.compute_120a.ptx';text=ptx.read_text();start=text.index('.entry _Z21quantize_mmq_few_q8_1');assert 'div.approx.ftz.f32' in text[start:] and 'rcp.approx.ftz.f32' in text[start:]
assert (p/'build-002/bound_mmvq_prefix.cuh').read_bytes()==(study/'rtx223-e09-c1/build-001/bound_mmvq_prefix.cuh').read_bytes()
assert (p/'build-002/bound_quantizer.cuh').read_bytes()==(study/'rtx223-e09-c1/build-001/bound_quantizer.cuh').read_bytes()
main=(p/'main_body_v2.inc').read_text();wrap=(p/'upstream_wrap_v2.cu').read_text();assert main.count('<<<')==wrap.count('<<<')==2
assert 'extern "C" bool e11_reserve' in main and 'noexcept' in main and 'if(!e11_reserve(1,"U_' in wrap
full=json.loads((p/'full-backend-002/RESULT.json').read_bytes());assert all(x['returncode']==0 and x['owned_active_at_exit']==0 for x in full['stages'])
full_dll=p/'full-backend-002/build/bin/ggml-cuda.dll';assert full_dll.exists()
write(p/'FULL_BACKEND_BUILD_IDENTITY.json',dict(built=True,path=str(full_dll),sha256=sha(full_dll),bytes=full_dll.stat().st_size,source_commit='0fb8f157702702f33f4e018de8701b2569a1bc28',loaded=False,backend_run='NOT_RUN',reason='Full dispatcher,initialization,graph/replay explicit-call control not closed within this500 exploration. Only extracted4 author dispatch sites admitted.',compile_only=True,CUDA_ABI_execution_suppressed=True))
write(p/'STATIC_ADMISSION.json',dict(pass_=True,launch_sites=4,prelaunch='nonthrowing C ABI bool,always checked before each launch;deadline109s;native14/392;family500',PTX_quantizer_approximate_div_reciprocal=True,PTX_sha256=sha(ptx),old_B_source_identical=True,oracle_set_header_sha256=sha(p/'u_oracle.hpp'),counter_fault_tests=json.loads((p/'counter-cpu-002/RESULT.json').read_bytes()),full_backend='COMPILE_PASS_NOT_RUN',e10='FAIL_UNCHANGED',old_4096='NOT_CLOSED'))
activation=(stage/'activation.f32').read_bytes();values=struct.unpack('<32768f',activation);assert all(math.isfinite(x) and (x==0 or abs(x)>=2**-126) for x in values)
write(p/'CPU_DOMAIN.json',dict(pass_=True,activation_values=32768,min_nonzero_abs=min(abs(x) for x in values if x),max_abs=max(map(abs,values)),nonzero_normal=True,blocks_nonzero=all(any(values[c*4096+b*32+k]!=0 for k in range(32)) for c in range(8) for b in range(128)),weight_domain_verified_by_independent_CPU_checker=True,CPU_checker=json.loads((p/'capture-cpu-001/RESULT.json').read_bytes()),CUDA_initializations=0))
write(p/'CONTROL_AMENDMENT_V2.json',dict(reason='CPU EHsc fault exposed throwing extern-C callback;no GPU attempt or reservation. Newbuild002 returns bool/cudaError across ABI,keeps EHsc and all device mathematics/contract/budget unchanged.',controller_unchanged_sha256=sha(p/'admin_controller.py'),contract_unchanged_sha256=sha(p/'CONTRACT.json'),old_build_001='NOT_RUN_PRESERVED',old_request_001='NOT_QUEUED_SUPERSEDED',new_build_sha256=sha(p/'build-002/operator-upstream.exe'),runner_sha256=sha(p/'runner_v2.py'),staging_sha256=sha(p/'STAGING_V2.json'),counter_result_sha256=sha(p/'counter-cpu-002/RESULT.json')))
plan=json.loads((p/'CPU_PLAN_001.json').read_bytes());replace={str(p/'runner.py'):p/'runner_v2.py',str(p/'STAGING.json'):p/'STAGING_V2.json',str(p/'build-001/BUILD.json'):p/'build-002/BUILD.json'}
for row in plan['controller_inputs']:
 if row['path'] in replace:row.update(path=str(replace[row['path']]),sha256=sha(replace[row['path']]))
extra=['counter-cpu-002/RESULT.json','STATIC_ADMISSION.json','CPU_DOMAIN.json','FULL_BACKEND_BUILD_IDENTITY.json','CONTROL_AMENDMENT_V2.json','main_body_v2.inc','upstream_wrap_v2.cu','capture-cpu-001/validate_capture_cpu.exe']
plan['controller_inputs'] += [dict(path=str(p/x),sha256=sha(p/x)) for x in extra]
write(p/'CPU_PLAN_002.json',plan)
entry=p/'execute_cpu_002.py';s="from pathlib import Path\nimport json,hashlib,runpy,sys\np=Path(__file__).resolve().parent\nplan=p/'CPU_PLAN_002.json'\nassert hashlib.sha256(plan.read_bytes()).hexdigest()=="+repr(sha(p/'CPU_PLAN_002.json'))+"\nfor row in json.loads(plan.read_bytes())['controller_inputs']:\n assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256']\nrunpy.run_path(str(p/'create_profile.py'),run_name='__main__')\nsys.argv=[str(p/'runner_v2.py'),str(plan)]\nrunpy.run_path(str(p/'runner_v2.py'),run_name='__main__')\n"
with entry.open('x',encoding='utf8',newline='\n') as f:f.write(s)
dest=p/'admin-queue/001-cpu-admission.json';pending=dest.with_suffix('.pending');write(pending,dict(script=str(entry),sha256=sha(entry),reservation=0,kind='CPU_ONLY'));os.rename(pending,dest)
print(json.dumps(dict(queued=str(dest),selected_exe_sha256=sha(stage/'operator-ucontract.exe'),full_backend_compile=True,CUDA_initializations=0)))
