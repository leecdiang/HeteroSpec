from pathlib import Path
import hashlib,runpy,sys,json
p=Path(__file__).resolve().parent
plan=p/"CAPTURE_PLAN_001.json"
assert hashlib.sha256(plan.read_bytes()).hexdigest()=="878d7409e48f8962bf7565a922690c95b424d75fdaa02e49a00aa86c8d8628d3"
for row in json.loads(plan.read_bytes())["controller_inputs"]:
 assert hashlib.sha256(Path(row["path"]).read_bytes()).hexdigest()==row["sha256"]
sys.argv=[str(p/"runner-v3.py"),str(plan)]
runpy.run_path(str(p/"runner-v3.py"),run_name="__main__")
