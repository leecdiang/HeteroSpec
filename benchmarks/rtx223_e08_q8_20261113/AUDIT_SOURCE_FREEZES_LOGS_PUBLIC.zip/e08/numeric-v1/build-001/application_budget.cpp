#include "hs_launch_budget.hpp"
#include <atomic>
#include <mutex>
#include <cstdio>
#include <cstdlib>
#if defined(_WIN32)
#include <windows.h>
#endif

namespace {
enum : int { OK=1, UNARMED=-1, EXHAUSTED=-2, REENTRY=-3, LB_OPAQUE=-4,
             CONFIGURATION=-5, NATIVE_BLOCKED=-6, TERMINAL=-7 };
struct state_type {
    std::mutex configuration_lock;
    std::atomic<int> configured{0};
    std::atomic<int> terminal{0};
    std::atomic<uint64_t> limit{4096}, inherited{0}, reservation{0};
    std::atomic<uint64_t> admitted{0}, rejected{0};
};
HANDLE log_handle=INVALID_HANDLE_VALUE;
std::mutex log_lock;
state_type state;  // one shared definition, not header/TLS state
thread_local bool in_prelaunch = false;

int reject(int code) {
    state.rejected.fetch_add(1, std::memory_order_relaxed);
    int empty=0;
    state.terminal.compare_exchange_strong(empty, code, std::memory_order_acq_rel);
    return code;
}

[[noreturn]] void failstop(int code, const char * text) {
    std::fputs(text, stderr);
    std::fputc('\n', stderr);
    std::fflush(stderr);
#if defined(_WIN32)
    // No C++ exception crosses the GNU/MSVC DLL ABI. Only this process exits.
    TerminateProcess(GetCurrentProcess(), 0xE0330000u + static_cast<unsigned>(-code));
#endif
    std::abort();
}
}

extern "C" int hs_launch_budget_configure_v1(uint64_t limit, uint64_t inherited,
                                               uint64_t reservation, const char * epoch) {
#if 0
    (void)limit; (void)inherited; (void)reservation; (void)epoch;
    // Source-visible launch coverage is not a proof of all physical kernels:
    // opaque runtime/library work remains unqualified. No numeric DLL is armed.
    return reject(NATIVE_BLOCKED);
#else
    std::lock_guard<std::mutex> lock(state.configuration_lock);
    if (state.configured.load() != 0 || state.terminal.load() != 0) return reject(CONFIGURATION);
    if (!epoch || !epoch[0] || limit == 0 || limit > 567 || inherited > limit ||
        reservation == 0 || reservation > 64 || reservation > limit-inherited) return reject(CONFIGURATION);
    char path[32768];
    if(!GetEnvironmentVariableA("HS_E08_LAUNCH_LOG",path,sizeof(path)))return reject(CONFIGURATION);
    log_handle=CreateFileA(path,GENERIC_WRITE,FILE_SHARE_READ,nullptr,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,nullptr);
    if(log_handle==INVALID_HANDLE_VALUE)return reject(CONFIGURATION);
    state.limit.store(limit); state.inherited.store(inherited); state.reservation.store(reservation);
    state.configured.store(1, std::memory_order_release);
    return OK;
#endif
}

extern "C" int hs_launch_budget_try_v1(const char * site) {
    if (in_prelaunch) return reject(REENTRY);
    struct scoped_flag {
        scoped_flag() { in_prelaunch=true; }
        ~scoped_flag() { in_prelaunch=false; }
    } guard;
    if (!site || !site[0]) return reject(CONFIGURATION);
    if (!state.configured.load(std::memory_order_acquire)) return reject(UNARMED);
    if (state.terminal.load(std::memory_order_acquire)) return reject(TERMINAL);
    uint64_t current=state.admitted.load(std::memory_order_relaxed);
    while (true) {
        const uint64_t inherited=state.inherited.load(std::memory_order_relaxed);
        const uint64_t limit=state.limit.load(std::memory_order_relaxed);
        const uint64_t reservation=state.reservation.load(std::memory_order_relaxed);
        if (current >= reservation || inherited >= limit || current >= limit-inherited)
            return reject(EXHAUSTED);
        if (state.admitted.compare_exchange_weak(current, current+1,
                                                std::memory_order_acq_rel,
                                                std::memory_order_relaxed)) return OK;
        if (state.terminal.load(std::memory_order_acquire)) return reject(TERMINAL);
    }
}

extern "C" void hs_launch_budget_before_launch_v1(const char * site) {
    std::lock_guard<std::mutex> lock(log_lock);
    const int code=hs_launch_budget_try_v1(site);
    if (code != OK) failstop(code, "HeteroSpec launch budget refused before explicit CUDA launch");
    char line[2048];int length=snprintf(line,sizeof(line),"%llu %s\n",(unsigned long long)state.admitted.load(),site);
    DWORD written=0;
    if(length<=0||length>=sizeof(line)||!WriteFile(log_handle,line,DWORD(length),&written,nullptr)||written!=length||!FlushFileBuffers(log_handle))
        failstop(reject(CONFIGURATION),"prelaunch evidence short/uncertain write");
}

extern "C" int hs_launch_budget_deny_opaque_try_v1(const char * route) {
    (void)route;
    return state.configured.load() && !state.terminal.load() ? OK : reject(UNARMED);
}

extern "C" void hs_launch_budget_deny_opaque_v1(const char * route) {
    const int code=hs_launch_budget_deny_opaque_try_v1(route);
    if(code!=OK) failstop(code,"application-only controller not configured");
}

extern "C" int hs_launch_budget_snapshot_v1(hs_launch_budget_snapshot_v1_t * out) {
    if (!out) return CONFIGURATION;
    *out = {1, state.limit.load(), state.inherited.load(), state.reservation.load(),
            state.admitted.load(), state.rejected.load(), state.terminal.load(), state.configured.load()};
    return OK;
}

extern "C" const char * hs_launch_budget_metadata_v1() {
    return "{\"abi\":1,\"contract\":\"E08_EXPLICIT_APPLICATION_ONLY\",\"full_lifecycle_physical_upper_bound\":false,\"opaque_internal_work\":\"UNKNOWN_ALLOWED\",\"graphs\":\"DENY\",\"reset\":false}";
}

#if defined(HS_LB_CPU_TEST_ONLY)
extern "C" int hs_launch_budget_test_reentry_v1() {
    in_prelaunch=true;
    int result=hs_launch_budget_try_v1("CPU-test-recursive-prelaunch");
    in_prelaunch=false;
    return result;
}
#endif
