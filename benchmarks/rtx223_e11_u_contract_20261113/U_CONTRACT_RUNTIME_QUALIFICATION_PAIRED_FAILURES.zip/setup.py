"""CPU-only successor setup and portable build-tool retrieval. No system install."""
from pathlib import Path
import json,hashlib,subprocess,shutil,urllib.request,zipfile,datetime
p=Path(__file__).resolve().parent;old=p.parent/'rtx223-e10-fewrow'
sha=lambda q:hashlib.file_digest(Path(q).open('rb'),'sha256').hexdigest()
def write(q,v):
 with q.open('x',encoding='utf8') as f:json.dump(v,f,indent=2)
shutil.copytree(old/'u',p/'u')
for row in json.loads((old/'UPSTREAM_BLOBS_VERIFIED.json').read_bytes())['files']:assert sha(p/'u'/row['path'])==row['sha256']
write(p/'UPSTREAM_SOURCE.json',dict(commit='0fb8f157702702f33f4e018de8701b2569a1bc28',path=str(p/'u'),copy_from=str(old/'u'),all10_changed_blobs_match=True,archive_sha256=json.loads((old/'UPSTREAM_SOURCE.json').read_bytes())['archive_sha256']))
shutil.copy2(old/'UPSTREAM_BLOBS_VERIFIED.json',p/'UPSTREAM_BLOBS_VERIFIED.json')
source=(old/'verify_parent.py').read_text().replace("parent_head='304dcbff6d17461237774464c67ce8cb0ed60189'","parent_head='01a4cf847bfc8340321564c66132680d4131bf0d'")
(p/'verify_parent.py').write_text(source,encoding='utf8',newline='\n')
for name in ['observation.py','Collect-Host.ps1']:shutil.copy2(old/name,p/name)
tool=p/'tools';tool.mkdir()
url='https://github.com/Kitware/CMake/releases/download/v3.31.8/'
checksum=urllib.request.urlopen(url+'cmake-3.31.8-SHA-256.txt').read().decode();(tool/'CMAKE_SHA256.txt').write_text(checksum)
file='cmake-3.31.8-windows-x86_64.zip';expected=next(x.split()[0] for x in checksum.splitlines() if x.endswith(file))
dest=tool/file;urllib.request.urlretrieve(url+file,dest);assert sha(dest)==expected
with zipfile.ZipFile(dest) as z:z.extractall(tool)
records=[dict(name=file,path=str(dest),sha256=sha(dest),source=url+file,checksum_source=url+'cmake-3.31.8-SHA-256.txt')]
# Ninja official release metadata supplies the artifact digest independently of ZIP bytes.
c=subprocess.run(['gh','api','repos/ninja-build/ninja/releases/tags/v1.13.1'],capture_output=True,text=True,encoding='utf8',timeout=30);assert c.returncode==0,c.stderr
meta=json.loads(c.stdout);asset=next(x for x in meta['assets'] if x['name']=='ninja-win.zip');assert asset.get('digest','').startswith('sha256:')
dest=tool/'ninja-win.zip';urllib.request.urlretrieve(asset['browser_download_url'],dest);assert 'sha256:'+sha(dest)==asset['digest']
with zipfile.ZipFile(dest) as z:z.extractall(tool/'ninja')
records.append(dict(name='ninja-win.zip',path=str(dest),sha256=sha(dest),source=asset['browser_download_url'],release_asset_digest=asset['digest']))
write(p/'PORTABLE_TOOLS.json',dict(files=records,system_install=False,ACL_changes=0,CUDA_initializations=0,utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
print(json.dumps(dict(setup=True,tools=records)))
