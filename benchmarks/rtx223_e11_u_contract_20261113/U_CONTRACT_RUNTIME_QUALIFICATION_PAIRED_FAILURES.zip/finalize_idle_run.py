"""Final read-only evidence binding, hashing and reporting; no CUDA API."""
from pathlib import Path
import json,hashlib,shutil,datetime,importlib.util,collections
p=Path(__file__).resolve().parent;state=Path('D:/HeteroSpec-PC/rtx223-e11-u-contract')
sha=lambda q:hashlib.file_digest(Path(q).open('rb'),'sha256').hexdigest()
utc=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def put(name,obj): (p/name).write_text(json.dumps(obj,indent=2),encoding='utf8')
for name in ['RESULT.json','FINAL_IDENTITIES.json','CLEANUP_FINAL.json']:
 target=p/('TWO_REFUSALS_'+name)
 if not target.exists():shutil.copy2(p/name,target)
family=(state/'family.jsonl').read_bytes();events=[json.loads(x) for x in family.splitlines()]
for name in ['FAMILY_PREFIX_BEFORE_CONTINUATION.jsonl','FAMILY_PREFIX_BEFORE_IDLE.jsonl']:assert family.startswith((p/name).read_bytes())
assert events[-1]['kind']=='IDLE_CONTINUATION_STOPPED' and events[-1]['claimed']
assert sum(x['reserved'] for x in events if x['kind']=='RESERVED_BEFORE_TASK')==430
assert all(x.get('additional_reserved',0)==0 for x in events)
analysis=json.loads((p/'ANALYSIS.json').read_bytes());assert analysis['stable_in_both_boundaries']
qual=json.loads((p/'evidence-run/profile/AC/Temp/e11-qualification-001/result.json').read_bytes())
timing=json.loads((p/'evidence-idle/profile/AC/Temp/e11-timing-003/result.json').read_bytes())
assert qual['explicit_prelaunch_charged']==8 and timing['explicit_prelaunch_charged']==392
assert timing['explicit_by_operation']==dict(B_quantizer=74,B_projection=122,U_quantizer=74,U_projection=122)
assert len(timing['post_batch_bitwise'])==48 and all(x['activation_exact'] and x['output_exact'] for x in timing['post_batch_bitwise'])
observations={};attempts=[]
for name in ['qualification-001','timing-001','timing-002','timing-003']:
 rows=[json.loads(x)['event'] for x in (state/name/'attempt.jsonl').read_bytes().splitlines()]
 assert rows[-1]['owned_process_exit_confirmed']
 no_native=not any(x.get('kind') in ['OWNED_SUSPENDED','PERMIT'] for x in rows)
 if name in ['timing-001','timing-002']:assert no_native and rows[-1]['kind']=='FAIL'
 else:assert rows[-1]['kind']=='PASS' and not no_native
 count=8 if name=='qualification-001' else 392 if name=='timing-003' else 0
 attempts.append(dict(name=name,status=rows[-1]['kind'],native_created=not no_native,explicit_application_permits=count,terminal=rows[-1]))
 if not no_native:
  counts=collections.Counter(str(x['event_id']) for x in rows if x.get('observer')=='ETW')
  ends=[x for x in rows if x.get('observer')=='ETW_end']
  assert counts==dict({'1':1,'2':1,'5':55,'6':55}) and ends[-1]['loss_counters']==[0,0,0]
  observations[name]=dict(ETW_counts=dict(counts),ETW_loss_counters=ends[-1]['loss_counters'],watermarks=[x for x in rows if x.get('observer')=='watermark'],not_a_physical_launch_counter=True)
for name in ['PROFILE_DATA_PRESERVED.json','PROFILE_DATA_PRESERVED_002.json']:
 for row in json.loads((p/name).read_bytes())['files']:assert sha(row['preserved'])==row['sha256']
assert json.loads((p/'PROFILE_CLEANUP.json').read_bytes())['deleted']
assert json.loads((p/'PROFILE_CLEANUP_002.json').read_bytes())['deleted']
host=json.loads((p/'HOST_FINAL_002.private.json').read_bytes());assert not host['competing_workers'] and not host['project_tasks'] and not host['project_services']
controllers=[26356,3004,json.loads((p/'ADMIN3_LAUNCH.json').read_bytes().decode('utf-8-sig'))['pid']]
assert not set(controllers)&{x['ProcessId'] for x in host['all_processes']}
assert not Path('D:/HeteroSpec-PC/RTX_EXPERIMENT.lock').exists() and not (state/'runner.lease').exists()
parents=json.loads((p/'PARENTS_VERIFIED.json').read_bytes())['files']
for row in parents:assert sha(row['path'])==row['sha256'],row['path']
inputs=json.loads((p/'build-003/FREEZE.json').read_bytes())['inputs']
for name,row in inputs.items():assert sha(name)==row['sha256'],name
stage=json.loads((p/'STAGING_V4.json').read_bytes())
for row in stage['files']:assert sha(row['path'])==row['sha256']
spec=importlib.util.spec_from_file_location('final_ob',p/'observation_v3.py');ob=importlib.util.module_from_spec(spec);spec.loader.exec_module(ob)
nvml=json.loads((p/'DEPLOYMENT.json').read_bytes())['modules']['nvml.dll'];assert sha(nvml['path'])==nvml['sha256']
m=ob.Management(nvml['path'])
try:
 m.start();total,free,used,disk,pids=m.sample(p);util=m.utilization()
 gpu=dict(utc=utc(),read_only_NVML=True,compute_pids=pids,GPU_utilization_percent=util,free_bytes=free,used_bytes=used,temperature_c=m.temperature,CUDA_runtime_calls=0)
 assert not pids
finally:m.close()
put('POSTRUN_GPU_READONLY.json',gpu)
(p/'evidence-idle/family.jsonl').write_bytes(family)
result=json.loads((p/'RESULT.json').read_bytes())
result.update(schema='heterospec.e11.real-U-qualification.v3',utc=utc(),status='PASS_EXTRACTED_U_DIFFERENT_CONTRACT_EXPLORATORY_HEADROOM',timing_attempts=attempts,analysis='ANALYSIS.json',samples=48,pairs=24,next='GPU stopped;one legacy-preserving candidate proposal only;new independent authorization needed for candidate/cross-input/service')
result['gates'].update(C_paired_timing='PASS_12_PAIRS_PER_BOUNDARY_ALL_RETAINED',service5pct='CONDITIONAL_COVERAGE_ONLY_SAME_REQUEST_COSTS_NOT_MEASURED',cleanup='PASS_BOTH_PROFILES_AND_ALL_CONTROLLERS_ENDED')
result['budget'].update(explicit_application_permits=400,timing_003=392,unused_reserved_not_refunded=30)
result['consumption'].update(native_GPU_processes=2,CUDA_runtime_driver_initialized=True,implicit_context_count=None,full_lifecycle_physical_launches=None)
result['timing_summary']={k:{x:v[x] for x in ['U_over_B_geomean','U_time_change_percent','paired_log_bootstrap_95pct','U_faster_pairs','stable_exploratory_advantage']} for k,v in analysis['summary'].items()}
result['amdahl']=analysis['amdahl'];result['raw_timing_result_sha256']=sha(p/'evidence-idle/profile/AC/Temp/e11-timing-003/result.json')
put('RESULT.json',result)
put('LEDGER_INTERPRETATION_FINAL.json',dict(limit=500,global_reserved=430,actual_explicit=400,qualification_actual=8,timing_actual=392,two_refusals_actual=0,unused_reserved_not_refunded=30,unreserved=70,additional_continuation_reservation=0,global_debits='14+416;inner416 records all refer to the same003-timing reservation',prefixes_preserved=True,final_journal_sha256=sha(state/'family.jsonl'),physical_lifecycle_launches=None,old4096='NOT_CLOSED'))
put('OBSERVATION_SUMMARY.json',dict(phases=observations,limits='ETW endpoints/images and NVML sampled watermarks are not physical-kernel/context accounting;short kernels may occur between samples;device hang immediate cleanup not guaranteed'))
put('CLEANUP_FINAL.json',dict(pass_=True,utc=host['end_utc'],controllers_absent=controllers,competing_workers=[],project_tasks=[],project_services=[],canonical_lease_exists=False,runner_lease_exists=False,both_profiles_deleted=True,unrelated_processes_killed=0,ToDesk_settings_changes=0,ACL_changes=0,security_changes=0,limits='current host snapshot only;not a guarantee about future unrelated tasks'))
put('FINAL_IDENTITIES.json',dict(pass_=True,utc=utc(),native_build_inputs_rechecked=len(inputs),parent_records_rechecked=len(parents),stage_files_rechecked=len(stage['files']),native_sha256=sha(p/'build-003/operator-upstream.exe'),prefixes_preserved=True,final_family_sha256=sha(state/'family.jsonl'),raw_data_preserved=True,old_failures_unchanged=True,cleanup=True))
put('HOST_SUMMARY_FINAL.json',dict(utc=host['end_utc'],host_process_count=len(host['all_processes']),host_task_count=len(host['all_tasks']),project_tasks=[],project_services=[],competing_workers=[],all_controllers_ended=True,all_owned_leases_absent=True,limits='point-in-time snapshot;full command lines private'))
print(json.dumps(dict(status=result['status'],explicit_calls=400,reserved=430,parent_records=len(parents),native_inputs=len(inputs),cleanup=True)))
