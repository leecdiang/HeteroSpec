from pathlib import Path
import hashlib,runpy,sys,json
p=Path(__file__).resolve().parent
plan=p/"CAPTURE_PLAN_003.json"
assert hashlib.sha256(plan.read_bytes()).hexdigest()=="c2d93230af3432aa4f1704b095510f239e0ff07cb19ba37c464486e055403d65"
for row in json.loads(plan.read_bytes())["controller_inputs"]:
 assert hashlib.sha256(Path(row["path"]).read_bytes()).hexdigest()==row["sha256"]
sys.argv=[str(p/"runner-v6.py"),str(plan)]
runpy.run_path(str(p/"runner-v6.py"),run_name="__main__")
