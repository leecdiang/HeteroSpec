from pathlib import Path
import json,hashlib,sys,runpy
p=Path(__file__).resolve().parent
plan=p/'QUALIFICATION_PLAN_001.json'
assert hashlib.sha256(plan.read_bytes()).hexdigest()=='9c5638f6a1fc53601161a5206cab4ea5bf5c09bd4463e858902d6048ef214329'
for row in json.loads(plan.read_bytes())['controller_inputs']:
 assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256']
sys.argv=[str(p/'runner.py'),str(plan)]
runpy.run_path(str(p/'runner.py'),run_name='__main__')
