from common import *
import py_compile
p=R/'code/runtime.py';s=p.read_text().replace("decode('utf8-sig'","decode('utf-8-sig'")
s=s.replace("EXE=R/'build/Release/b570-evidence-worker.exe'","EXE=R/'build/Release/b570-evidence-worker.exe'\nCOUNTER_SHA=sha(R/'COUNTER_SEMANTICS.json')")
s=s.replace("w['counter_semantics_sha256']==sha(R/'COUNTER_SEMANTICS.json')","w['counter_semantics_sha256']==COUNTER_SHA")
s=s.replace("assert counts[kind]+unit<=LIMITS[kind],","assert counts['core']+unit<=256 if kind=='probe' else True\n assert counts[kind]+unit<=LIMITS[kind],")
p.write_text(s,encoding='utf8');py_compile.compile(str(p),doraise=True)
# Read-only host inventory, no profiler start.
q=subprocess.run([str(PS),'-NoProfile','-NonInteractive','-Command',"[Console]::OutputEncoding=[System.Text.UTF8Encoding]::new($false); $x=@{utc=(Get-Date).ToUniversalTime().ToString('o');os=(Get-CimInstance Win32_OperatingSystem | Select-Object Caption,Version,BuildNumber,LastBootUpTime);gpu=@(Get-CimInstance Win32_VideoController | Select-Object Name,PNPDeviceID,DriverVersion,DriverDate);cpu=(Get-CimInstance Win32_Processor | Select-Object Name,NumberOfCores,NumberOfLogicalProcessors);memory=(Get-CimInstance Win32_ComputerSystem | Select-Object TotalPhysicalMemory)};$x|ConvertTo-Json -Depth 5"],capture_output=True,creationflags=subprocess.CREATE_NO_WINDOW,timeout=30)
(R/'HOST_INVENTORY.stdout').write_bytes(q.stdout);(R/'HOST_INVENTORY.stderr').write_bytes(q.stderr);assert q.returncode==0
save(R/'HOST_INVENTORY.json',json.loads(q.stdout.decode('utf-8-sig')))
core=[R/'native/worker.cpp',R/'native/candidate-src/llama-context.cpp',R/'native/candidate-src/llama-context.h',R/'native/CMakeLists.txt',R/'COUNTER_SEMANTICS.json',*list((R/'build/Release').glob('*.dll')),R/'build/Release/b570-evidence-worker.exe']
rows=[dict(path=str(p.relative_to(R)).replace('\\','/'),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(core)]
value=dict(source_runtime=rows,models=load(DOC/'ASSETS.json'),no_numeric_GGML_DLL_changes=True,upstream_lineage='NOT_CERTIFIED_LOCAL_BYTES_BOUND')
save(R/'SOURCE_IDENTITY.json',dict(sha256=hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest(),identity=value))
save(R/'ZERO_FORWARD_PLAN.json',dict(stage='F0P',arms=['R_stock','C_k1'],action='probe',observation_mode='counts',request_count=0,maximum_attempts=6,planned_attempts=2,signed_dedicated_headroom_bytes=536870912,trace_preflight='TRACE_PREFLIGHT.json',trace_stop_reason='RESIDENCY_PROOF_UNAVAILABLE_NONADMIN_GPUVIEW_ABSENT',no_automatic_elevation=True,no_ETW_started=True))
save(R/'PHYSICAL_RESIDENCY_STATUS.json',dict(status='RESIDENCY_PROOF_UNAVAILABLE',physical_residency='UNKNOWN',preflight_sha256=sha(R/'TRACE_PREFLIGHT.json'),reason='Current token nonadministrator; GPUView/decoder unavailable; no allocation-to-weight/KV map. No tracing or elevation attempted.',formal_same_scope_certificate=None,fully_resident_qualified_ratio=None,main_request_study_blocked=False,trace_setup_unit_used=0))
print('inventory',load(R/'HOST_INVENTORY.json'))
