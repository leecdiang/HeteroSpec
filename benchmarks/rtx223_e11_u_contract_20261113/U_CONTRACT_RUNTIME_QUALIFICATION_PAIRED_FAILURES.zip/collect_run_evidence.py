"""Preserve real qualification and both pre-native failures; no GPU calls."""
from pathlib import Path
import json,hashlib,shutil,csv,struct,datetime
p=Path(__file__).resolve().parent;state=Path('D:/HeteroSpec-PC/rtx223-e11-u-contract');sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
stage=json.loads((p/'STAGING_V3.json').read_bytes());profile=Path(stage['profile']);evidence=p/'evidence-run'
files=[]
for q in sorted(profile.parent.rglob('*')):
 if q.is_file():
  target=evidence/'profile'/q.relative_to(profile.parent);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(q,target);assert sha(q)==sha(target)
  files.append(dict(original=str(q),preserved=str(target),sha256=sha(q),bytes=q.stat().st_size))
for name in ['cpu-001','cpu-002','qualification-001','timing-001','timing-002']:
 target=evidence/name;target.mkdir(parents=True,exist_ok=True)
 for q in (state/name).iterdir():
  if q.is_file():shutil.copy2(q,target/q.name);assert sha(q)==sha(target/q.name)
with (p/'PROFILE_DATA_PRESERVED.json').open('x',encoding='utf8') as f:json.dump(dict(files=files,utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),f,indent=2)
host=json.loads((state/'timing-002/HOST.private.json').read_bytes());match=[x for x in host['all_processes'] if x['ProcessId']==39736]
foreign=dict(NVML_observed_utc='2026-11-13T04:40:54.304471+00:00',NVML_pids=[39736],owned_pid=0,host_snapshot_start=host['start_utc'],host_snapshot_end=host['end_utc'],snapshot_process=match,identity_limit='Snapshot about5s earlier,not simultaneous creation-time binding;PID reuse not conclusively excluded;current lookup no live39736',timing_native_created=False,timing_explicit_permits=0,guard_not_relaxed=True,unrelated_processes_terminated=0,ToDesk_configuration_changes=0)
with (p/'FOREIGN_CONTEXT_002.private.json').open('x',encoding='utf8') as f:json.dump(foreign,f,indent=2)
public=foreign.copy();public['snapshot_process']=[dict(pid=x['ProcessId'],parent_pid=x['ParentProcessId'],name=x['Name'],path=x['ExecutablePath'],video_session_arg='--isVideoSession=true') for x in match]
with (p/'FOREIGN_CONTEXT_002.json').open('x',encoding='utf8') as f:json.dump(public,f,indent=2)
qual=profile/'Temp/e11-qualification-001';old=p.parent/'rtx223-e10-fewrow';oldqual=old/'evidence/profile/AC/Temp/e10-qualification-001'
assert (qual/'U-r0-activation.bin').read_bytes()==(oldqual/'U-r0-activation.bin').read_bytes()
assert (qual/'U-r0-output.bin').read_bytes()==(oldqual/'U-r0-output.bin').read_bytes()
bindings=[]
for n in ['QUANT_DIFFERENCES.csv','SCALE_DIFFERENCES.csv','OUTPUT_DIFFERENCES.csv']:
 shutil.copy2(old/n,p/n);bindings.append(dict(path=n,sha256=sha(p/n),reused_from=str(old/n),reason='Current U raw bytes exactly match oldU;no old contract status changed'))
y=(qual/'U-r0-output.bin').read_bytes();b=(Path(stage['stage'])/'backend-output.f32').read_bytes();count=0;maximum=0
with (p/'OUTPUT_DIFFERENCES.csv').open(newline='',encoding='utf8') as f:
 for row in csv.DictReader(f):
  i=int(row['column'])*4096+int(row['row']);actual=struct.unpack_from('<I',y,4*i)[0];reference=struct.unpack_from('<I',b,4*i)[0]
  assert actual==int(row['U_bits'],16) and reference==int(row['legacy_bits'],16) and actual!=reference
  maximum=max(maximum,float(row['absolute_difference']));count+=1
assert count==32766
with (p/'RAW_DIFFERENCE_BINDING.json').open('x',encoding='utf8') as f:json.dump(dict(pass_=True,current_U_quant_sha256=sha(qual/'U-r0-activation.bin'),current_U_output_sha256=sha(qual/'U-r0-output.bin'),reused_CSVs=bindings,all_output_difference_rows_independently_checked=count,max_abs_difference_vs_legacy=maximum,old_e10='FAIL_UNCHANGED'),f,indent=2)
print(json.dumps(dict(preserved_profile_files=len(files),output_difference_rows=count,maximum_legacy_error=maximum)))
