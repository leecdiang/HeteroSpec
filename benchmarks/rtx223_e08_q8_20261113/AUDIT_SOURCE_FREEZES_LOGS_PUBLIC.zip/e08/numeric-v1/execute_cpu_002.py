from pathlib import Path
import hashlib,runpy,sys,json
p=Path(__file__).resolve().parent
plan=p/"CPU_PLAN_002.json"
assert hashlib.sha256(plan.read_bytes()).hexdigest()=="ebed8dc6a27115a67819e64daa40a765b9b63345894fab137413e3c1add4821b"
for row in json.loads(plan.read_bytes())["controller_inputs"]:
 assert hashlib.sha256(Path(row["path"]).read_bytes()).hexdigest()==row["sha256"]
sys.argv=[str(p/"runner-v2.py"),str(plan)]
runpy.run_path(str(p/"runner-v2.py"),run_name="__main__")
