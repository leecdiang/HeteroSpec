from runtime import *
assert load(R/'ENGINEERING_GATE.json')['status']=='PASS'
rows=load(R/'ENGINEERING_RECORDS.json')
costs={}
for arm in ARMS:
 rr=[r for r in rows if r['condition']==arm and r['measurement_mode']=='counts' and r['kind']=='exposed']
 longest=next(r for r in rows if r['condition']==arm and r['kind']=='longest')
 assert len(rr)==24
 maximum=max(r['wall_ms'] for r in rr)/1000
 extra=longest['wall_ms']/1000
 costs[arm]=dict(max_exposed_request_seconds=maximum,actual_longest_768_seconds=extra,budget_request_ceiling_seconds=2*maximum+extra,formal_requests=240)
life=[load(p) for p in (R/'raw').glob('*/LIFECYCLE.json')]
owned=sum(r['owned_seconds'] for r in life)
loaded=[e for e in ledger() if e['event']=='WORKER_START'];closed=[e for e in ledger() if e['event']=='WORKER_CLOSED'];assert len(loaded)==len(closed)
start={e['block']:e for e in loaded}
dur=[]
for p in (R/'raw').glob('*/COMMAND.json'):
 b=p.parent.name
 if not b.startswith('probe'):
  events=[e for e in ledger() if e.get('block')==b and e['event']=='REQUEST_STARTED']
  # Includes runtime identity checks before paid warmup, conservatively priced.
  first=min(events,key=lambda e:e['utc']);from datetime import datetime
  dur.append(datetime.fromisoformat(first['utc']).timestamp()-start[b]['epoch'])
load_max=max(dur)
warm=[load(p) for p in (R/'records').glob('*.json') if load(p).get('warmup')]
warm_max=max(r['wall_ms'] for r in warm)/1000
central=sum(240*x['budget_request_ceiling_seconds'] for x in costs.values())+50*(load_max+warm_max+1)
remaining=28800-owned
forecast=dict(status='PASS_FULL_FORMAL_WITH_MARGIN' if central*1.5<remaining else 'BUDGET_FORECAST_BLOCKED',utc=now(),owned_gpu_seconds_already_spent=owned,remaining_owned_gpu_seconds=remaining,formal_request_budget=1200,formal_warmup_budget=50,max_observed_load_and_identity_seconds=load_max,max_observed_paid_warmup_seconds=warm_max,by_arm=costs,complete_formal_budget_seconds=central,margin_multiplier=1.5,complete_formal_seconds_with_margin=central*1.5,all24_new_prompt_lengths=[len(t['prompt_ids']) for t in load(R/'CONFIRMATION_INPUTS.json')['families']['Llama']],basis='Empirical budget forecast only: double exposed maximum plus the actual768-ID request as prompt allowance, then1.5 margin. No mechanistic coefficients fitted.',hard_stops='fixed units, per-request budget admission, native memory failure, lifecycle watchdog before28800seconds',model_timing_unavailable_does_not_block=True)
save(R/'F0B_BUDGET_FORECAST.json',forecast)
assert forecast['status']=='PASS_FULL_FORMAL_WITH_MARGIN',forecast
print('BUDGET_FORECAST_PASS',round(central*1.5/3600,2),'hours plus spent',round(owned/3600,2),flush=True)
