"""Publish only additive audit sources/results; never binaries, GGUF or host command lines."""
from pathlib import Path
import json,hashlib,zipfile,shutil,re,datetime,base64
p=Path(__file__).resolve().parent;d=p/'delivery';d.mkdir(exist_ok=False)
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
names=['AGENTS.md','REPORT_ZH.md','SOURCE_COMPARISON_ZH.md','CONTRACT.json','RESULT.json','DIFFERENCES.json','QUANT_DIFFERENCES.csv','SCALE_DIFFERENCES.csv','PAIRED_SAMPLES.csv','TIMING_NOT_RUN.json','FAST_MATH_DIAGNOSIS.json','UPSTREAM_SOURCE.json','UPSTREAM_PR.json','UPSTREAM_DATES.json','UPSTREAM_BLOBS_VERIFIED.json','PARENT_REUSE_VERIFIED.json','C1_PARENT_VERIFIED.json','CPU_SMOKE_PASS.json','STATIC_ADMISSION.json','CPU_LAYOUT_CHECK.json','CPU_NUMERICAL_DOMAIN.json','STAGING.json','FINAL_IDENTITIES.json','CLEANUP_FINAL.json','GPU_FINAL_OBSERVATION.json','PROFILE_CREATED.json','PROFILE_CLEANUP.json','PROFILE_DATA_PRESERVED.json','EXECUTION_FAILURES.json','PREPARATION_FAILURES.json','runner.py','observation.py','admin_controller.py','prepare_phase.py','build_diagnostic_v2.py','main_body_v2.inc','upstream_wrap.cu','analyze_failure.py','finalize_checks.py','Collect-Host.ps1']
for n in names:shutil.copy2(p/n,d/n)
archive=d/'FEWROW_AUDIT_SOURCE_FREEZES_LOGS.zip';members=[]
def add(z,q,name):
 data=q.read_bytes()
 if q.suffix in ('.py','.cu','.cuh','.cpp','.h','.hpp','.inc','.ptx','.json','.jsonl','.log','.md','.ps1','.csv'):
  assert not re.search(rb'(?:sk-[A-Za-z0-9_-]{20,}|gh[pousr]_[A-Za-z0-9]{30,}|Bearer [A-Za-z0-9._-]{30,})',data),'Potential secret '+str(q)
 z.writestr(name,data);members.append(dict(path=name,sha256=sha(q),bytes=len(data)))
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for q in sorted(p.iterdir()):
  if q.is_file() and q.suffix in ('.py','.inc','.cu','.ps1','.md','.json','.ptx','.csv') and '.private.' not in q.name:
   add(z,q,q.name)
 for build in ('build-001','build-002'):
  for n in ['BUILD.json','FREEZE.json','COMMANDS.json','main.log','upstream_wrap.log','link.log','main.cu','bound_few_prefix.cuh','bound_few_quantizer.cuh','bound_mmvq_prefix.cuh','bound_quantizer.cuh','upstream_wrap.cu','main.d','upstream_wrap.d']:
   add(z,p/build/n,build+'/'+n)
 for n in ['counter.cpp','RESULT.json']:add(z,p/'counter-cpu-001'/n,'counter-cpu-001/'+n)
 for q in (p/'evidence').rglob('*'):
  if q.is_file() and q.suffix in ('.json','.jsonl','.stdout','.stderr') and '.private.' not in q.name:add(z,q,'evidence/'+q.relative_to(p/'evidence').as_posix())
 for q in (p/'admin-queue').iterdir():
  if q.is_file():add(z,q,'admin-queue/'+q.name)
 add(z,p/'u/LICENSE','LICENSE_LLAMA_CPP')
 add(z,p.parent/'rtx223-e08/numeric-v1/operator-build-005/two_group_q8.cuh','prior-source/two_group_q8.cuh')
 add(z,p.parent/'rtx223-e09-c1/c1_serial_groups.cuh','prior-source/c1_serial_groups.cuh')
(d/'ARCHIVE_MANIFEST.json').write_text(json.dumps(dict(path=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,entries=members,not_included=['GGUF','weight/activation/output binaries','EXE/DLL','full host command lines','copied runtime/toolchain','entire upstream archive'],raw_data_local_preserved=True),indent=2),encoding='utf8')
# Local CLI upload input is private and outside the public delivery directory.
(p/'publish_blob.private.json').write_text(json.dumps(dict(encoding='base64',content=base64.b64encode(archive.read_bytes()).decode())),encoding='utf8')
records=[dict(path=q.name,sha256=sha(q),bytes=q.stat().st_size) for q in sorted(d.iterdir())]
(d/'DELIVERY_MANIFEST.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),files=records),indent=2),encoding='utf8')
print(json.dumps(dict(files=len(records)+1,archive_bytes=archive.stat().st_size,archive_entries=len(members),archive_sha256=sha(archive))))
