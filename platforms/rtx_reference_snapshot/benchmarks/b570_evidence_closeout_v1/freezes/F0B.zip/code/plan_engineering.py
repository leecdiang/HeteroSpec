from common import *
sys.path.insert(0,str(REPO/'scripts/platform/b570_evidence_closeout_v1'))
import closeout
d=load(DOC/'DESIGN.json');e=load(R/'PR88_ENGINEERING_INPUTS.json');synt=load(R/'PR88_SYNTHETIC_INPUTS.json');arms=[c['name'] for c in d['conditions']]
blocks=[]
for arm in arms:
 req=[]
 for repeat in [1,2]:
  for t in e:req.append(dict(slot='core|'+arm+'|'+t['id']+'|'+str(repeat),task=t['id'],cap=128,repeat=repeat,observation='counts',kind='exposed'))
 for t in synt:
  if t['id'] in ['SYNTHETIC/BOUNDARY_A','SYNTHETIC/BOUNDARY_B']:
   for cap in [1,2,3,4,31,32,128]:req.append(dict(slot='boundary|'+arm+'|'+t['id']+'|'+str(cap),task=t['id'],cap=cap,observation='counts',kind='boundary'))
  elif t['id']=='SYNTHETIC/LONGEST_768':req.append(dict(slot='longest|'+arm,task=t['id'],cap=128,observation='counts',kind='longest'))
 blocks.append(dict(block='core_'+arm,arm=arm,bucket='core',warmup='SYNTHETIC/WARM',warmup_mode='counts',requests=req))
for arm in ['R_stock','C_k1']:
 req=[]
 for t in synt:
  if t['id'] in ['SYNTHETIC/BOUNDARY_A','SYNTHETIC/BOUNDARY_B']:
   for cap in [1,2,3,4,31,32,128]:req.append(dict(slot='heavyboundary|'+arm+'|'+t['id']+'|'+str(cap),task=t['id'],cap=cap,observation='heavy',kind='heavyboundary'))
  elif t['id']=='SYNTHETIC/LONGEST_768':req.append(dict(slot='heavylongest|'+arm,task=t['id'],cap=128,observation='heavy',kind='heavylongest'))
 blocks.append(dict(block='heavy_'+arm,arm=arm,bucket='core',warmup='SYNTHETIC/WARM',warmup_mode='counts',requests=req))
modes=d['mechanism']['profile_modes']
for arm in d['mechanism']['profile_arms']:
 req=[]
 for i,tid in enumerate(d['mechanism']['calibration_task_ids']):
  row=modes[i%4:]+modes[:i%4]
  for rank,mode in enumerate(row):req.append(dict(slot='profile|'+arm+'|'+tid+'|'+mode,task=tid,cap=128,observation=mode,kind='profile',task_index=i,mode_order=row,mode_rank=rank))
 blocks.append(dict(block='profile_'+arm,arm=arm,bucket='profile',warmup='SYNTHETIC/WARM',warmup_mode='counts',requests=req))
plan=dict(schema='heterospec.b570.pr90.engineering_plan.v1',blocks=blocks,core_units=2+sum(1+len(b['requests']) for b in blocks if b['bucket']=='core'),profile_units=sum(1+len(b['requests']) for b in blocks if b['bucket']=='profile'),probe_units=2,probe_limit=6,total_engineering_limit=384,formal_units=1200,formal_warmups=50,planned_units_including_formal=0,profile_mode_switch='per request before native reset, same persistent worker per arm',profile_order_finite_imbalance='six task rows cannot evenly balance all four mode positions; raw task/mode ranks retained',no_engineering_reselection=True,formal_mode='counts',retry_policy='No started formal slots replayed; engineering failures charged and stop before any amendment',inputs_sha256=closeout.digest(e),synthetic_sha256=closeout.digest(synt),utc=now())
plan['planned_units_including_formal']=plan['core_units']+plan['profile_units']+1250
assert plan['core_units']==234 and plan['profile_units']==100
save(R/'ENGINEERING_PLAN.json',plan)
print({k:v for k,v in plan.items() if k!='blocks'})
