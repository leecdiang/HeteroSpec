$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$release=Get-Content -LiteralPath (Join-Path $root 'CONTINUATION_RELEASE.json') -Raw|ConvertFrom-Json
foreach($record in $release.files){if((Get-FileHash -LiteralPath $record.path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $record.sha256){throw 'Frozen controller input drift'}}
$python=Join-Path (Split-Path $root -Parent) 'rtx223-e08/python311/python.exe'
$script=Join-Path $root 'admin_continuation.py'
$process=Start-Process -FilePath $python -ArgumentList @('-I','-B','-S',$script) -Verb RunAs -WindowStyle Hidden -PassThru
$record=[ordered]@{pid=$process.Id;script=$script;sha256=(Get-FileHash -LiteralPath $script -Algorithm SHA256).Hash;utc=[DateTimeOffset]::UtcNow.ToString('o');scope='e11 append-only continuation of already charged416 timing reservation;500 total unchanged,120 seconds per run, no ACL or Windhawk setting changes'}
$record|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $root 'ADMIN2_LAUNCH.json') -Encoding utf8
