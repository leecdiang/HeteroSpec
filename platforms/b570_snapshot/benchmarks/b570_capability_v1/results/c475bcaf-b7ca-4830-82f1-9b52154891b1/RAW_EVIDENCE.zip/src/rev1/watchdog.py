"""Independent CPU deadline/heartbeat/outer Job owner. Cannot attest its own OS exit."""
import argparse,datetime,json,os,shutil,sys,time,traceback
from pathlib import Path
from win import *
p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--run',required=True);p.add_argument('--mode',choices=['development','measured'],required=True);p.add_argument('--phase-limit',type=float,default=15000);a=p.parse_args()
ROOT=check_root(a.root);RUN=(ROOT/a.run).resolve();need(ROOT in RUN.parents,'run confinement');RUN.mkdir(exist_ok=False)
os.environ['TEMP']=os.environ['TMP']=str(ROOT/'tmp')
acq=json.loads((ROOT/'ACQUISITION.json').read_text());age=max(0,(datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(acq['first_preparation_utc'].replace('Z','+00:00'))).total_seconds());task_remaining=21600-age
if a.mode=='development':need(age<5400,'D0_90_MINUTE_LIMIT')
begin=now();deadline=begin+int(min(a.phase_limit,task_remaining-(60 if a.mode=='development' else 0))*1e9)
need(deadline>begin,'TASK_DEADLINE');J=Journal(RUN/'WATCHDOG.jsonl');M=Journal(RUN/'WATCHDOG_SAMPLES.jsonl');job=make_job();child=None;registered=None;last_sample=None;last_heartbeat=None;error=None;closed=False;terminating=None;observed_residual=[]
def monitor():
    global last_sample,last_heartbeat
    t=now();need(last_sample is None or t-last_sample<=5_000_000_000,'WATCHDOG_MONITOR_GAP')
    if last_sample is not None and t-last_sample<1_000_000_000:return
    ready=RUN/'HEARTBEAT.json';hb=None
    if ready.exists():
        hb=json.loads(ready.read_text());need(hb['pid']==child.pid,'heartbeat identity');need(hb['at_ns']<=t,'heartbeat clock');last_heartbeat=hb['at_ns']
    age_ns=t-(last_heartbeat if last_heartbeat is not None else begin);need(age_ns<=10_000_000_000,'SUPERVISOR_HEARTBEAT_TIMEOUT')
    members=job_pids(job);rows=[]
    for pid in members:
        h=open_process(0x100410,False,pid)
        if not h:
            need(pid not in job_pids(job),'resource open failed while still in job');rows.append(dict(pid=pid,exit_race=True,rss_bytes=None));continue
        try:
            ts=os_times(h)
            if alive(h):rows.append(dict(pid=pid,created_filetime=ts['created_filetime'],rss_bytes=rss(h)))
            else:rows.append(dict(pid=pid,created_filetime=ts['created_filetime'],exit_race=True,rss_bytes=None))
        finally:checked(close(h),'Close resource process handle')
    own=rss(current());need(own<=512*1024**2,'WATCHDOG_RSS')
    sup=[r for r in rows if r['pid']==child.pid and r['rss_bytes'] is not None];actors=[r for r in rows if r['pid']!=child.pid and r['rss_bytes'] is not None]
    need(all(r['rss_bytes']<=512*1024**2 for r in sup) and len(actors)<=8 and all(r['rss_bytes']<=256*1024**2 for r in actors),'JOB_PROCESS_MEMORY')
    total=own+sum(r['rss_bytes'] or 0 for r in rows);need(total<=1536*1024**2,'AGGREGATE_MEMORY')
    free=shutil.disk_usage(ROOT).free;need(free>=10*1024**3,'DISK_FREE')
    storage=hb.get('storage_upper_bytes') if hb else None
    if storage is not None:need(storage<=1024**3,'STORAGE_LIMIT')
    end=now();need(last_sample is None or end-last_sample<=5_000_000_000,'WATCHDOG_MONITOR_GAP')
    M.emit('SAMPLE',begin_ns=t,end_ns=end,gap_ns=None if last_sample is None else end-last_sample,job_active=len(members),job_members=rows,watchdog_rss=own,total_observed_rss=total,heartbeat_age_ns=age_ns,storage_upper_bytes=storage,disk_free_bytes=free)
    last_sample=end
def capture_residual():
    for pid in job_pids(job):
        if child and pid==child.pid:continue
        h=open_process(0x100410,False,pid)
        if h:
            ident=identity(h);observed_residual.append((pid,h,ident));J.emit('RESIDUAL_RETAINED',pid=pid,**ident)
try:
    J.emit('WATCHDOG_START',pid=os.getpid(),begin_ns=begin,deadline_ns=deadline,unobserved_own_exit=True,**identity(current()))
    if a.mode=='measured':freeze_check(ROOT)
    argv=[sys.executable,'-B',str(Path(__file__).resolve().parent/'supervisor.py'),'--root',str(ROOT),'--run',a.run,'--mode',a.mode,'--watchdog-pid',str(os.getpid()),'--deadline-ns',str(deadline)]
    child=spawn_suspended(argv,ROOT,RUN/'SUPERVISOR.stdout.log',RUN/'SUPERVISOR.stderr.log');registered=identity(child.process)
    J.emit('SUPERVISOR_CREATED_SUSPENDED',pid=int(child.pid),argv=argv,**registered)
    checked(job_assign(job,child.process),'Assign supervisor outer Job');J.emit('OUTER_JOB_ASSIGNED',pid=int(child.pid))
    need(resume(child.thread)!=0xffffffff,'ResumeThread');J.emit('SUPERVISOR_RESUMED',pid=int(child.pid));checked(close(child.thread),'Close supervisor thread');child.thread=None;J.emit('HANDLE_CLOSED',handle_kind='supervisor_primary_thread')
    while alive(child.process):
        try:
            need(now()<deadline,'WATCHDOG_HARD_DEADLINE');monitor()
        except BaseException as e:
            if error is None:error=repr(e);J.emit('WATCHDOG_FAILURE',error=error);capture_residual();terminate_job(job);terminating=now();J.emit('OUTER_JOB_TERMINATE',reason=error)
        if terminating is not None and now()-terminating>5_000_000_000:raise RuntimeError('SUPERVISOR_CLEANUP_UNCONFIRMED')
        time.sleep(.02)
    J.emit('SUPERVISOR_EXIT_OBSERVED',pid=int(child.pid));ts=os_times(child.process);code=exit_code(child.process)
    need(ts['created_filetime']==registered['created_filetime'] and int(ts['exit_filetime'])>int(ts['created_filetime']),'SUPERVISOR_OS_EXIT')
    J.emit('SUPERVISOR_OS_EXIT',pid=int(child.pid),exit_code=code,**ts)
    remaining=job_pids(job)
    if remaining:
        if error is None:error='SUPERVISOR_EXIT_WITH_LIVE_DESCENDANTS'
        capture_residual();terminate_job(job);cutoff=now()+5_000_000_000
        while job_pids(job) and now()<cutoff:time.sleep(.01)
    need(not job_pids(job),'OUTER_JOB_NOT_EMPTY');J.emit('OUTER_JOB_EMPTY',active_pids=[])
    for pid,h,ident in observed_residual:
        need(not alive(h),'RESIDUAL_STILL_LIVE');end=os_times(h);J.emit('RESIDUAL_OS_EXIT',pid=pid,exit_code=exit_code(h),**end);checked(close(h),'Close residual');J.emit('HANDLE_CLOSED',pid=pid,handle_kind='residual_process')
    checked(close(child.process),'Close supervisor process');child.process=None;J.emit('HANDLE_CLOSED',handle_kind='supervisor_process')
    checked(close(job),'Close outer Job');job=None;J.emit('HANDLE_CLOSED',handle_kind='outer_job');closed=True
    summary=json.loads((RUN/'SUMMARY.json').read_text()) if (RUN/'SUMMARY.json').exists() else None
    if code!=0 and error is None:error='SUPERVISOR_NONZERO_EXIT'
    receipt=dict(status='WATCHDOG_CLOSED' if closed and error is None else 'WATCHDOG_FAILED',supervisor_pid=int(child.pid),supervisor_exit_code=code,supervisor_os_times=ts,outer_job_empty=True,owned_handles_closed=True,error=error,begin_ns=begin,end_ns=now(),task_elapsed_before_watchdog_seconds=age,summary_status=summary.get('status') if summary else None,watchdog_pid=os.getpid(),watchdog_os_exit_time=None,command_shell_os_lifetime=None,tool_host_os_lifetime=None,scope='Watchdog independently observes supervisor exit and outer Job; watchdog/shell/tool host own closure is outside this boundary')
    J.emit('WATCHDOG_END',receipt=receipt);dump_new(RUN/'WATCHDOG_RECEIPT.json',receipt)
except BaseException as e:
    error=repr(e);J.emit('WATCHDOG_EXCEPTION',error=error,traceback=traceback.format_exc())
    if job:
        try:terminate_job(job);J.emit('OUTER_JOB_EMERGENCY_TERMINATE')
        except BaseException as cleanup:J.emit('CLEANUP_ERROR',error=repr(cleanup))
    dump_new(RUN/'WATCHDOG_INCOMPLETE.json',dict(error=error,cleanup_confirmed=False,supervisor_pid=int(child.pid) if child else None,at_ns=now()))
finally:
    if job:close(job)
    if child:
        if child.thread:close(child.thread)
        if child.process:close(child.process)
    J.end();M.end()
print(json.dumps(dict(watchdog_closed=closed,error=error,run=a.run)),flush=True)
sys.exit(0 if closed and error is None else 1)
