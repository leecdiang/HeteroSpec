from common import *
head='92d08d80bd8e8f567ec02c3b1d5b04dd452b3efe';assert git('rev-parse','HEAD').decode().strip()==head
rows=[]
for line in git('diff-tree','--no-commit-id','--name-only','-r','4db9bc501fa01c76db50721e7d11e9a0d1e53782',head).decode().splitlines():
 b=git('show',head+':'+line);assert b==(REPO/line).read_bytes();rows.append(dict(path=line,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
save(R/'DESIGN_RECHECK.json',dict(status='PASS',head=head,files=rows))
for x in load(DOC/'SOURCE_BINDINGS.json')['files']:
 b=git('show',x['head']+':'+x['path']);assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256'];assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==x['sha']
save(R/'SOURCE_BINDINGS_RECHECK.json',dict(status='PASS',files=load(DOC/'SOURCE_BINDINGS.json')['files'],cross_platform_context_annotation='Design cross_platform_context.head repeats B570 head; never treated as authoritative RTX source. Actual RTX PR84 source fetched separately for history.'))
dest=Path('C:/hs/b570-evidence-pr88-readback-v1');assert not dest.exists()
p=subprocess.run([str(GIT),'clone','--filter=blob:none','--depth','1','--branch','codex/b570-memory-followup-run-20261011','--no-checkout','https://github.com/leecdiang/HeteroSpec.git',str(dest)],capture_output=True);save(R/'PR88_CLONE.json',dict(returncode=p.returncode,stderr=p.stderr.decode(errors='replace')));assert p.returncode==0
assert git('rev-parse','HEAD',cwd=dest).decode().strip()=='4db9bc501fa01c76db50721e7d11e9a0d1e53782'
meta=load(REPO/'benchmarks/b570_memory_followup_v1/CAS_INDEX.json');paths=['benchmarks/b570_memory_followup_v1/CAS_INDEX.json']+[x['repo_path'] for x in meta['parts']];objects=[git('rev-parse','HEAD:'+p,cwd=dest).decode().strip() for p in paths]
p=subprocess.run([str(GIT),'-c','fetch.negotiationAlgorithm=noop','fetch','origin','--no-tags','--no-write-fetch-head','--filter=blob:none','--stdin'],input=('\n'.join(objects)+'\n').encode(),capture_output=True,cwd=dest);save(R/'PR88_FETCH.json',dict(returncode=p.returncode,stderr=p.stderr.decode(errors='replace')));assert p.returncode==0
arc=R/'PR88_ACTUAL_REMOTE.zip'
with arc.open('wb') as out:
 for x in meta['parts']:
  b=git('show','HEAD:'+x['repo_path'],cwd=dest);assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256'];out.write(b)
assert arc.stat().st_size==meta['archive_bytes'] and sha(arc)==meta['archive_sha256']
rest=Path('C:/hs/b570-evidence-pr88-restored-v1');rest.mkdir()
with zipfile.ZipFile(arc) as z:
 assert z.testzip() is None;idx=json.loads(z.read('INDEX.json'))
 for rel,m in idx['files'].items():
  b=z.read('objects/'+m['sha256']);assert len(b)==m['bytes'] and hashlib.sha256(b).hexdigest()==m['sha256'];p=rest/rel;assert p.resolve().is_relative_to(rest.resolve());p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
expected=load(rest/'INDEPENDENT_VERIFICATION.json');p=subprocess.run([sys.executable,'-X','utf8',str(rest/'code/independent_verify.py'),str(rest)],capture_output=True,text=True,encoding='utf8');assert p.returncode==0,p.stderr;assert load(rest/'INDEPENDENT_VERIFICATION.json')==expected
save(R/'PR88_FRESH_RESTORE.json',dict(status='PASS',utc=now(),actual_remote_head='4db9bc501fa01c76db50721e7d11e9a0d1e53782',CAS_sha256=meta['archive_sha256'],logical_files=len(idx['files']),independent_checks=expected['checks'],complete_restoration_and_rederivation_identical=True,restore=str(rest),stdout=p.stdout))
for folder in ['native','dependencies','vocab']:
 shutil.copytree(rest/folder,R/folder)
(R/'versions').mkdir();shutil.copytree(rest/'build/Release',R/'versions/PR88-bin');shutil.copyfile(rest/'native/worker.cpp',R/'versions/PR88-worker.cpp')
(R/'build/Release').mkdir(parents=True)
for p in (rest/'build/Release').glob('*'):
 if p.suffix in ['.dll','.lib']:shutil.copyfile(p,R/'build/Release'/p.name)
for name in ['ENGINEERING_INPUTS.json','SYNTHETIC_INPUTS.json','ASSET_CHECKS.json','VOCAB_CHECKS.json','HISTORY_AUDIT.json','HISTORY_CATALOG.json','DATASET_BINDINGS.json']:
 shutil.copyfile(rest/name,R/('PR88_'+name))
print('PR88 full real Git/CAS restored',len(idx['files']),expected['checks'],flush=True)
