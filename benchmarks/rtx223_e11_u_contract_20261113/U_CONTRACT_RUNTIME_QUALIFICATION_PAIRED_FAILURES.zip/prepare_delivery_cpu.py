"""Public additive handoff; includes failure logs, excludes binary/data/host dumps."""
from pathlib import Path
import json,hashlib,zipfile,shutil,base64,re,datetime
p=Path(__file__).resolve().parent;d=p/'delivery';d.mkdir(exist_ok=False)
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
host=json.loads((p/'HOST_FINAL.private.json').read_bytes());assert not host['project_tasks'] and not host['project_services'] and not host['competing_workers']
summary=dict(utc=host['end_utc'],read_only_snapshot=True,host_process_count=len(host['all_processes']),host_task_count=len(host['all_tasks']),project_tasks=host['project_tasks'],project_services=host['project_services'],competing_workers=host['competing_workers'],canonical_lease_exists=Path('D:/HeteroSpec-PC/RTX_EXPERIMENT.lock').exists(),runner_lease_exists=Path('D:/HeteroSpec-PC/rtx223-e11-u-contract/runner.lease').exists(),controller_started=False,profile_created=False,queued_JSON_requests=0,limits='point-in-time snapshot;deep CIM metadata Depth7 warning;full command lines kept private;not proof against future externally-created tasks')
assert not summary['canonical_lease_exists'] and not summary['runner_lease_exists']
(p/'HOST_SUMMARY.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
names=['AGENTS.md','REPORT_ZH.md','RESUME_ZH.md','NUMERICAL_CONTRACTS_ZH.md','BACKEND_BOUNDARIES_ZH.md','ENGINEERING_FAILURES_ZH.md','AMDAHL_METHOD_ZH.md','NEXT_SINGLE_CANDIDATE_ZH.md','CONTRACT.json','RESULT.json','PRE_GPU_RESULT.json','PRE_GPU_SAMPLES.csv','PREPARATION_LEDGER.jsonl','PERFORMANCE_DECISION.json','PARENT_HEADS.json','PARENTS_VERIFIED.json','PARENT_REUSE_VERIFIED.json','UPSTREAM_SOURCE.json','UPSTREAM_BLOBS_VERIFIED.json','PORTABLE_TOOLS.json','CURRENT_PRIVILEGE.json','HOST_SUMMARY.json','FINAL_IDENTITIES.json','COMPILER_RESOURCES.json','FINAL_GPU_OBSERVATION.json','FINAL_COMPUTE_OBSERVATION.json','STAGING_V3.json','STATIC_ADMISSION_V3.json','CPU_DOMAIN_V3.json','FULL_BACKEND_BUILD_IDENTITY_V3.json','CONTROL_AMENDMENT_V3.json','u_oracle.hpp','oracle_cpu.cpp','validate_capture_cpu.cpp','main_body_v3.inc','upstream_wrap_v2.cu','build_diagnostic_v3.py','runner_v3.py','admin_controller.py','prepare_phase_v3.py','independent_qualification_v3.py','analyze_v3.py']
for name in names:shutil.copy2(p/name,d/name)
archive=d/'U_CONTRACT_AUDIT_SOURCE_FREEZES_FAILURES.zip';members=[]
def add(z,q,name):
 b=q.read_bytes();assert not re.search(rb'(?:sk-[A-Za-z0-9_-]{20,}|gh[pousr]_[A-Za-z0-9]{30,}|Bearer [A-Za-z0-9._-]{30,})',b),'potential secret '+str(q)
 z.writestr(name,b);members.append(dict(path=name,sha256=sha(q),bytes=len(b)))
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for q in sorted(p.iterdir()):
  if q.is_file() and q.suffix in ('.py','.hpp','.inc','.cu','.cpp','.ps1','.md','.json','.jsonl','.csv') and '.private.' not in q.name:add(z,q,q.name)
 add(z,p/'ADMIN_STOP','ADMIN_STOP')
 for folder in ['build-001','build-002','build-003']:
  for n in ['BUILD.json','FREEZE.json','COMMANDS.json','main.cu','upstream_wrap.cu','u_oracle.hpp','bound_few_prefix.cuh','bound_few_quantizer.cuh','bound_mmvq_prefix.cuh','bound_quantizer.cuh','main.log','upstream_wrap.log','link.log','main.d','upstream_wrap.d']:
   q=p/folder/n
   if q.exists():add(z,q,folder+'/'+n)
 for folder in ['oracle-cpu-001','capture-cpu-001','counter-cpu-001','counter-cpu-diagnosis','counter-cpu-002']:
  for q in (p/folder).iterdir():
   if q.is_file() and q.suffix in ('.cpp','.json','.log'):add(z,q,folder+'/'+q.name)
 for folder in ['full-backend-001','full-backend-002']:
  for n in ['INPUTS.json','RESULT.json','configure.stdout.log','configure.stderr.log','build.stdout.log','build.stderr.log','build/CMakeCache.txt']:
   q=p/folder/n
   if q.exists():add(z,q,folder+'/'+n)
 for q in (p/'admin-queue').iterdir():
  if q.is_file():add(z,q,'admin-queue/'+q.name)
 add(z,p/'u/LICENSE','LICENSE_LLAMA_CPP')
for name,source in [('ORACLE_CPU_RESULT.json',p/'oracle-cpu-001/RESULT.json'),('COUNTER_CPU_FAIL.json',p/'counter-cpu-001/RESULT.json'),('COUNTER_CPU_PASS.json',p/'counter-cpu-002/RESULT.json'),('OLD_U_CPU_SET_DIAGNOSTIC.json',p/'capture-cpu-001/RESULT.json'),('FULL_BACKEND_COMPILE_RESULT.json',p/'full-backend-002/RESULT.json')]:shutil.copy2(source,d/name)
(d/'ARCHIVE_MANIFEST.json').write_text(json.dumps(dict(archive=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,entries=members,excluded=['GGUF','raw weights/activation/output binaries','EXE/DLL','whole upstream source/tools','full host command lines'],GPU_data_samples=0),indent=2),encoding='utf8')
(p/'publish_blob.private.json').write_text(json.dumps(dict(encoding='base64',content=base64.b64encode(archive.read_bytes()).decode())),encoding='utf8')
(d/'DELIVERY_MANIFEST.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),files=[dict(path=q.name,sha256=sha(q),bytes=q.stat().st_size) for q in sorted(d.iterdir())]),indent=2),encoding='utf8')
print(json.dumps(dict(files=len(list(d.iterdir())),archive_bytes=archive.stat().st_size,archive_sha256=sha(archive),archive_entries=len(members))))
