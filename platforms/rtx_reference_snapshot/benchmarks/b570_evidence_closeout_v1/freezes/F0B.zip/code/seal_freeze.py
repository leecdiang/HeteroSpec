from common import *
import argparse
stage=sys.argv[1];public=PUBLIC/'freezes';public.mkdir(parents=True,exist_ok=True)
archive=public/(stage+'.zip')
assert not archive.exists(),('FREEZE_EXISTS',stage)
selected=[]
for prefix in ['native','dependencies','vocab','code','versions','raw','records','tokenizer','datasets','history_sources','history_evidence']:
 for p in (R/prefix).rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts:selected.append(p)
for p in (R/'build/Release').iterdir():
 if p.suffix in ['.dll','.exe','.txt']:selected.append(p)
selected += [p for p in R.iterdir() if p.is_file() and p.suffix in ['.json','.jsonl','.bin','.stdout','.stderr','.log']]
selected=[p for p in selected if not p.name.startswith(('F0P_','F0A_','F0B_'))]
selected=sorted(set(selected))
entries=[dict(path=str(p.relative_to(R)).replace('\\','/'),bytes=p.stat().st_size,sha256=sha(p)) for p in selected]
runtime=[x for x in entries if x['path'].startswith(('native/','dependencies/','build/Release/')) or x['path'] in ['code/runtime.py','code/common.py','COUNTER_SEMANTICS.json','SOURCE_IDENTITY.json']]
manifest=dict(stage=stage,prepared_utc=now(),no_new_forward_before_f0a=True if stage=='F0P' else None,files=entries,runtime_files=runtime,external_models=load(DOC/'DESIGN.json')['assets']['Llama']['models'],source_identity_sha256=load(R/'SOURCE_IDENTITY.json')['sha256'])
save(R/(stage+'_MANIFEST.json'),manifest);save(public/(stage+'_MANIFEST.json'),manifest)
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in selected:z.write(p,str(p.relative_to(R)).replace('\\','/'))
save(public/(stage+'_ARCHIVE.json'),dict(stage=stage,zip_sha256=sha(archive),bytes=archive.stat().st_size,logical_files=len(entries),manifest_sha256=sha(public/(stage+'_MANIFEST.json'))))
readme=PUBLIC/'README.md'
if not readme.exists():readme.write_text('# B570 PR90 evidence closeout\n\nIndependent execution of PR90 at 92d08d80bd8e8f567ec02c3b1d5b04dd452b3efe. This branch contains prospective source/configuration freezes. Formal trials have not started. No numerical success or residency certification is claimed.\n',encoding='utf8')
git('add','--',str(PUBLIC.relative_to(REPO)))
git('-c','user.name=leecdiang','-c','user.email=leecdiang@users.noreply.github.com','commit','-m',stage+': freeze B570 evidence closeout execution bytes')
commit=git('rev-parse','HEAD').decode().strip()
branch=git('branch','--show-current').decode().strip()
p=subprocess.run([str(GIT),'push','-u','origin',branch],cwd=REPO,capture_output=True,creationflags=subprocess.CREATE_NO_WINDOW)
save(R/(stage+'_PUSH.json'),dict(commit=commit,argv=['git','push','-u','origin',branch],returncode=p.returncode,stdout=p.stdout.decode(errors='replace'),stderr=p.stderr.decode(errors='replace'),utc=now()))
assert p.returncode==0,p.stderr
remote=Path('C:/hs/b570-evidence-readback-v1')
if not remote.exists():git('clone','--filter=blob:none','--no-checkout','--branch',branch,'https://github.com/leecdiang/HeteroSpec.git',str(remote),cwd=R)
else:git('fetch','origin',branch,cwd=remote)
ref=git('rev-parse','origin/'+branch,cwd=remote).decode().strip();assert ref==commit
verified=[]
for name in [stage+'.zip',stage+'_MANIFEST.json',stage+'_ARCHIVE.json']:
 path=str((public/name).relative_to(REPO)).replace('\\','/')
 data=git('show',commit+':'+path,cwd=remote);assert data==(public/name).read_bytes()
 out=R/'remote_blobs'/stage/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(data)
 verified.append(dict(path=path,sha256=sha(out),bytes=len(data)))
with zipfile.ZipFile(R/'remote_blobs'/stage/(stage+'.zip')) as z:
 assert z.testzip() is None
 for e in entries:
  b=z.read(e['path']);assert len(b)==e['bytes'] and hashlib.sha256(b).hexdigest()==e['sha256']
receipt=dict(status='PASS',stage=stage,commit=commit,remote_head=ref,actual_remote_blob_bytes_verified=True,verified=verified,all_archive_members_verified=True,utc=now())
save(R/(stage+'_REMOTE_READBACK.json'),receipt)
print(json.dumps(receipt),flush=True)
