#include "explicit_budget.hpp"
#include <climits>
int main() {
    ApplicationBudget a;
    try{a.reserve(1);return 1;}catch(const std::exception&){}
    a.configure(14);
    for(int i=0;i<14;++i)a.reserve(1);
    try{a.reserve(1);return 2;}catch(const std::exception&){}
    if(a.used!=14)return 3;
    try{a.configure(14);return 4;}catch(const std::exception&){}
    ApplicationBudget b;b.configure(320);b.reserve(8);b.reserve(120);b.reserve(192);
    try{b.reserve(UINT_MAX);return 5;}catch(const std::exception&){}
    if(b.used!=320)return 6;
    ApplicationBudget c;
    try{c.configure(356);return 7;}catch(const std::exception&){}
    return 0;
}
