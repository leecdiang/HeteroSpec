from pathlib import Path
import os,sys,json,subprocess,hashlib,importlib.util
p=Path(__file__).resolve().parent;out=p/'capture-build-004';out.mkdir();(out/'temp').mkdir()
sha=lambda f:hashlib.file_digest(Path(f).open('rb'),'sha256').hexdigest()
def write(f,v):f.write_text(json.dumps(v,indent=2))
old=p/'build-002';recipe=json.loads((old/'COMMANDS.json').read_bytes());cc=recipe['capture_compile'];link=recipe['capture_link'];env=recipe['front_env']
cc=[s.replace(str(old/'capture.cpp'),str(p/'capture-v4.cpp')).replace(str(old/'capture.obj'),str(out/'capture.obj')).replace(str(old/'capture.d'),str(out/'capture.d')) for s in cc]
link=[s.replace(str(old),str(out)) for s in link]
for key in ('TEMP','TMP','ZIG_GLOBAL_CACHE_DIR','ZIG_LOCAL_CACHE_DIR'):
 d=out/key;d.mkdir(exist_ok=True);env[key]=str(d)
write(out/'COMMANDS.json',dict(compile=cc,link=link,env=env))
inputs=json.loads((old/'FREEZE.json').read_bytes())['inputs']
for f in [Path(__file__),p/'capture-v4.cpp',out/'COMMANDS.json']:
 inputs[str(f)]={'sha256':sha(f),'bytes':f.stat().st_size}
write(out/'FREEZE.json',dict(inputs=inputs,change='complete scheduler stop by private typed exception entirely within GNU caller frames, only after synchronized tensor capture; no exception across CUDA MSVC frames',reused_root=sha(old/'ggml-cuda.dll')))
runtime=p.parents[1]/'rtx223-round1-resume-20261112-e04/runtime';sp=importlib.util.spec_from_file_location('closure',runtime/'input_closure_v2.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);held=m.ReadFreeze()
try:
 for f,v in inputs.items():
  held.add(f)
  if sha(f)!=v['sha256']:raise RuntimeError('changed input')
 codes=[]
 for name,cmd in [('compile',cc),('link',link)]:
  with (out/(name+'.log')).open('xb') as f:r=subprocess.run(cmd,cwd=out,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=600)
  codes.append(r.returncode)
  if r.returncode:break
 write(out/'BUILD.json',dict(returncodes=codes,changes=[f for f,v in inputs.items() if sha(f)!=v['sha256']],capture_sha256=sha(out/'capture.exe') if (out/'capture.exe').exists() else None,CUDA_calls=0,DLL_loads=0))
 print((out/'BUILD.json').read_text(),flush=True)
finally:held.release()
