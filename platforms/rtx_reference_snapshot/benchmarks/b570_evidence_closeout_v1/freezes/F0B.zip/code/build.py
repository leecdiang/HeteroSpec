from common import *
p=R/'native/worker.cpp';s=p.read_text(encoding='utf8')
s=s.replace('auto phase_begin=clock_type::now();','auto phase_begin=timed()?clock_type::now():clock_type::time_point{};').replace('auto begin=clock_type::now();if(work)work->inc("sampling_calls");','auto begin=timed()?clock_type::now():clock_type::time_point{};if(work)work->inc("sampling_calls");').replace('auto bind_begin=clock_type::now();','auto bind_begin=timed()?clock_type::now():clock_type::time_point{};')
s=s.replace('emit({{"event","PERSISTED"},{"request_id",rid}});','work=nullptr;emit({{"event","PERSISTED"},{"request_id",rid}});')
p.write_text(s,encoding='utf8')
save(R/'OBSERVATION_IMPLEMENTATION.json',dict(load(R/'OBSERVATION_IMPLEMENTATION.json'),new_worker_sha256=sha(p),phase_clock_hooks_disabled_in_baseline_and_counts=True))
commands=[
['C:/Program Files/CMake/bin/cmake.exe','-S',str(R/'native'),'-B',str(R/'build'),'-G','Visual Studio 17 2022','-A','x64','-DVulkan_INCLUDE_DIR=C:/VulkanSDK/1.4.357.0/Include','-DVulkan_LIBRARY=C:/VulkanSDK/1.4.357.0/Lib/vulkan-1.lib'],
['C:/Program Files/CMake/bin/cmake.exe','--build',str(R/'build'),'--config','Release','--parallel','6']]
logs=[]
for i,c in enumerate(commands):
 p=subprocess.run(c,capture_output=True,creationflags=subprocess.CREATE_NO_WINDOW);(R/'versions'/('COMPILE_'+str(i)+'.stdout.log')).write_bytes(p.stdout);(R/'versions'/('COMPILE_'+str(i)+'.stderr.log')).write_bytes(p.stderr);logs.append(dict(argv=c,returncode=p.returncode));save(R/'BUILD.json',logs);assert p.returncode==0,p.stdout.decode('utf8',errors='replace')+p.stderr.decode('utf8',errors='replace')
(R/'build/Release/COUNTER_HASH.txt').write_text(sha(R/'COUNTER_SEMANTICS.json')+'\n',encoding='ascii')
print('Native rebuilt with unchanged four GGML DLL bytes',flush=True)
