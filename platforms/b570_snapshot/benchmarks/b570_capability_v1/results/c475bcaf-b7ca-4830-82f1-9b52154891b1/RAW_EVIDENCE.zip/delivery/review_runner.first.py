import argparse,json,sys,time
from pathlib import Path
root=Path(sys.argv[1]).resolve();sys.path.insert(0,str(root/'src/rev2'))
from win import *
exe=sys.argv[2];prompt=(root/'delivery/REVIEW_PROMPT.txt').read_text();job=make_job();child=None;error=None
argv=[exe,'exec','--ephemeral','--sandbox','read-only','--skip-git-repo-check','--cd',str(root),'--color','never','--json','--output-last-message',str(root/'delivery/REVIEW_FINAL.txt'),prompt]
begin=now();log=Journal(root/'delivery/REVIEW_LIFECYCLE.jsonl')
try:
    child=spawn_suspended(argv,root,root/'delivery/REVIEW_EVENTS.jsonl',root/'delivery/REVIEW.stderr.log');ident=identity(child.process);log.emit('REVIEW_CREATED_SUSPENDED',pid=int(child.pid),**ident);checked(job_assign(job,child.process),'assign review Job');need(resume(child.thread)!=0xffffffff,'review resume');checked(close(child.thread),'close review thread');child.thread=None
    while alive(child.process):
        if now()-begin>300*10**9:error='REVIEW_TIMEOUT';terminate_job(job)
        if now()-begin>310*10**9:raise RuntimeError('REVIEW_CLEANUP_UNCONFIRMED')
        time.sleep(.05)
    ts=os_times(child.process);rc=exit_code(child.process);log.emit('REVIEW_OS_EXIT',pid=int(child.pid),exit_code=rc,**ts)
    remaining=job_pids(job)
    if remaining:error=error or 'REVIEW_DESCENDANTS_AFTER_EXIT';terminate_job(job)
    cutoff=now()+5*10**9
    while job_pids(job) and now()<cutoff:time.sleep(.01)
    empty=not job_pids(job);need(empty,'review Job not empty');checked(close(child.process),'close review process');child.process=None;checked(close(job),'close review Job');job=None
    record=dict(exit_code=rc,error=error,job_empty=empty,handles_closed=True,begin_ns=begin,end_ns=now(),review_exe=exe,review_exe_sha256=sha(exe),scope='Review root lifecycle observed; transient review descendants not individually traced; runner/shell own OS lifetime outside coverage')
    dump_new(root/'delivery/REVIEW_RECEIPT.json',record);log.emit('REVIEW_CLOSED',**record);print(json.dumps(record))
except BaseException as e:
    error=repr(e);log.emit('REVIEW_FAILURE',error=error);raise
finally:
    if job:terminate_job(job);close(job)
    if child:
        if child.thread:close(child.thread)
        if child.process:close(child.process)
    log.end()
sys.exit(0 if not error and rc==0 else 1)
