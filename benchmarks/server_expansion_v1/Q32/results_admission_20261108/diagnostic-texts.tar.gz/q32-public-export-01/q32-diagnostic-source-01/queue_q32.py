"""Bounded one-shot Q32 diagnostics. No new candidate or performance panel."""
from pathlib import Path
import datetime, fcntl, hashlib, json, os, subprocess, sys, time
ROOT=Path(sys.argv[1]).resolve()
SOURCE=Path(__file__).resolve().parent
AUDIT=ROOT/'q32-diagnostic-audit-01'
BUILD=ROOT/'q32-diagnostic-build-01'
SUP=ROOT/'q32-diagnostic-supervisor-01'
WORK=ROOT/'q32-diagnostic-run-01'
CUTOFF=datetime.datetime(2026,11,8,21,0,tzinfo=datetime.timezone.utc)
def now():return datetime.datetime.now(datetime.timezone.utc)
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(4*1024**2),b''):h.update(b)
    return h.hexdigest()
def read(p):return json.loads(p.read_text())
def save(p,x):
    with p.open('x') as f:json.dump(x,f,indent=2);f.write('\n')
def eligible():return (CUTOFF-now()).total_seconds()>=960
def main():
    AUDIT.mkdir();WORK.mkdir()
    os.sched_setaffinity(0,{34,35});os.nice(10)
    start=time.monotonic()
    save(AUDIT/'SOURCE_FREEZE.private.json',dict(utc=now().isoformat(),files={str(p):sha(p) for p in SOURCE.rglob('*') if p.is_file()},
        license_sha256=sha(SOURCE/'LICENSE'),inherited_model_access='Pinned Apache-2.0; no new model weights or vocabulary redistribution',
        modes=['zero-forward all-buffer allocation','separate same-profile bounded original-backend smoke'],
        model_correctness='NOT_TESTED',performance_panel='PROHIBITED',M2='DEFERRED',
        startup_cutoff_utc=CUTOFF.isoformat(),minimum_start_margin_s=960,original_reserves_unchanged=True))
    phase='build'
    try:
        if not eligible():raise RuntimeError('Insufficient startup margin; optional work skipped')
        cmd=[sys.executable,'-B',str(SOURCE/'build_admission.py'),'--baseline',str(ROOT/'run-01'),'--runtime',str(ROOT/'m1-runtime-01'),
             '--out',str(BUILD),'--supervisor',str(SUP)]
        env=os.environ.copy();env.update(CUDA_VISIBLE_DEVICES='',OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='1')
        t=time.monotonic()
        with (AUDIT/'build.stdout.log').open('x') as o,(AUDIT/'build.stderr.log').open('x') as e:
            result=subprocess.run(cmd,stdout=o,stderr=e,env=env,timeout=900)
        save(AUDIT/'BUILD_COST.json',dict(command=cmd,returncode=result.returncode,wall_s=time.monotonic()-t))
        assert result.returncode==0,'Fresh observer build failed; retained, no automatic retries'
        sys.path.insert(0,str(SUP));import admission_host as host
        manifest=read(SOURCE/'models.json')
        phase='await_download'
        while not (ROOT/'q32-models-01/Qwen32B-VERIFIED.json').exists():
            status=ROOT/'q32-download-audit-01/STATUS.json'
            if status.exists() and read(status).get('status')=='FAILED_RETAINED':
                raise RuntimeError('Acquisition failed; retain partials and skip GPU diagnostics')
            if not eligible():raise RuntimeError('Download incomplete at optional diagnostic cutoff; no GPU launch')
            time.sleep(10)
        receipt=read(ROOT/'q32-models-01/Qwen32B-VERIFIED.json')
        assert receipt['verified'] and receipt['bytes']==manifest['target']['bytes'] and receipt['sha256']==manifest['target']['sha256']
        target=ROOT/'q32-models-01'/manifest['target']['filename']
        draft=ROOT/'models-final'/manifest['draft']['filename']
        assert target.stat().st_size==manifest['target']['bytes'] and draft.stat().st_size==manifest['draft']['bytes']
        cfg=read(ROOT/'run-01/config-reference-frozen-01.json')
        cfg.update(work_root=str(WORK),reference_freeze=None,reference_freeze_sha256=None,freeze=None,freeze_sha256=None)
        save(WORK/'config.private.json',cfg)
        save(AUDIT/'IDENTITY.private.json',dict(acquisition_receipt_sha256=sha(ROOT/'q32-models-01/Qwen32B-VERIFIED.json'),
            build_sha256=sha(BUILD/'BUILD.json'),dependency_closure_sha256=sha(BUILD/'DEPENDENCIES.json'),
            no_reference_or_candidate_qualification=True,allocated_gpu_uuid=cfg['gpu_uuid']))
        phase='wait_scheduling_lock'
        with (ROOT/'STUDY_SCHEDULING.lock').open('a') as lock:
            while True:
                if not eligible():raise RuntimeError('No diagnostic start before cutoff margin; skip without GPU work')
                try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);break
                except BlockingIOError:time.sleep(2)
            # Download is fully verified and its mutex is drained before either worker.
            for mode in ('allocation','short_forward'):
                if not eligible():raise RuntimeError('No second worker after cutoff margin; retain allocation result')
                phase=mode
                job=dict(family='Qwen32B',target_model=str(target),target_sha256=manifest['target']['sha256'],
                    draft_model=str(draft),draft_sha256=manifest['draft']['sha256'],n_ctx=1024,threads=2,
                    target_ubatch=32,draft_ubatch=4,target_outputs=4,draft_outputs=1,zero_forward=mode=='allocation',
                    inputs=[],placement='all_model_tensors_and_KV_on_one_GPU_v1',mode=mode,forward_text='The capital of France is')
                path=WORK/(mode+'-JOB.json');save(path,job)
                host.run(WORK/'config.private.json',BUILD/'BUILD.json',path,WORK/mode,'admission')
                native=read(WORK/mode/'native/result.json')
                assert native['status']==('ZERO_FORWARD_ADMISSION_PASS' if mode=='allocation' else 'SHORT_FORWARD_SMOKE_PASS_NOT_QUALIFICATION')
                assert native['model_forwards']==0 if mode=='allocation' else 0<native['model_forwards']<=8
                assert native['token_rows']<=70
                samples=[json.loads(x) for x in (WORK/mode/'resources.jsonl').read_text().splitlines()]
                assert samples
                summary=dict(status=native['status'],mode=mode,native_receipt_sha256=sha(WORK/mode/'native/result.json'),
                    host_receipt_sha256=sha(WORK/mode/'HOST.json'),module_map_sha256=sha(WORK/mode/'LOADED_MODULES.json'),
                    memory_sample_count=len(samples),minimum_sampled_free_bytes=min(float(x['gpu']['memory.free'])*1024**2 for x in samples),
                    maximum_sampled_total_minus_free_bytes=max((float(x['gpu']['memory.total'])-float(x['gpu']['memory.free']))*1024**2 for x in samples),
                    memory_scope='Selected-GPU total-minus-free includes driver/reserved/unavailable bytes; 2s sampling, not per-process peak',
                    safety_reserve_bytes=cfg['gpu_reserve_bytes'],model_forwards=native['model_forwards'],token_rows=native['token_rows'],
                    all_weights_and_KV_on_allocated_GPU=True,context_capacity=1024,KV_precision='F16',
                    source_numerics='Unchanged pristine reference archives, original llama_decode; allocation/short-forward observer only',
                    numerical_qualification='NOT_RUN',independent_Q32_reference='NOT_FROZEN',performance_panel='NOT_RUN',
                    limitation='Admission and finite-vector smoke only; no equivalence, speed, long-context, speculative transaction or candidate-Q4 qualification')
                assert summary['minimum_sampled_free_bytes']>=cfg['gpu_reserve_bytes']
                save(WORK/(mode+'-SUMMARY.json'),summary)
                print(json.dumps(summary),flush=True)
        save(AUDIT/'STATUS.json',dict(status='COMPLETE',utc=now().isoformat(),wall_s=time.monotonic()-start,
            last_phase=phase,numerical_qualification='NOT_RUN',performance_panel='NOT_RUN',M2='DEFERRED'))
    except BaseException as e:
        save(AUDIT/'STATUS.json',dict(status='FAILED_OR_SKIPPED_RETAINED',utc=now().isoformat(),phase=phase,error=str(e),
            wall_s=time.monotonic()-start,no_automatic_native_retries=True,numerical_qualification='NOT_RUN',performance_panel='NOT_RUN'))
        raise
if __name__=='__main__':main()
