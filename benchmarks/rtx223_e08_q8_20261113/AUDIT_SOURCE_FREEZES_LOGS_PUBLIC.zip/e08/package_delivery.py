"""Package this successor's closed evidence. No execution, model upload or host-commandline upload."""
from pathlib import Path
import hashlib,json,shutil,zipfile,datetime,ast
root=Path(__file__).resolve().parent;p=root/'numeric-v1';delivery=root/'delivery';delivery.mkdir(exist_ok=False)
sha=lambda f:hashlib.file_digest(Path(f).open('rb'),'sha256').hexdigest()
closed=[]
for n in range(1,7):
 f=Path('D:/HeteroSpec-PC/rtx223-e08')/('attempt-%03d'%n)/'attempt.jsonl';rows=[json.loads(x)['event'] for x in f.read_bytes().splitlines()];tail=rows[-1];assert tail['owned_process_exit_confirmed']
 closed.append(dict(attempt=n,status=tail['kind'],failure=tail['failure'],grants=[r['stage'] for r in rows if r.get('kind')=='stage_permit_consumed'],journal_sha256=sha(f)))
numeric=json.loads((p/'ANALYSIS.json').read_bytes());old=json.loads((root.parent/'rtx223-e07/RESULT.json').read_bytes());old_ledger=Path('D:/HeteroSpec-PC/rtx223-bootstrap-b1/attempt.jsonl');assert sha(old_ledger)==old['ledger_sha256']
result=dict(schema='heterospec.e08.overnight-final.v1',parent='ee999060ea342e96014827f6c14ff8d5118b3d18',completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),bootstrap_attempts=closed,bootstrap_initial_new_limit=3,bootstrap_amended_new_limit=6,amendment_authority='later user instruction to relax quotas; interpreted boundedly, original3 retained; user did not specify exact6',old_B1=dict(status='FAILED_UNCHANGED',ledger_sha256=sha(old_ledger),not_retried_in_same_ledger=True),gates=numeric['gates'],usage=numeric['usage'],C_vs_B=[x for x in numeric['paired_comparisons'] if x['reference']=='B'],cleanup=json.loads((root/'CLEANUP_FINAL.json').read_bytes()),old_ledgers=json.loads((root/'OLD_LEDGERS_RECHECK.json').read_bytes()),original_lifecycle_physical_limit='NOT_CLOSED',implicit_contexts=None,whole_lifecycle_physical_kernels=None,paper_modified=False,PR_merged=False)
(root/'RESULT.json').write_text(json.dumps(result,indent=2),encoding='utf8')
# Compact readable surface; historical versions and full input freezes go in the audit ZIP.
files=[root/'RESULT_ZH.md',root/'RESULT.json',root/'ADMIN_EVENTS.jsonl',root/'BOOTSTRAP_LIMIT_AMENDMENT.json',root/'CLEANUP_FINAL.json',root/'OLD_LEDGERS_RECHECK.json',root/'PROFILE_CLEANUP.json',root/'WINDHAWK_EXCLUDE_BEFORE.json',root/'WINDHAWK_EXCLUDE_APPLIED.json']
files += [p/n for n in ('ANALYSIS.json','TIMING_SAMPLES.csv','BITWISE_INDEPENDENT.json','CONTRACT.json','CONTRACT-v2.json','CONTRACT-v3.json','OPERANDS_FROZEN.json','FINAL_IDENTITIES.json','PROFILE_DATA_PRESERVED.json','APPLICATION_PATH_AUDIT.json','capture-v5.cpp','runner-v6.py','observation.py','Collect-Host.ps1','analyze.py')]
files += [p/'counter-cpu-001/RESULT.json',p/'evidence/qualification-001/result.json',p/'evidence/timing-001/result.json']
for f in files:
 target=delivery/f.relative_to(root);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,target)
archive=delivery/'AUDIT_SOURCE_FREEZES_LOGS.zip';members={}
def add(f,name):
 if name in members:assert members[name]==f;return
 members[name]=f
for f in root.iterdir():
 if f.is_file() and f.suffix in ('.py','.ps1','.json','.jsonl','.log') and not f.name.startswith(('HOST_','publish_')):add(f, str(Path('e08')/f.name))
for folder in [*root.glob('attempt-*'),root/'build',root/'admin-queue',p]:
 for f in folder.iterdir():
  if f.is_file() and f.suffix in ('.py','.cpp','.ps1','.json','.jsonl','.log','.result','.csv') and not f.name.startswith('HOST_'):add(f,str(Path('e08')/f.relative_to(root)))
for folder in [*p.glob('build-*'),*p.glob('capture-build-*'),*p.glob('operator-build-*'),p/'counter-cpu-001']:
 for f in folder.iterdir():
  if f.is_file() and (f.name in ('FREEZE.json','COMMANDS.json','COMMAND.json','BUILD.json','LINK.rsp','operator_probe.cu','application_budget.cpp','hs_launch_budget.hpp','capture.cpp','bound_mmvq_prefix.cuh','bound_quantizer.cuh','two_group_q8.cuh','RESULT.json') or f.suffix=='.log'):add(f,str(Path('e08')/f.relative_to(root)))
state=Path('D:/HeteroSpec-PC/rtx223-e08')
for f in state.rglob('*'):
 if f.is_file() and (f.name in ('attempt.jsonl','native.stdout','native.stderr','bootstrap-family.jsonl','dispatch-clearance.json')):add(f,str(Path('runtime-receipts')/f.relative_to(state)))
for f in (p/'evidence').rglob('*'):
 if f.is_file() and f.suffix in ('.txt','.log','.json'):add(f,str(Path('e08/numeric-v1')/f.relative_to(p)))
license=root.parent/'rtx223-round1-resume-20261112-e04/runtime/source-v1/LICENSE';add(license,'LICENSE_GGML_LLAMA')
syntax=[]
for name,f in members.items():
 if f.suffix=='.py':ast.parse(f.read_text(encoding='utf8'));syntax.append(name)
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,f in sorted(members.items()):z.write(f,name)
manifest=dict(archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,syntax_checked_python_files=len(syntax),members=[dict(name=name,sha256=sha(f),bytes=f.stat().st_size) for name,f in sorted(members.items())],excluded='model, operand/output binaries, DLL/EXE/toolchain bytes, full-host commandline snapshots and third-party Windhawk source')
(delivery/'AUDIT_MANIFEST.json').write_text(json.dumps(manifest,indent=2),encoding='utf8')
(root/'PACKAGE_CHECK.json').write_text(json.dumps(dict(pass_=True,archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,members=len(members),python_syntax_files=len(syntax)),indent=2))
print((root/'PACKAGE_CHECK.json').read_text())
