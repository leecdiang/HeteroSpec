"""Prospective deterministic operand selection; no native execution or comparisons."""
import hashlib
import json
from pathlib import Path
import random
import struct
import fp32

ROOT=Path(__file__).parent
OLD=Path('C:/Users/ASUS/Documents/Codex/2026-10-10/kan/work/HeteroSpec-querylayout/benchmarks/rtx_querylayout_mechanism_v1')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,x):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x',encoding='utf-8') as f:json.dump(x,f,sort_keys=True,indent=2);f.write('\n')
def fbits(x):return struct.unpack('<I',struct.pack('<f',x))[0]
def canonical(root,m):
    assert m['type']==0
    b=(root/m['file']).read_bytes();out=bytearray();ne,nb=m['ne'],m['nb']
    for i3 in range(ne[3]):
        for i2 in range(ne[2]):
            for i1 in range(ne[1]):
                for i0 in range(ne[0]):
                    offset=sum(a*b for a,b in zip((i0,i1,i2,i3),nb));assert offset+4<=len(b)
                    out.extend(b[offset:offset+4])
    return bytes(out)

def main():
    (ROOT/'inputs').mkdir(exist_ok=False)
    report=json.loads((OLD/'OPERATOR_REPLAY.json').read_bytes())
    assert len(report['contexts'])==24
    coverage=[];workloads=[];sources=[]
    for family in ('Qwen','SmolLM2','Llama'):
        for phase in ('prefill','continuation'):
            for q in (1,2,3,4):
                candidates=[]
                for index,ctx in enumerate(report['contexts']):
                    if (ctx['family'],ctx['phase'])!=(family,phase):continue
                    root=Path(ctx['root']);m=json.loads((root/'snapshot.json').read_bytes())
                    if m['q_occupancy']!=q:continue
                    if not all(x['bitwise_equal'] for x in ctx['own_path_MQ_vs_native'].values()):continue
                    if ctx['failures']:continue
                    candidates.append((m['layer'],ctx['task'],index,ctx,m))
                if not candidates:
                    coverage.append(dict(family=family,phase=phase,q=q,status='NOT_AVAILABLE'));continue
                layer,task,index,ctx,m=sorted(candidates,key=lambda v:v[:3])[0]
                assert layer==0 # historical domain only; no invented middle/late data
                root=Path(ctx['root'])
                for name,h in ctx['registry'].items():assert sha(root/name)==h
                boundary=json.loads((root/'LOGICAL_BOUNDARY.json').read_bytes())
                assert boundary['native_decode']['role']=='target' and boundary['native_decode']['scope_mask']==0
                assert len(boundary['native_decode']['positions'])==q
                for repeat in (0,1,2):
                    replay=next(x for x in ctx['replays'] if x['arm']=='MQ' and x['repeat']==repeat)
                    d=Path(replay['path']);receipt=json.loads((d/'REPLAY.json').read_bytes())
                    for name,h in replay['files'].items():assert sha(d/name)==h
                    assert all(x['readback_bitwise_equal'] for x in receipt['fixed_inputs'].values())
                    for stage in ('QK','softmax','AV'):assert canonical(root,m['native_'+stage])==(d/(stage+'.bin')).read_bytes()
                pm,vm=m['native_softmax'],m['V'];assert pm['type']==0 and vm['type']==1
                keys=min(64,pm['ne'][0]);channels=2;pb=(root/pm['file']).read_bytes();vb=(root/vm['file']).read_bytes()
                assert vm['ne'][0]==pm['ne'][0] and vm['ne'][1]>=channels
                P=[[struct.unpack_from('<I',pb,t*pm['nb'][0]+j*pm['nb'][1])[0] for t in range(keys)] for j in range(q)]
                V=[[fbits(struct.unpack_from('<e',vb,t*vm['nb'][0]+c*vm['nb'][1])[0]) for c in range(channels)] for t in range(keys)]
                for row in P+V:
                    for b in row:fp32.decode(b)
                ident=f'native_{family}_{phase}_q{q}'
                w=dict(id=ident,source='NATIVE_OPERAND_SUBVIEW_PR98',q=q,keys=keys,channels=channels,P=P,V=V,
                       owner=f'PR98_context_{index}',epoch=0,layer=0,family=family,phase=phase,
                       source_index=index,subview='head0, KVhead0, channels[0:2], keys[0:64], all physical queries',
                       new_native_capture=False,legacy_RTX_arithmetic_reproduced=False)
                save(ROOT/'inputs'/f'{ident}.json',w);workloads.append(ident)
                coverage.append(dict(family=family,phase=phase,q=q,status='QUALIFIED_HISTORICAL_SUBVIEW',source_index=index,layer=0))
                sources.append(dict(id=ident,source_root=str(root),registry=ctx['registry'],metadata=m,
                                    logical_boundary=boundary,own_path=ctx['own_path_MQ_vs_native'],
                                    replays=ctx['replays'],selection_uses_PQ_QB_equality_or_speed=False,
                                    current_source_hashes_equal_historical_registry=True))
    rng=random.Random(20261015)
    for q in (1,4):
        P=[]
        for j in range(q):
            row=[]
            for t in range(32):
                pair=[0,fbits(2/64)];rng.shuffle(pair);row.extend(pair)
            P.append(row)
        V=[[fbits(rng.randint(-32,32)/16) for c in range(2)] for t in range(64)]
        ident=f'synthetic_q{q}_k64'
        save(ROOT/'inputs'/f'{ident}.json',dict(id=ident,source='SYNTHETIC',q=q,keys=64,channels=2,
                                             P=P,V=V,owner=ident,epoch=0,seed=20261015))
        workloads.append(ident)
    save(ROOT/'NATIVE_COVERAGE.json',dict(groups=coverage,sources=sources,
                                         raw_report_sha256=sha(OLD/'OPERATOR_REPLAY.json'),
                                         PR104_E1='BLOCKED_E2_GATE',native_domain='Historical PR98 layer0 only'))
    base=dict(lanes=4,issue_rate=1,compute_latency=2,contexts=8,context_ports=4,context_write_ports=4,
              buffer_bytes=512,banks=4,bank_ports=4,broadcast_words=8,memory_ports=4,memory_latency=2,queue_depth=8)
    resources=[dict(id='ABSTRACT_WIDE',**base),dict(id='ABSTRACT_SUPPLY_LIMITED',**(base|dict(memory_ports=1,broadcast_words=2,queue_depth=2))),
               dict(id='ABSTRACT_BANK_CONFLICT',**(base|dict(banks=1,bank_ports=2)))]
    from model import MAPPINGS
    cells=[dict(workload=w,resource=r['id'],mapping=m) for w in workloads for r in resources for m in MAPPINGS]
    save(ROOT/'PLAN.json',dict(schema=1,status='PROSPECTIVE_PARITY_PANEL',reference='DECLARED_ARCHITECTURE_REFERENCE',
                              workloads=workloads,resources=resources,cells=cells,seed=20261015,
                              mapping_capabilities='Same available contexts, legal fixed ordering, packed shared supply and multicast; no distinct unimplemented hardware capability credited',
                              parity_scope='Rectangular finite panel and one legal stable-priority policy; not optimality or complete ragged schedule equivalence',
                              budget=dict(child_seconds=14400,rss_bytes=8589934592,derived_bytes=2147483648,formal_cells=1024,max_heavy_jobs=1),
                              crop_rule_frozen_before_candidate_comparisons=True,new_GPU_model_operator_starts=0))
    print(json.dumps(dict(workloads=len(workloads),native=len(sources),missing_groups=sum(g['status']=='NOT_AVAILABLE' for g in coverage),cells=len(cells))))

if __name__=='__main__':main()
