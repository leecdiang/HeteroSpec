# Anonymous evidence index — v0.8.6

Extract this ZIP into a new empty directory, then run `python3 -B verify.py`.
Python 3.11+ standard library suffices; no hardware, models or network required.
Study-separated complete arrays, paired fork scores/actual decisions/continuations,
and condition latency times are included. Original B570 H1 uses 24×3 cap runs;
RTX H2 uses another 24×3 set with earlier EOG and cap endpoints. H2 prediction
matches 72/72 but reference qualification fails at 60/72. B570 immediate fork
decisions remain equal despite scores and some later trajectories changing.

The larger H2 tape/events capsule is separate: see INDEX.json for exact filename,
length and SHA256. Extract that tar.gz into another new directory and execute its
own offline.py as documented in INDEX.json. Its retained original digests may
link to original evidence; anonymity is not a guarantee of unlinkability.

The derived/ directory adds post-study inputs, distributions, conditional arithmetic and a new family-stratified sensitivity stream. verify.py executes both unchanged original scientific assertions and new derived calculations. Source ZIPs reconstruct PDFs; this index/capsule recomputes retained observations.
Arrays are compared element by element against the sealed original records.
Original raw evidence and earlier outputs remain unchanged. Host paths, author
metadata, identity and exact UTC records are excluded from these compact exports.
Derived file hashes do not equal the original file digests; ordinal chronology
cannot authenticate original remote freeze times. Omitted weight/runtime/compiler/
driver bytes and omitted full logits are not authenticated; no model execution,
new measurements or functional HumanEval pass@k. No online upload is implied.
