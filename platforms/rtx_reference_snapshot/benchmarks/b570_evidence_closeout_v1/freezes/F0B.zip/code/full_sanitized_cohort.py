from common import *
sys.path.insert(0,str(REPO/'scripts/platform/b570_evidence_closeout_v1'))
import closeout
# Reuse the completed full-history exclusion audit; no outcome-dependent changes.
audit=load(R/'HISTORY_AUDIT_COMPLETE.json');d=load(DOC/'DESIGN.json')
excluded=set(audit['excluded_ids']);texts=set(audit['excluded_text_sha256'])
mbpp=load(R/'datasets/sanitized-mbpp.json')
candidates=[dict(id='MBPP/'+str(x['task_id']),domain='MBPP',description=x['prompt'],dataset_split='train' if x['task_id']<11 else ('test' if x['task_id']<=510 else ('validation' if x['task_id']<=600 else 'prompt'))) for x in mbpp]
for i,line in enumerate((R/'datasets/gsm8k-test.jsonl').read_text().splitlines()):
 candidates.append(dict(id='GSM8K/test/'+str(i),domain='GSM8K',description=json.loads(line)['question'],dataset_split='test'))
# Extend the normalized-description check to every MBPP row in the same fixed bytes.
# Exact candidate descriptions are matched against the same archived textual sources.
catalog=load(R/'HISTORY_CATALOG_COMPLETE.json')
fullhits={};seen=set();strings={}
def extract(x,src):
 if isinstance(x,dict):
  for key,val in x.items():
   if isinstance(val,str) and key in ['description','question','raw_prompt','formatted_prompt','prompt','text','native_detokenized_prompt']:
    strings.setdefault(closeout.normalized_text(val),src)
   elif isinstance(val,(list,dict)):extract(val,src)
 elif isinstance(x,list):
  for val in x:extract(val,src)
for name,meta in catalog.items():
 p=Path(name)
 if meta['sha256'] in seen or p.suffix not in ['.json','.jsonl','.md','.txt','.tex','.csv']:continue
 seen.add(meta['sha256']);b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==meta['sha256'],('HISTORY_BYTES_CHANGED',name)
 text=b.decode('utf8',errors='replace')
 try:
  if p.suffix=='.json':
   x=json.loads(text);extract(x.get('selected',[]) if p.name=='STATIC_INPUT_SELECTION.json' else x,name)
  elif p.suffix=='.jsonl':
   for line in text.splitlines():
    try:extract(json.loads(line),name)
    except ValueError:pass
  else:strings.setdefault(closeout.normalized_text(text),name)
 except (ValueError,TypeError):pass
for c in candidates:
 if c['domain']!='MBPP' or 11<=int(c['id'].split('/')[1])<=510:continue
 norm=closeout.normalized_text(c['description']);src=next((src for text,src in strings.items() if norm in text),None)
 if src:
  excluded.add(c['id']);fp=hashlib.sha256(norm.encode()).hexdigest();texts.add(fp);fullhits[c['id']]=dict(normalized_description_sha256=fp,evidence_source=src)
audit['excluded_ids']=sorted(excluded);audit['excluded_text_sha256']=sorted(texts);audit['description_evidence'].update(fullhits);audit['MBPP_population']='Complete sanitized-mbpp.json at the same pinned Google commit, all splits; no test-only restriction in PR90';audit['utc_full_population_checked']=now()
save(R/'HISTORY_AUDIT_COMPLETE.json',audit)
eligible=[]
for c in candidates:
 norm=closeout.normalized_text(c['description']);fp=hashlib.sha256(norm.encode()).hexdigest()
 if c['id'] in excluded or fp in texts or closeout.cohort_parity(c['domain'],c['description'])!=1:continue
 c['selection_hash']=hashlib.sha256(('heterospec-final-closeout-v1|'+c['domain']+'|'+norm).encode()).hexdigest();eligible.append(c)
chosen=[]
for dom in ['MBPP','GSM8K']:
 pool=sorted((c for c in eligible if c['domain']==dom),key=lambda c:(c['selection_hash'],c['id']))
 assert len(pool)>=12,(dom,len(pool));chosen+=pool[:12]
save(R/'COHORT_SELECTION.json',dict(status='SELECTED_CPU_ONLY_NO_FORWARD',eligible_counts={dom:sum(c['domain']==dom for c in eligible) for dom in ['MBPP','GSM8K']},selected=chosen,history_sha256=sha(R/'HISTORY_AUDIT_COMPLETE.json'),salt='heterospec-final-closeout-v1',parity=1,selection='first12 per domain ordered full salted SHA256, then task ID',eligible_pool=eligible,utc=now(),no_output_or_gain_selector=True,MBPP_population='complete pinned sanitized corpus; all splits explicitly retained'))
save(R/'COHORT_POPULATION_NOTE.json',dict(status='PROSPECTIVE_BEFORE_FORMAL',protocol='PR90 specifies fixed MBPP sanitized corpus revision and 12 tasks, without a split restriction. Complete pinned sanitized corpus used; existing test-only static default yielded only1 eligible odd task after conservative full-history ID exclusions.',no_dataset_revision_change=True,no_history_exclusions_relaxed=True,no_input_or_output_crop=True,no_formal_forward_before_selection=True,training_unseen_claim=False,MBPP_selected_splits={c['id']:c['dataset_split'] for c in chosen if c['domain']=='MBPP'},source_dataset_sha256=sha(R/'datasets/sanitized-mbpp.json')))
print('FULL_SANITIZED_COHORT', [c['id'] for c in chosen],flush=True)
