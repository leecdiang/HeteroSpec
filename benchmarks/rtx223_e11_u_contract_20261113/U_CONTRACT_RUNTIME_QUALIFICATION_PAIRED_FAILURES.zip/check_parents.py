"""Read-only original result and failure verification; no model runtime load."""
from pathlib import Path
import json,hashlib,math,statistics,datetime
p=Path(__file__).resolve().parent;study=p.parent;e10=study/'rtx223-e10-fewrow';e09=study/'rtx223-e09-c1'
sha=lambda q:hashlib.file_digest(Path(q).open('rb'),'sha256').hexdigest()
records=[]
for row in json.loads((e10/'DELIVERY_VERIFIED.json').read_bytes())['remote_blobs']:
 q=e10/'delivery'/row['path'];assert sha(q)==row['sha256'];records.append(dict(path=str(q),sha256=row['sha256']))
for row in json.loads((e10/'FINAL_IDENTITIES.json').read_bytes())['old_files_checked']:
 assert sha(row['path'])==row['sha256'];records.append(row)
for row in json.loads((e10/'PROFILE_DATA_PRESERVED.json').read_bytes())['files']:
 assert sha(row['preserved'])==row['sha256'];records.append(dict(path=row['preserved'],sha256=row['sha256']))
for q in [e10/'RESULT.json',e10/'CONTRACT.json',e10/'build-002/BUILD.json',e10/'build-002/FREEZE.json',e10/'build-002/operator-upstream.exe',Path('D:/HeteroSpec-PC/rtx223-e10-fewrow/family.jsonl'),Path('D:/HeteroSpec-PC/rtx223-e09-c1/family.jsonl')]:records.append(dict(path=str(q),sha256=sha(q)))
for path,row in json.loads((e10/'build-002/FREEZE.json').read_bytes())['inputs'].items():assert sha(path)==row['sha256']
oldnative=json.loads((e10/'evidence/profile/AC/Temp/e10-qualification-001/result.json').read_bytes());assert oldnative['status']=='FAILED' and oldnative['explicit_prelaunch_charged']==6 and not oldnative['U_qualification'][0]['U_own_contract_pass']
oracle=(study/'rtx223-e08/numeric-v1/evidence/capture-003/backend-output.f32').read_bytes();quant=(study/'rtx223-e08/numeric-v1/evidence/capture-003/quantized/activation_q8_1.bin').read_bytes()
qual=e09/'evidence/e09-qualification-001'
for arm in range(3):
 for repeat in range(2):
  for suffix,expected in [('activation.bin',quant),('output.bin',oracle)]:
   q=qual/('arm'+str(arm)+'-r'+str(repeat)+'-'+suffix);assert q.read_bytes()==expected;records.append(dict(path=str(q),sha256=sha(q)))
timing=json.loads((e09/'evidence/e09-timing-001/result.json').read_bytes());ratios=[]
for mode in ('kernel-only','complete-operator'):
 values=[]
 for b in range(12):
  arms={x['arm']:x['event_ms'] for x in timing['paired_timings'] if x['mode']==mode and x['block']==b};values.append(arms[2]/arms[1])
 ratios.append(dict(mode=mode,C1_over_B_geomean=math.exp(statistics.mean(map(math.log,values))),raw_ratios=values))
result=dict(pass_=True,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),e10_still_FAIL=True,e10_explicit_permits=6,e10_reserved=14,e09_all6_raw_replays_equal_original=True,e09_ratios=ratios,files=records,old_e10_build_inputs=9862,new_model_loads=0,CUDA_initializations=0)
with (p/'PARENTS_VERIFIED.json').open('x',encoding='utf8') as f:json.dump(result,f,indent=2)
print(json.dumps(dict(pass_=True,files=len(records),ratios=ratios)))
