from pathlib import Path
import subprocess,json,hashlib
B=Path(__file__).resolve().parents[1];H=B/'repo/benchmarks/b570_zero_gpu_repair_v1/host';S=B/'sources/benchmarks/b570_paper_support_v1/host'
for name in ('os_process.py','identity.py'):(H/name).write_bytes((S/name).read_bytes())
cs=(S/'LauncherCapture.cs').read_text(encoding='utf-8').replace('>8L*1024*1024*1024','>2L*1024*1024*1024')
(H/'LauncherCapture.cs').write_text(cs,encoding='utf-8',newline='\n')
csc=Path('C:/Windows/Microsoft.NET/Framework64/v4.0.30319/csc.exe')
args=[str(csc),'/nologo','/target:library','/reference:System.Web.Extensions.dll','/out:'+str(H/'LauncherCapture.dll'),str(H/'LauncherCapture.cs')]
p=subprocess.run(args,capture_output=True);(B/'task/CSharp.stdout.log').write_bytes(p.stdout);(B/'task/CSharp.stderr.log').write_bytes(p.stderr)
print(json.dumps({'argv':args,'exit':p.returncode,'compiler_sha256':hashlib.sha256(csc.read_bytes()).hexdigest(),'dll_sha256':hashlib.sha256((H/'LauncherCapture.dll').read_bytes()).hexdigest() if p.returncode==0 else None}));raise SystemExit(p.returncode)
