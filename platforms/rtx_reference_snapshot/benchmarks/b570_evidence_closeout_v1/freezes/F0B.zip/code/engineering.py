from runtime import *
OLD=Path('C:/hs/b570-evidence-pr88-restored-v1')
plan=load(R/'ENGINEERING_PLAN.json')
tasks={t['id']:t for t in load(R/'PR88_ENGINEERING_INPUTS.json')+load(R/'PR88_SYNTHETIC_INPUTS.json')}
armmap=dict(R_stock='R_UB128',R_prod='R_UB512',M_match='M_vulkan_batched_repair',N_k1='C_Q4_K_M_native_greedy_k1',C_k1='C_Q4_K_M_vulkan_batched_repair_k1')
old={}
for p in (OLD/'raw').rglob('RESULT.json'):
 x=load(p)
 if x.get('profile')=='STANDARD_Q6' and not x.get('warm') and x['arm'] in armmap.values():old[x['arm'],x['task'],x['repeat']]=x
def output_old(n):return dict(ids=n['ids'],eog_flags=n['eog'],length=n['length'],terminal_id=n['terminal_id'],stop_reason=n['stop_reason'],cached_tokens=0,truncated=False)
def firstdiff(a,b):
 for i,(x,y) in enumerate(zip(a['ids'],b['ids'])):
  if x!=y:return dict(index=i,reference_id=x,candidate_id=y,reference_length=a['length'],candidate_length=b['length'])
 return dict(index=min(a['length'],b['length']),reference_length=a['length'],candidate_length=b['length'],endpoint_difference=a!=b)
allrows=[];ref={};countsout={};comparisons=[];perturb=[]
try:
 assert load(R/'ZERO_FORWARD_RESULT.json')['status']=='PASS'
 for block in plan['blocks']:
  arm=block['arm'];bid=block['block'];bucket=block['bucket']
  with Worker(arm,bid,bucket,'F0A') as w:
   w.request(tasks[block['warmup']],bid+'|WARM',obs=block['warmup_mode'],warm=True)
   profile_rows={}
   for a in block['requests']:
    t=tasks[a['task']];extra=dict(kind=a['kind'],repeat=a.get('repeat'),profile_mode=a['observation'],order_rank=a.get('mode_rank'),mode_order=a.get('mode_order'))
    r=w.request(t,a['slot'],cap=a['cap'],obs=a['observation'],extra=extra);allrows.append(r)
    key=(t['id'],a['cap'])
    if a['kind']=='exposed':
     inherited=old[armmap[arm],t['id'],a['repeat']]
     eq=r['output']==output_old(inherited['native'])
     comparisons.append(dict(slot=r['slot'],scope='PR88_on_off_complete_output',equal=eq,old_raw_sha256=sha(OLD/'raw'/inherited['unit']/'RESULT.json'),first_difference=None if eq else firstdiff(output_old(inherited['native']),r['output'])))
     assert eq,('INHERITED_OUTPUT_CHANGED',r['slot'])
    if bucket=='core' and a['observation']=='counts':
     if arm=='R_stock':
      if key in ref:assert r['output']==ref[key],('REFERENCE_UNSTABLE',r['slot'])
      else:ref[key]=r['output']
     eq=r['output']==ref[key]
     comparisons.append(dict(slot=r['slot'],scope='R_stock_full_native_output',equal=eq,first_difference=None if eq else firstdiff(ref[key],r['output'])))
     if arm!='N_k1':assert eq,('COMPLETE_OUTPUT_GATE_FAILED',r['slot'])
     countsout[arm,key]=r['output']
    elif bucket=='core' and a['observation']=='heavy':
     eq=r['output']==countsout[arm,key]
     comparisons.append(dict(slot=r['slot'],scope='heavy_counts_boundary',equal=eq))
     assert eq
     raw=load(R/r['memory_path'])
     if arm=='C_k1':
      binds=[x for x in raw['target'] if x['phase']=='BINDING'];assert len(binds)==1 and binds[0]['actual_full_state_bytes_equal']
     for c in raw['verify']:
      assert c['target_ub']==(1 if arm=='C_k1' else ARMS[arm]['continuation_ub'])
    elif bucket=='profile':
     assert r['output']==ref[key],('PROFILE_FULL_OUTPUT_CHANGED',r['slot'])
     profile_rows[t['id'],a['observation']]=r
    save(R/'ENGINEERING_PROGRESS.json',dict(utc=now(),block=bid,last_slot=r['slot'],completed_requests=len(allrows),last_wall_ms=r['wall_ms']))
   if bucket=='profile':
    for tid in DESIGN['mechanism']['calibration_task_ids']:
     rr={m:profile_rows[tid,m] for m in DESIGN['mechanism']['profile_modes']}
     def delta(a,b):return dict(absolute_ms=rr[a]['wall_ms']-rr[b]['wall_ms'],ratio=rr[a]['wall_ms']/rr[b]['wall_ms'])
     perturb.append(dict(arm=arm,task=tid,prompt_length=len(tasks[tid]['prompt_ids']),output_length=rr['counts']['output']['length'],stop_reason=rr['counts']['output']['stop_reason'],slots={m:v['slot'] for m,v in rr.items()},mode_order=rr['counts']['mode_order'],wall_ms={m:v['wall_ms'] for m,v in rr.items()},counts_minus_baseline=delta('counts','baseline'),lite_minus_counts=delta('lite','counts'),heavy_minus_counts=delta('heavy','counts'),full_output_equal=True,no_cost_subtraction=True))
  print('COMPLETED_BLOCK',bid,flush=True)
 save(R/'ENGINEERING_RECORDS.json',allrows);save(R/'OUTPUT_COMPARISONS.json',comparisons);save(R/'OBSERVATION_PERTURBATION.json',dict(rows=perturb,formal_cost_not_discounted=True,finite_order_imbalance='6 rows / 4 modes',etw_attempted=False))
 # Lite clocks deliberately preserve asynchronous enqueue spans. Do not label those completed component walls.
 lite=[r for r in allrows if r['kind']=='profile' and r['measurement_mode']=='lite'];assert len(lite)==24
 evidence=[]
 for r in lite:
  raw=load(R/r['raw_path']);assert raw['component_completed_wall'] is None and raw['elapsed_hooks']
  assert raw['observation']['added_sync'] is False
  evidence.append(dict(slot=r['slot'],raw_sha256=r['raw_evidence_sha256'],component_timing_status=raw['component_timing_status'],completed_wall_partition=False,no_added_sync=True,elapsed_hooks_count=len(raw['elapsed_hooks'])))
 save(R/'MODEL_CALIBRATION.json',dict(status='MODEL_TIMING_UNAVAILABLE',rows=evidence,reason='Lite native decode hook records asynchronous enqueue and existing sampler wait spans, not a mutually exclusive completed whole-request wall partition. No forced synchronization or enqueue-to-completion substitution.'))
 model=dict(status='MODEL_TIMING_UNAVAILABLE',reason='No validated completed component wall partition in the preserved lite observations.',coefficients_ms_per_unit={},design_sha256=closeout.digest(DESIGN),calibration_task_ids=DESIGN['mechanism']['calibration_task_ids'],fit_on_confirmation=False,calibration_sha256=closeout.digest(load(R/'MODEL_CALIBRATION.json')))
 mechanism.validate_model(DESIGN,model);save(R/'MODEL.json',model)
 save(R/'ENGINEERING_GATE.json',dict(status='PASS',all_reference_stable=True,stock_prod_matched_candidate_full_output_equal=True,all_engineering_operational_memory_pass=True,observer_mode_full_output_equal=True,inherited_full_output_equal=True,formal_mode='counts',model_status=model['status'],physical_residency='UNKNOWN',utc=now(),rows=len(allrows),formal_not_started=True))
 print('ALL_ENGINEERING_GATE_PASS',flush=True)
except BaseException as e:
 save(R/'ENGINEERING_RECORDS_PARTIAL.json',allrows);save(R/'OUTPUT_COMPARISONS_PARTIAL.json',comparisons)
 save(R/'ENGINEERING_GATE.json',dict(status='FAILED',reason=str(e),utc=now(),completed_requests=len(allrows),formal_not_started=True));raise
