from pathlib import Path
import hashlib,sys,runpy
p=Path(__file__).resolve().parent
assert hashlib.sha256((p/'cleanup_profile.py').read_bytes()).hexdigest()=='49bd0815abea14f4f4037b8694d5b9a7afb532c9a6af4865b25d0b6ed73080b8'
sys.argv=[str(p/'cleanup_profile.py'),'apply-after-owned-processes-ended']
runpy.run_path(str(p/'cleanup_profile.py'),run_name='__main__')
