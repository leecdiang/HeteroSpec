"""Add final runtime evidence; retain the original preparation archive unchanged."""
from pathlib import Path
import json,hashlib,zipfile,shutil,base64,re,datetime
p=Path(__file__).resolve().parent;d=p/'delivery';sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
assert sha(d/'U_CONTRACT_AUDIT_SOURCE_FREEZES_FAILURES.zip')=='6e4e40b16040a4e1e1ccef2351911a85ba943d514ec82612b0fa740af668d22c'
assert json.loads((p/'RESULT.json').read_bytes())['budget']['explicit_application_permits']==400
q=p/'REPORT_ZH.md';q.write_text(q.read_text(encoding='utf8').replace('13.1113%','13.1118%'),encoding='utf8')
eng=p/'ENGINEERING_FAILURES_ZH.md'
if not (p/'PRE_GPU_ENGINEERING_FAILURES_ZH.md').exists():shutil.copy2(eng,p/'PRE_GPU_ENGINEERING_FAILURES_ZH.md')
eng.write_text((p/'PRE_GPU_ENGINEERING_FAILURES_ZH.md').read_text(encoding='utf8')+'''

## 后续实际执行（2026-11-13，最终）

管理员准入与资格后来完成，旧取消记录不删。timing001/002分别因foreign context在native创建前拒绝，均0显式调用；PID39736约5秒前为ToDesk视频进程，但缺同时creation绑定，不将其作为可豁免身份。未更改ToDesk配置或终止进程。

最后UAC入口一次取消、再由用户本机确认；008 CPU回执路径错误，在profile创建前失败。新create_profile_003.py仅修正不可变e07回执路径，旧脚本/计划保留。010旧文件名cleanup的CPU槽用于修正后准入，8.734秒PASS；实际收尾使用同用户DeleteAppContainerProfile授权API，0返回，无需新UAC/ACL。该文件名不是GPU或清理成功证据。

保持原foreign PID拒绝规则；等待10.078秒连续采样空闲后timing003完成7.297秒、392次显式调用、48样本及48批全量检查PASS。原430预留不退款/重置，实际总400。两次profile及三个控制器都已退出，详见最终报告及各原始回执。没有重试GPU数值资格、没有运行新候选或服务。
''',encoding='utf8')
shutil.copy2(p/'evidence-idle/family.jsonl',d/'FAMILY_FINAL.jsonl')
shutil.copy2(p/'evidence-idle/profile/AC/Temp/e11-timing-003/result.json',d/'TIMING_NATIVE_RESULT.json')
shutil.copy2(p/'evidence-run/profile/AC/Temp/e11-qualification-001/result.json',d/'QUALIFICATION_NATIVE_RESULT.json')
names=['REPORT_ZH.md','RESUME_ZH.md','RESULT.json','FINAL_IDENTITIES.json','CLEANUP_FINAL.json','ENGINEERING_FAILURES_ZH.md','ALL_SAMPLES.csv','ALL_PAIRS.csv','ANALYSIS.json','AMDAHL.json','INDEPENDENT_QUALIFICATION.json','RAW_DIFFERENCE_BINDING.json','LEDGER_INTERPRETATION_FINAL.json','OBSERVATION_SUMMARY.json','HOST_SUMMARY_FINAL.json','POSTRUN_GPU_READONLY.json','FOREIGN_CONTEXT_002.json','CPU_SMOKE_PASS.json','CPU_SMOKE_PASS_V4.json','CPU_SMOKE_PASS_V5.json','IDLE_CPU_TESTS.json','IDLE_CONTINUATION_POLICY.json','CPU_PATH_REPAIR.json','PROFILE_CLEANUP.json','PROFILE_CLEANUP_002.json','PRE_GPU_REPORT_ZH.md','PRE_GPU_FINAL_IDENTITIES.json','PRE_GPU_RESUME_ZH.md','PRE_GPU_ENGINEERING_FAILURES_ZH.md','TWO_REFUSALS_RESULT.json','TWO_REFUSALS_FINAL_IDENTITIES.json','TWO_REFUSALS_CLEANUP_FINAL.json','TIMING_NOT_RUN.json','TIMING_PLAN_003.json','STAGING_V4.json','runner_v5.py','observation_v3.py','idle_admission.py','admin_idle_continuation.py','continuation_proof_v2.py','analyze_v5.py','independent_qualification_v3.py','NEXT_SINGLE_CANDIDATE_ZH.md']
for name in names:shutil.copy2(p/name,d/name)
members=[];archive=d/'U_CONTRACT_RUNTIME_QUALIFICATION_PAIRED_FAILURES.zip'
def add(z,q,name):
 b=q.read_bytes();assert not re.search(rb'(?:sk-[A-Za-z0-9_-]{20,}|gh[pousr]_[A-Za-z0-9]{30,}|Bearer [A-Za-z0-9._-]{30,})',b),'potential secret '+str(q)
 z.writestr(name,b);members.append(dict(path=name,bytes=len(b),sha256=sha(q)))
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for q in sorted(p.iterdir()):
  if q.is_file() and '.private.' not in q.name and q.suffix.lower() in ['.py','.ps1','.json','.jsonl','.csv','.md','.hpp','.inc','.cu','.cpp','.log']:add(z,q,q.name)
 for folder in ['admin-queue','admin-queue-continuation','admin-queue-idle','evidence-run','evidence-idle']:
  if not (p/folder).exists():continue
  for q in sorted((p/folder).rglob('*')):
   if q.is_file() and '.private.' not in q.name and (q.suffix in ['.json','.jsonl','.csv','.log','.result','.stdout','.stderr']):add(z,q,q.relative_to(p).as_posix())
 for n in ['ADMIN_STOP','ADMIN2_STOP','ADMIN3_STOP']:
  if (p/n).exists():add(z,p/n,n)
for name,obj in [('RUNTIME_ARCHIVE_MANIFEST.json',dict(archive=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,entries=members,excluded=['GGUF/raw operand binaries','EXE/DLL','full host command lines/private receipts'],all_CSV_differences_included=True,initial_archive_unchanged=True))]:
 (d/name).write_text(json.dumps(obj,indent=2),encoding='utf8')
(p/'publish_runtime_blob.private.json').write_text(json.dumps(dict(encoding='base64',content=base64.b64encode(archive.read_bytes()).decode())),encoding='utf8')
(d/'DELIVERY_FINAL_MANIFEST.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='e11 prefix only;original preparation archive and histories retained',files=[dict(path=q.name,sha256=sha(q),bytes=q.stat().st_size) for q in sorted(d.iterdir()) if q.name!='DELIVERY_FINAL_MANIFEST.json']),indent=2),encoding='utf8')
print(json.dumps(dict(files=len(list(d.iterdir())),runtime_archive_bytes=archive.stat().st_size,runtime_archive_sha256=sha(archive),entries=len(members))))
