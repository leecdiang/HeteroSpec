from common import *
p=R/'native/worker.cpp';s=p.read_text()
assert 'cp.cb_eval=heavy()?observe_compute:nullptr;' in s
s=s.replace('cp.cb_eval=heavy()?observe_compute:nullptr;cp.cb_eval_user_data=heavy()?this:nullptr;','cp.cb_eval=nullptr;cp.cb_eval_user_data=nullptr;')
s=s.replace('#include <set>','#include <set>\n#include <cstring>\n#include <iomanip>')
s=s.replace('int64_t threshold;std::string profile;', 'std::string luid;bool luid_valid=false;\n int64_t threshold;std::string profile;')
s=s.replace('if(!device)throw std::runtime_error("B570 PCI unavailable");',
'''if(!device)throw std::runtime_error("B570 PCI unavailable");
  VkPhysicalDeviceIDProperties ids{};ids.sType=VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_ID_PROPERTIES;
  VkPhysicalDeviceProperties2 p2{};p2.sType=VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_PROPERTIES_2;p2.pNext=&ids;vkGetPhysicalDeviceProperties2(device,&p2);luid_valid=ids.deviceLUIDValid;
  uint32_t low=0,high=0;memcpy(&low,ids.deviceLUID,4);memcpy(&high,ids.deviceLUID+4,4);std::ostringstream ls;ls<<std::hex<<std::setw(8)<<std::setfill('0')<<high<<"-"<<std::setw(8)<<low;luid=ls.str();''')
s=s.replace('{"device_name",props.deviceName}', '{"device_name",props.deviceName},{"adapter_luid",luid},{"adapter_luid_valid",luid_valid}')
s=s.replace('if(action=="probe"){emit({{"event","PROBE_COMPLETE"},{"forward_calls",0}});return 0;}',
'''if(action=="probe"){std::string finish;if(!std::getline(std::cin,finish)||finish!="PROBE_FINISH")throw std::runtime_error("Explicit zero-forward probe close required");emit({{"event","PROBE_COMPLETE"},{"forward_calls",0},{"target_graphs",llama_b570_work_graphs(tgt.ctx)},{"draft_graphs",dft?llama_b570_work_graphs(dft->ctx):0}});return 0;}''')
anchor='auto start=clock_type::now();auto inp='
assert anchor in s
s=s.replace(anchor,'''observation_mode=req.value("observation_mode",observation_mode);if(observation_mode!="baseline"&&observation_mode!="counts"&&observation_mode!="lite"&&observation_mode!="heavy")throw std::runtime_error("Unknown request observation mode");
   auto start=clock_type::now();auto inp=''')
p.write_text(s,encoding='utf8')
x=load(R/'COUNTER_SEMANTICS.json');x['observation']='baseline disables new work counters; counts integer summaries only; lite enqueue/sample timestamps without added sync; heavy explicit sync/full KV state and periodic memory/readbacks/cycles; compute callbacks disabled in all modes, ETW unavailable';x['mode_switch']='request-level mode switch before reset, same worker/context per profile arm; formal adapter forces counts';save(R/'COUNTER_SEMANTICS.json',x)
save(R/'OBSERVATION_IMPLEMENTATION.json',dict(load(R/'OBSERVATION_IMPLEMENTATION.json'),new_worker_sha256=sha(p),counter_semantics_sha256=sha(R/'COUNTER_SEMANTICS.json'),heavy_compute_callbacks=False,heavy_full_kv_capture=True,request_level_mode_switch=True,probe_waits_for_explicit_finish_no_forward=True,native_adapter_luid_observed=True))
c=['C:/Program Files/CMake/bin/cmake.exe','--build',str(R/'build'),'--config','Release','--parallel','6']
q=subprocess.run(c,capture_output=True,creationflags=subprocess.CREATE_NO_WINDOW)
(R/'versions/COMPILE_2.stdout.log').write_bytes(q.stdout);(R/'versions/COMPILE_2.stderr.log').write_bytes(q.stderr)
save(R/'BUILD_2.json',dict(argv=c,returncode=q.returncode))
assert q.returncode==0,q.stdout.decode(errors='replace')+q.stderr.decode(errors='replace')
(R/'build/Release/COUNTER_HASH.txt').write_text(sha(R/'COUNTER_SEMANTICS.json')+'\n',encoding='ascii')
print('mode switch / LUID / probe build PASS',flush=True)
