param([string]$root)
$ErrorActionPreference='Stop'
$start = [DateTimeOffset]::UtcNow.UtcDateTime.ToString('o')
$procs = Get-CimInstance Win32_Process
$tasks = Get-ScheduledTask
$services = Get-CimInstance Win32_Service
$pattern = 'HeteroSpec|rtx223|rtx221|native-probe|worker.exe|ggml|llama'
$taskHits = @($tasks | Where-Object { ($_.TaskName + ' ' + (($_.Actions | ForEach-Object { $_.Execute + ' ' + $_.Arguments + ' ' + $_.ClassId }) -join ' ')) -match $pattern })
$svcHits = @($services | Where-Object { ($_.Name + ' ' + $_.PathName) -match $pattern })
$worker = @($procs | Where-Object { $_.Name -match '^(worker|native-probe|cpu-probe|llama.*|nvcc)\.exe$' })
$hostEvidence = [ordered]@{
 start_utc=$start; end_utc=[DateTimeOffset]::UtcNow.UtcDateTime.ToString('o')
 processes=@{rows=$procs.Count;system_pid4=@($procs|Where-Object ProcessId -eq 4).Count;candidate_image_hits=$worker.Count;unreadable_commandlines=@($procs|Where-Object {-not $_.CommandLine}).Count}
 task_scheduler=@{rows=$tasks.Count;project_matches=@($taskHits|Select-Object TaskName,State)}
 services=@{rows=$services.Count;project_matches=@($svcHits|Select-Object Name,State)}
}
$hostPath = Join-Path $root 'HOST_PRE_003.json'
if (Test-Path $hostPath) { throw 'Host receipt already exists.' }
$hostEvidence | ConvertTo-Json -Depth 6 | Set-Content -Encoding utf8 -LiteralPath $hostPath
if ($worker.Count -or $taskHits.Count -or $svcHits.Count) { throw 'Visible competing task or dispatch source.' }
