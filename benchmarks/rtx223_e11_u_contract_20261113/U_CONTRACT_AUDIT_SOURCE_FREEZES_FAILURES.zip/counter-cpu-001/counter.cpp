#include <windows.h>
#include <cstring>
#include <stdexcept>
#include <climits>
static void need(bool v,const char*s){if(!v)throw std::runtime_error(s);}
static unsigned used=0,limit=0,operations[4]={};static ULONGLONG deadline=0;
extern "C" void e11_reserve(unsigned n,const char*label) {
    need(n&&used<=limit&&n<=limit-used,"explicit budget refused before dispatch");
    need(GetTickCount64()<deadline,"prelaunch deadline reached");used+=n;
    const char* names[]={"B_quantizer","B_projection","U_quantizer","U_projection"};int id=-1;for(int i=0;i<4;++i)if(strcmp(names[i],label)==0)id=i;need(id>=0&&n==1,"unknown dispatch accounting");operations[id]+=n;
}

int main(){limit=500;deadline=GetTickCount64()+10000;for(int i=0;i<500;++i)e11_reserve(1,"B_quantizer");try{e11_reserve(1,"B_quantizer");return 1;}catch(const std::exception&){}if(operations[0]!=500)return 2;used=0;limit=392;for(int i=0;i<392;++i)e11_reserve(1,"U_projection");try{e11_reserve(1,"U_projection");return 3;}catch(const std::exception&){}used=0;deadline=GetTickCount64()-1;try{e11_reserve(1,"B_projection");return 4;}catch(const std::exception&){}if(used)return 5;deadline=GetTickCount64()+10000;try{e11_reserve(UINT_MAX,"B_projection");return 6;}catch(const std::exception&){}return 0;}
