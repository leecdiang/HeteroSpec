"""CPU-only three-TU C ABI fault tests under the production /EHsc mode."""
from pathlib import Path
import json,subprocess,hashlib
p=Path(__file__).resolve().parent;out=p/'counter-cpu-002';out.mkdir(exist_ok=False)
body=(p/'main_body_v2.inc').read_text();body=body[body.index('static unsigned used='):body.index('static void quantize(')]
impl='#include <windows.h>\n#include <cstring>\n'+body+'\nextern "C" void reset_mock(unsigned cap,bool expired) noexcept {used=0;limit=cap;deadline=GetTickCount64()+(expired?-1:10000);for(auto &x:operations)x=0;refusal_reason=nullptr;}\nextern "C" unsigned mock_used() noexcept{return used;}\n'
wrapper='extern "C" bool e11_reserve(unsigned,const char*) noexcept;\nstatic unsigned fake=0;\nextern "C" bool mock_dispatch() noexcept {if(!e11_reserve(1,"U_projection"))return false;++fake;return true;}\nextern "C" unsigned mock_dispatch_count() noexcept{return fake;}\n'
test='''#include <climits>
extern "C" bool e11_reserve(unsigned,const char*) noexcept;
extern "C" void reset_mock(unsigned,bool) noexcept;
extern "C" unsigned mock_used() noexcept;
extern "C" bool mock_dispatch() noexcept;
extern "C" unsigned mock_dispatch_count() noexcept;
int main(){
 reset_mock(500,false);for(int i=0;i<500;++i)if(!mock_dispatch())return 1;
 if(mock_dispatch()||mock_used()!=500||mock_dispatch_count()!=500)return 2;
 reset_mock(392,false);for(int i=0;i<392;++i)if(!mock_dispatch())return 3;
 if(mock_dispatch()||mock_used()!=392||mock_dispatch_count()!=892)return 4;
 reset_mock(14,true);if(mock_dispatch()||mock_used()!=0||mock_dispatch_count()!=892)return 5;
 reset_mock(14,false);if(e11_reserve(UINT_MAX,"B_quantizer")||mock_used()!=0)return 6;
 if(e11_reserve(0,"B_quantizer")||e11_reserve(1,"unknown")||mock_used()!=0)return 7;
 return 0;
}
'''
for name,text in [('implementation.cpp',impl),('wrapper.cpp',wrapper),('test.cpp',test)]:
 with (out/name).open('x',encoding='utf8',newline='\n') as f:f.write(text)
r=json.loads((p.parent/'rtx223-e10-fewrow/build-002/COMMANDS.json').read_bytes());env=r['environment'].copy();env['TEMP']=env['TMP']=str(out);cl=Path(env['PATH'].split(';')[0])/'cl.exe'
argv=[str(cl),'/nologo','/std:c++17','/EHsc','/O2','/MT',*[str(out/x) for x in ['implementation.cpp','wrapper.cpp','test.cpp']],'/Fe:'+str(out/'counter.exe')]
c=subprocess.run(argv,cwd=out,env=env,capture_output=True,timeout=30);(out/'compile.log').write_bytes(c.stdout+c.stderr);assert c.returncode==0,c.stdout
c=subprocess.run([str(out/'counter.exe')],cwd=out,env=env,capture_output=True,timeout=5);assert c.returncode==0,c.returncode
result=dict(pass_=True,exit_code=0,three_translation_units=True,compiler_flag='/EHsc unchanged;C callbacks now noexcept return failure',tests=['exact500/refuse501','exact392/refuse393','expired_before_dispatch_and_charge','unsigned_overflow','zero/unknown operation rejection','no dispatch on rejection'],CUDA_initializations=0,numerical_DLL_loads=0,source_sha256={x.name:hashlib.sha256(x.read_bytes()).hexdigest() for x in out.glob('*.cpp')})
(out/'RESULT.json').write_text(json.dumps(result,indent=2),encoding='utf8');print(json.dumps(result))
