from pathlib import Path
import json,hashlib
B=Path(__file__).resolve().parents[1];H=B/'repo/benchmarks/b570_zero_gpu_repair_v1/host';L=H/'legacy';L.mkdir()
for name in ('common.py','storage.py','supervisor.py','os_process.py','timing.py','cpu_child.py'):
    data=(B/'sources/benchmarks/b570_paper_support_v1/host'/name).read_text(encoding='utf-8')
    if name=='common.py':
        data=data.replace("BASE = Path('C:/hs/b570-paper-support-v1-20261016')","BASE = Path('C:/hs/b570-zero-gpu-repair-v1-20261016')\nif 'b570-paper-support' in str(BASE.resolve()).lower(): raise ValueError('legacy root forbidden')")
    if name=='storage.py':
        data=data.replace('cancelled=k.CancelIoEx(h,ctypes.byref(ov))',"self.journal.emit('CANCEL_BEGIN',pending=True)\n                    cancelled=k.CancelIoEx(h,ctypes.byref(ov))")
        data=data.replace('completion_error=ctypes.get_last_error()',"completion_error=ctypes.get_last_error()\n                        self.journal.emit('CANCEL_COMPLETION',completed=bool(completed),error=completion_error,bytes=n.value)")
        data=data.replace("if event and not k.CloseHandle(event):self.error=self.error or 'watch event close failure'","if event and not k.CloseHandle(event):self.error=self.error or 'watch event close failure'\n            self.journal.emit('HANDLE_CLOSE_END',error=self.error)")
    (L/name).write_text(data,encoding='utf-8',newline='\n')
print(json.dumps({'ported':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in L.iterdir()},'old_roots_executed':False}))
