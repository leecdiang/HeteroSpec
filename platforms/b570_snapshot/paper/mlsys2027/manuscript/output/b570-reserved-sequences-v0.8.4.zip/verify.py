import hashlib
import json
from collections import defaultdict
from pathlib import Path

def digest(ids):
    return hashlib.sha256(json.dumps(ids, separators=(',', ':')).encode()).hexdigest()

data = json.loads((Path(__file__).parent / 'b570_reserved_sequences.json').read_text())
rows = data['records']
assert len(rows) == 72
by_task = defaultdict(list)
pred_live = ref_live = first_index_matches = 0
divergent = set()
for row in rows:
    task, repetition = row['task_id'], row['repetition']
    assert repetition in (1, 2, 3)
    ids = row['ids']
    assert set(ids) == {'reference', 'predicted', 'live'}
    assert all(len(arr) == 128 and all(isinstance(n, int) and n >= 0 for n in arr) for arr in ids.values())
    assert all(digest(ids[k]) == row['sha256'][k] for k in ids)
    by_task[task].append(row)
    pred_live += ids['predicted'] == ids['live']
    ref_live += ids['reference'] == ids['live']
    if ids['reference'] != ids['live']:
        divergent.add(task)
        pi = next(i for i, (a, b) in enumerate(zip(ids['reference'], ids['predicted'])) if a != b)
        li = next(i for i, (a, b) in enumerate(zip(ids['reference'], ids['live'])) if a != b)
        first_index_matches += pi == li
assert len(by_task) == 24
assert all(sorted(x['repetition'] for x in v) == [1, 2, 3] for v in by_task.values())
assert all(len({tuple(x['ids'][k]) for x in v}) == 1 for v in by_task.values() for k in ('reference', 'predicted', 'live'))
assert pred_live == 72 and ref_live == 60
assert divergent == {'HumanEval/134', 'HumanEval/42', 'HumanEval/145', 'HumanEval/138'}
assert first_index_matches == 12
print('PASS: 24 tasks, 72/72 predictor/live, 60/72 reference/live, 4 divergent tasks, 12/12 divergence indices')
