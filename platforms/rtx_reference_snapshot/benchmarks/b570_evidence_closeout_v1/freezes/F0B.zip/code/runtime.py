from common import *
import threading,queue,collections,re,math
sys.path.insert(0,str(REPO/'scripts/platform/b570_evidence_closeout_v1'))
import closeout,mechanism
DESIGN=load(DOC/'DESIGN.json')
ARMS={x['name']:x for x in DESIGN['conditions']}
LIMITS=dict(core=256,profile=128,formal=1200,formal_warm=50,probe=6)
MODELS=dict(target=Path('C:/hs/b570-mem-run-v1/models/Meta-Llama-3.1-8B-Instruct-Q6_K.gguf'),draft=Path('C:/hs/b570-opt-run-v1/models/Llama-3.2-1B-Instruct-Q4_K_M.gguf'))
EXE=R/'build/Release/b570-evidence-worker.exe'
COUNTER_SHA=sha(R/'COUNTER_SEMANTICS.json')
def ledger():
 return [json.loads(x) for x in (R/'LEDGER.jsonl').read_text().splitlines()] if (R/'LEDGER.jsonl').exists() else []
def budget(kind,unit,slot):
 rows=ledger();counts=collections.Counter()
 for r in rows:
  if r.get('event')=='CHARGE':
   counts[r['bucket']]+=r['units']
   if r['bucket']=='probe':counts['core']+=r['units']
 assert counts['core']+unit<=256 if kind=='probe' else True
 assert counts[kind]+unit<=LIMITS[kind],('BUDGET_BLOCKED',kind,counts)
 assert sum(counts[x] for x in ['core','profile','formal','formal_warm'])+unit<=1634
 starts={r['block']:r for r in rows if r.get('event')=='WORKER_START'}
 closed={r['block']:r for r in rows if r.get('event')=='WORKER_CLOSED'}
 spent=0
 for b,x in starts.items():
  if b in closed:spent+=closed[b]['owned_seconds']
  else:spent+=time.time()-x['epoch']
 assert spent<28800,('GPU_BUDGET_BLOCKED',spent)
 if starts:assert time.time()-min(x['epoch'] for x in starts.values())<7*86400
 assert not any(r.get('event')=='CHARGE' and r.get('slot')==slot for r in rows),('STARTED_SLOT_NO_RETRY',slot)
 event(event='CHARGE',bucket=kind,units=unit,slot=slot,counts_before=dict(counts),owned_seconds_before=spent)
def freeze_guard(stage):
 x=load(R/(stage+'_REMOTE_READBACK.json'))
 assert x['status']=='PASS' and len(x['commit'])==40 and x['actual_remote_blob_bytes_verified']
 m=load(R/(stage+'_MANIFEST.json'))
 for r in m['runtime_files']:
  assert sha(R/r['path'])==r['sha256'],('FROZEN_SOURCE_CHANGED',r['path'])
 return x['commit']
def endpoint(x,t,cap,obs):
 ids=x['ids'];flags=x['eog']
 assert x['prompt_ids']==t['prompt_ids'] and x['cap']==cap
 assert 0<len(ids)<=cap and x['length']==len(ids)==len(flags)
 assert all(type(i)is int and 0<=i<128256 for i in ids)
 assert flags==[i in DESIGN['assets']['Llama']['eog'] for i in ids]
 assert not any(flags[:-1]) and x['terminal_id']==ids[-1]
 assert x['stop_reason']==('EOG' if flags[-1] else 'CAP')
 assert flags[-1] or len(ids)==cap
 assert x['reset_target_min']==x['reset_target_max']==-1
 if x['reset_draft_min'] is not None:assert x['reset_draft_min']==x['reset_draft_max']==-1
 assert x['observation_mode']==obs and not x['memory_violation']
 if obs=='counts':assert x['observation']==DESIGN['formal_observation'] and x['elapsed_hooks'] is None
 if obs!='baseline':
  w=x['workload']
  assert w['counter_semantics_sha256']==COUNTER_SHA
  assert w['output_ids_count']==len(ids)
  assert sum(w[k] for k in ['accepted_committed','first_mismatch_rejected','unexamined_after_mismatch','terminal_discarded','unverified_before_verify'])==w['proposal_generated']==x['proposed']
  assert sum(w[k] for k in ['initial_target_committed','accepted_committed','bonus_committed','correction_committed','fallback_committed'])==len(ids)
  assert w['accepted_committed']==x['accepted']
  assert w['draft_continuation_rows']==w['draft_continuation_calls']
  for role in ['target','draft']:
   h=w[role+'_physical_width_hist'];assert sum(h.values())==w[role+'_micrographs'];assert sum(int(k)*v for k,v in h.items())==w[role+'_micrograph_rows']
  assert sum(w['cycle_progress_hist'].values())==w['verify_cycles']
  assert sum(int(k)*v for k,v in w['cycle_progress_hist'].items())==len(ids)-1 if x['proposed'] else True
 return True
class Worker:
 def __init__(self,arm,block,bucket,stage,probe=False):
  self.arm=arm;self.block=block;self.bucket=bucket;self.probe=probe;self.closed=False
  self.freeze=freeze_guard(stage);self.stage=stage;self.dir=R/'raw'/block;self.dir.mkdir(parents=True,exist_ok=False)
  cfg=ARMS[arm];pins=DESIGN['assets']['Llama']['models']
  assets=[]
  for role in (['target','draft'] if cfg['spec'] else ['target']):
   path=MODELS[role];assets.append(dict(role=role,path=str(path),bytes=path.stat().st_size,sha256=sha(path)))
   assert assets[-1]['sha256']==pins[role]['sha256'] and assets[-1]['bytes']==pins[role]['bytes']
  save(self.dir/'ASSET_REHASH.json',assets)
  budget('probe' if probe else ('formal_warm' if bucket=='formal' else bucket),1,block+'|LOAD_AND_WARM')
  self.reserve_warm=not probe
  self.argv=[str(EXE),'STANDARD_Q6',str(MODELS['target']),str(MODELS['draft']) if cfg['spec'] else 'NONE',str(cfg['prefill_ub']),cfg['mode'],'1',str(self.dir),'probe' if probe else 'resident','counts']
  self.start=time.monotonic();self.start_epoch=time.time();self.events=[];self.lines=[];self.stderr=[];self.q=queue.Queue()
  save(self.dir/'COMMAND.json',dict(argv=self.argv,freeze_commit=self.freeze,utc=now(),observation='counts',no_automatic_warmup=True))
  self.p=subprocess.Popen(self.argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,cwd=EXE.parent,bufsize=0,creationflags=subprocess.CREATE_NO_WINDOW)
  event(event='WORKER_START',block=block,bucket=bucket,pid=self.p.pid,epoch=self.start_epoch,utc_start=now(),probe=probe)
  def out():
   for b in iter(self.p.stdout.readline,b''):
    self.lines.append(b)
    try:
     x=json.loads(b);self.events.append(x);self.q.put(x)
    except Exception as e:self.q.put(dict(event='PARSE_ERROR',reason=str(e)))
   self.q.put(dict(event='EOF',returncode=self.p.wait()))
  def err():
   for b in iter(self.p.stderr.readline,b''):self.stderr.append(b)
  self.threads=[threading.Thread(target=out,daemon=True),threading.Thread(target=err,daemon=True)]
  for t in self.threads:t.start()
  try:
   self.ready=self.wait('READY',timeout=300)
   assert self.ready['pid']==self.p.pid and self.ready['forward_calls']==0
   self.identity()
  except BaseException:
   self.close(failed=True);raise
 def wait(self,name,timeout=180):
  deadline=time.monotonic()+timeout
  while True:
   x=self.q.get(timeout=max(.01,deadline-time.monotonic()))
   if x['event']==name:return x
   if x['event'] in ['ERROR','EOF','PARSE_ERROR']:raise RuntimeError(x)
   if time.monotonic()>deadline:raise TimeoutError(name)
 def send(self,x):self.p.stdin.write((json.dumps(x,separators=(',',':'))+'\n').encode());self.p.stdin.flush()
 def identity(self):
  ps='@(Get-Process -Id '+str(self.p.pid)+').Modules | ForEach-Object { $_.FileName } | ConvertTo-Json'
  a=subprocess.run([str(PS),'-NoProfile','-NonInteractive','-Command',ps],capture_output=True,creationflags=subprocess.CREATE_NO_WINDOW,timeout=30)
  (self.dir/'MODULES.stdout').write_bytes(a.stdout);(self.dir/'MODULES.stderr').write_bytes(a.stderr)
  assert a.returncode==0
  paths=json.loads(a.stdout.decode('utf-8-sig',errors='replace'));paths=paths if isinstance(paths,list) else [paths]
  want=[EXE,*[EXE.parent/x for x in ['llama-b570-memory.dll','ggml-base.dll','ggml.dll','ggml-cpu.dll','ggml-vulkan.dll']]]
  actual={Path(x).name.lower():Path(x) for x in paths}
  modules=[]
  for p in want:
   q=actual[p.name.lower()];assert str(q.resolve()).lower()==str(p.resolve()).lower();assert sha(q)==sha(p);modules.append(dict(path=str(q),sha256=sha(q)))
  self.modules=modules
  weights=[e for e in self.events if e['event']=='WEIGHT_MAP']
  assert len(weights)==(2 if ARMS[self.arm]['spec'] else 1)
  for w in weights:assert w['pid']==self.p.pid and w['tensors'] and all(t['backend_device']=='Vulkan0' and t['gpu_backend_buffer'] for t in w['tensors'])
  contexts=[e for e in self.events if e['event']=='CONTEXT']
  assert len(contexts)==len(weights) and all(e['n_ctx']==1024 and e['numeric_path']=='Vulkan0_F16_KV_FAoff' and e['load_forward_calls']==0 for e in contexts)
  stderr=b''.join(self.stderr).decode(errors='replace')
  kv=[l for l in stderr.splitlines() if 'KV buffer size' in l]
  assert len(kv)>=len(contexts) and all('Vulkan0' in l and 'CPU' not in l for l in kv),(kv,stderr[-2000:])
  assert not re.search(r'failed to allocate|out of (device |gpu )?memory',stderr,re.I)
  mem=[e for e in self.events if e['event']=='MEMORY'];self.memory_validate(mem)
  save(self.dir/'IDENTITY.json',dict(status='PASS',owned_pid=self.p.pid,modules=modules,weight_maps=weights,contexts=contexts,kv_placement_log_lines=kv,memory=mem,physical_residency='UNKNOWN'))
  self.identity_hash=sha(self.dir/'IDENTITY.json')
 def memory_validate(self,samples):
  assert samples
  for m in samples:
   assert m['pid']==self.p.pid and m['scope']=='OWNED_MODEL_PROCESS'
   assert m['vendor_id']==0x8086 and m['device_id']==0xE20C and m['adapter_luid_valid']
   assert m['threshold_bytes']==536870912 and m['headroom_gate']
   h=[h for h in m['heaps'] if h['device_local']]
   assert len(h)==1 and h[0]['index']==0 and h[0]['physical_size_bytes']==10563354624
   assert m['device_local_headroom_bytes']==int(h[0]['budget_bytes'])-int(h[0]['usage_bytes'])>=536870912
 def request(self,t,slot,cap=None,obs='counts',warm=False,extra=None):
  cap=t['cap'] if cap is None else cap
  if self.bucket=='formal':assert obs=='counts' and (self.stage=='F0B')
  if warm:assert self.reserve_warm;self.reserve_warm=False
  else:budget(self.bucket,1,slot)
  uid=hashlib.sha256(slot.encode()).hexdigest()[:32]
  event(event='REQUEST_STARTED',slot=slot,block=self.block,pid=self.p.pid,bucket=self.bucket,warmup=warm,measurement_mode=obs)
  self.send(dict(op='CHECK'));check=self.wait('CHECK_OK');assert check['pid']==self.p.pid
  started=now();begin=time.perf_counter_ns()
  try:
   req=dict(request_id=uid,prompt_ids=t['prompt_ids'],cap=cap,capture=obs=='heavy',observation_mode=obs)
   self.send(req);x=self.wait('RESULT',timeout=240)
   assert x['request_id']==uid and x['pid']==self.p.pid and x['mode']==ARMS[self.arm]['mode']
   endpoint(x,t,cap,obs)
   c=x['actual_condition'];cfg=ARMS[self.arm]
   for k in ['prefill_ub','continuation_ub','output_capacity','maximum_k']:assert c[k]==cfg[k],(c,cfg)
   assert c['logical_batch']==512 and c['n_ctx']==1024 and c['kv']=='F16' and c['flash_attention'] is False and c['threads']==10
   wall=(time.perf_counter_ns()-begin)/1e6
   completed=now()
   # Whole timer ends only after full native RESULT parse and endpoint/config validation.
   done=self.wait('PERSISTED');assert done['request_id']==uid
   rawfile=self.dir/(uid+'.RESULT.json');save(rawfile,x);save(self.dir/(uid+'.REQUEST.json'),req)
   mp=self.dir/(uid+('.trace.json' if obs=='heavy' else '.memory.json'));mem=load(mp);mem=mem['memory'] if obs=='heavy' else mem
   assert mem['violation'] is False;self.memory_validate(mem['samples'])
   output=dict(ids=x['ids'],eog_flags=x['eog'],length=x['length'],terminal_id=x['terminal_id'],stop_reason=x['stop_reason'],cached_tokens=0,truncated=False)
   record=dict(slot=slot,family='Llama',condition=self.arm,task=t['id'],phase='warmup' if warm else self.bucket,warmup=warm,freeze_commit=self.freeze,input_sha256=closeout.digest(t),status='COMPLETED',wall_ms=wall,started_utc=started,completed_utc=completed,runtime_identity_verified=True,identity_receipt_sha256=self.identity_hash,worker_pid=self.p.pid,adapter_pci='8086:E20C',measurement_mode=obs,actual_condition=dict(family='Llama',**cfg),observation=x['observation'],output=output,workload=x['workload'],feature_units=x['feature_units'],raw_evidence_sha256=sha(rawfile),memory_evidence_sha256=sha(mp),raw_path=str(rawfile.relative_to(R)),memory_path=str(mp.relative_to(R)),source_identity_sha256=load(R/'SOURCE_IDENTITY.json')['sha256'],residency_receipt_sha256=None,operational_memory=dict(minimum_signed_headroom_bytes=min(m['device_local_headroom_bytes'] for m in mem['samples']),all_weights_and_kv_gpu_placed=True,allocation_failure=False,cpu_offload=False,known_paging_or_eviction=False,same_worker_budget_identity_verified=True,raw_evidence_sha256=sha(mp),paging_observation='UNAVAILABLE_UNINSTRUMENTED_WDDM',scope='CHECKPOINTS_NOT_CONTINUOUS_RESIDENCY'))
   if extra:record.update(extra)
   save(R/'records'/(uid+'.json'),record)
   event(event='REQUEST_COMPLETED',slot=slot,block=self.block,pid=self.p.pid,warmup=warm,bucket=self.bucket,wall_ms=wall,record_sha256=sha(R/'records'/(uid+'.json')))
   return record
  except BaseException as e:
   event(event='REQUEST_FAILED',slot=slot,block=self.block,pid=self.p.pid,bucket=self.bucket,reason=str(e));save(self.dir/(uid+'.FAILED.json'),dict(slot=slot,reason=str(e),utc=now()));raise
 def finish_probe(self):
  assert self.probe
  self.p.stdin.write(b'PROBE_FINISH\n');self.p.stdin.flush();x=self.wait('PROBE_COMPLETE')
  assert x['forward_calls']==x['target_graphs']==x['draft_graphs']==0
  save(self.dir/'PROBE_COMPLETE.json',x);self.close()
 def close(self,failed=False):
  if self.closed:return
  self.closed=True
  try:
   self.p.stdin.close();self.p.wait(timeout=30)
  except Exception:
   self.p.kill();self.p.wait()
  for t in self.threads:t.join(timeout=5)
  (self.dir/'stdout.jsonl').write_bytes(b''.join(self.lines));(self.dir/'stderr.log').write_bytes(b''.join(self.stderr))
  elapsed=time.monotonic()-self.start
  save(self.dir/'LIFECYCLE.json',dict(pid=self.p.pid,returncode=self.p.returncode,owned_seconds=elapsed,closed_utc=now(),failed=failed or self.p.returncode!=0))
  event(event='WORKER_CLOSED',block=self.block,pid=self.p.pid,returncode=self.p.returncode,owned_seconds=elapsed,failed=failed or self.p.returncode!=0)
  assert self.p.returncode==0 or failed
 def __enter__(self):return self
 def __exit__(self,t,e,tb):self.close(failed=t is not None)
