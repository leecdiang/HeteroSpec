from pathlib import Path
import json,hashlib,os
p=Path(__file__).resolve().parent;sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
def write(q,v):
 with q.open('x',encoding='utf8',newline='\n') as f:json.dump(v,f,indent=2)
smoke=p/'CPU_SMOKE_PASS_V5.json';assert json.loads(smoke.read_bytes())['pass']
oldplan=json.loads((p/'TIMING_PLAN_002.json').read_bytes());oldjob=Path(oldplan['argv'][1]);job=json.loads(oldjob.read_bytes());stageinfo=json.loads((p/'STAGING_V4.json').read_bytes());stage=Path(stageinfo['stage']);profile=Path(stageinfo['profile'])
for name,key in [('weight.bin','weight'),('activation.f32','input'),('backend-output.f32','backend_output'),('activation_q8_1.bin','quantized_activation'),('U-qualified-activation.bin','U_qualified_activation'),('U-qualified-output.bin','U_qualified_output')]:job[key+'_path']=str(stage/name);assert sha(stage/name)==job[key+'_sha256']
job['output_dir']=str(profile/'Temp/e11-timing-003');jobpath=stage/'timing-job-003.json';write(jobpath,job)
oldplan.update(receipt_dir='D:/HeteroSpec-PC/rtx223-e11-u-contract/timing-003',output_dir=job['output_dir'],argv=[str(stage/'operator-ucontract.exe'),str(jobpath)])
mapping={str(p/'runner_v4.py'):p/'runner_v5.py',str(p/'observation_v2.py'):p/'observation_v3.py',str(p/'STAGING_V3.json'):p/'STAGING_V4.json',str(p/'CPU_SMOKE_PASS_V4.json'):smoke,str(oldjob):jobpath}
for row in oldplan['controller_inputs']:
 q=Path(row['path'])
 if row['path'] in mapping:q=mapping[row['path']]
 elif q.name=='U-r0-activation.bin':q=stage/'U-qualified-activation.bin'
 elif q.name=='U-r0-output.bin':q=stage/'U-qualified-output.bin'
 elif 'e11-qualification-001' in str(q) and q.name=='result.json':q=p/'evidence-run/profile/AC/Temp/e11-qualification-001/result.json'
 row.update(path=str(q),sha256=sha(q))
oldplan['controller_inputs'] += [dict(path=str(p/x),sha256=sha(p/x)) for x in ['IDLE_CONTINUATION_POLICY.json','IDLE_CPU_TESTS.json','idle_admission.py','analyze_v5.py']]
plan=p/'TIMING_PLAN_003.json';write(plan,oldplan);entry=p/'execute_timing_003.py'
source="from pathlib import Path\nimport json,hashlib,sys,runpy\np=Path(__file__).resolve().parent\nplan=p/'TIMING_PLAN_003.json'\nassert hashlib.sha256(plan.read_bytes()).hexdigest()=="+repr(sha(plan))+"\nfor row in json.loads(plan.read_bytes())['controller_inputs']:\n assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256']\nsys.argv=[str(p/'runner_v5.py'),str(plan)]\nrunpy.run_path(str(p/'runner_v5.py'),run_name='__main__')\n"
with entry.open('x',encoding='utf8',newline='\n') as f:f.write(source)
q=p/'admin-queue-idle/009-timing-idle.pending';write(q,dict(script=str(entry),sha256=sha(entry),reservation=0,kind='NUMERICAL_CONTINUATION',reservation_ref='003-timing.json',explicit_limit=392));os.rename(q,q.with_suffix('.json'))
print('One idle-gated timing request queued;additionalreservation0;392explicitmax')
