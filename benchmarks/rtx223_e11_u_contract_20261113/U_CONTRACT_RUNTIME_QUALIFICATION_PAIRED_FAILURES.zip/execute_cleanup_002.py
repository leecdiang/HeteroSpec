from pathlib import Path
import hashlib,sys,runpy
p=Path(__file__).resolve().parent
q=p/'cleanup_profile_002.py'
assert hashlib.sha256(q.read_bytes()).hexdigest()=='35958fd2f788c9f495ebf243501727306fa0f9d9da9b7f6c4d7aa43525dadb42'
sys.argv=[str(q),'apply-after-owned-processes-ended']
runpy.run_path(str(q),run_name='__main__')
