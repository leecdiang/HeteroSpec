from runtime import *
def current_spent():
 rows=ledger();starts={r['block']:r for r in rows if r.get('event')=='WORKER_START'};closed={r['block']:r for r in rows if r.get('event')=='WORKER_CLOSED'}
 return sum(closed[b]['owned_seconds'] if b in closed else time.time()-x['epoch'] for b,x in starts.items())
rows=[];active=[None];done=threading.Event();spent=[current_spent()]
def watchdog():
 while not done.wait(.25):
  w=active[0]
  if w is not None and w.p.poll() is None and spent[0]+time.monotonic()-w.start>=28798:
   event(event='OWNED_GPU_BUDGET_STOP',block=w.block,pid=w.p.pid,owned_seconds=spent[0]+time.monotonic()-w.start)
   w.p.kill();return
try:
 assert load(R/'ENGINEERING_GATE.json')['status']=='PASS'
 assert load(R/'F0B_BUDGET_FORECAST.json')['status']=='PASS_FULL_FORMAL_WITH_MARGIN'
 freeze=load(R/'F0B.json');assert freeze['commit']==freeze_guard('F0B')
 inputs=load(R/'CONFIRMATION_INPUTS.json');plan=load(R/'FORMAL_PLAN.json');assert freeze['input_sha256']==closeout.digest(inputs) and freeze['plan_sha256']==closeout.digest(plan)
 assert freeze['before_first_formal_forward'] and freeze['model_frozen_before_first_formal']
 assert not any(r.get('bucket') in ['formal','formal_warm'] for r in ledger()),'NO AUTOMATIC REPLAY OF PREVIOUS FORMAL START'
 tasks={t['id']:t for t in inputs['families']['Llama']};warm=next(t for t in load(R/'PR88_SYNTHETIC_INPUTS.json') if t['id']=='SYNTHETIC/WARM')
 threading.Thread(target=watchdog,daemon=True).start()
 event(event='FORMAL_CAMPAIGN_STARTED',freeze_commit=freeze['commit'],planned=1200,warmups=50,model_sha256=freeze['model_sha256'],utc_f0b_verified=load(R/'F0B_REMOTE_READBACK.json')['utc'])
 for b in plan['blocks']:
  cfg=b['condition'];arm=cfg['name'];bid='formal_s'+str(b['session'])+'_r'+str(b['round'])+'_p'+str(b['position'])+'_'+arm
  w=Worker(arm,bid,'formal','F0B');active[0]=w
  try:
   w.request(warm,bid+'|WARM',warm=True,extra=dict(session=b['session'],round=b['round'],position=b['position']))
   for s in b['slots']:
    t=tasks[s['task']];assert s['input_sha256']==closeout.digest(t)
    r=w.request(t,s['slot'],extra=dict(session=b['session'],round=b['round'],position=b['position'],phase='formal',actual_condition=cfg))
    rows.append(r)
    save(R/'FORMAL_PROGRESS.json',dict(status='RUNNING',utc=now(),completed=len(rows),planned=1200,session=b['session'],round=b['round'],arm=arm,last_slot=s['slot'],last_wall_ms=r['wall_ms'],whole_output_only_no_positive_selection=True,automatic_endpoint_and_memory_guards=True))
  except BaseException:
   w.close(failed=True);active[0]=None;raise
  else:w.close();active[0]=None;spent[0]=current_spent()
  print('FORMAL_BLOCK_COMPLETED',bid,'paid',len(rows),'owned_seconds',round(spent[0],2),flush=True)
 done.set()
 assert len(rows)==1200
 save(R/'FORMAL_RECORDS.json',rows)
 result=closeout.analyse(DESIGN,plan,inputs,rows,freeze);save(R/'RESULTS.json',result)
 m=mechanism.analyse(DESIGN,plan,inputs,rows,freeze,load(R/'MODEL.json'));save(R/'MECHANISM_RESULTS.json',m)
 save(R/'FORMAL_COMPLETION.json',dict(status='COMPLETED',formal_requests=1200,formal_warmups=50,owned_seconds=current_spent(),utc=now(),retries=0))
 save(R/'FORMAL_PROGRESS.json',dict(status='COMPLETED',completed=1200,planned=1200,utc=now()))
 print('FORMAL_COMPLETE',flush=True)
except BaseException as e:
 done.set()
 save(R/'FORMAL_RECORDS_PARTIAL.json',rows);save(R/'FORMAL_COMPLETION.json',dict(status='STOPPED',reason=str(e),formal_requests=len(rows),utc=now(),retries=0))
 raise
