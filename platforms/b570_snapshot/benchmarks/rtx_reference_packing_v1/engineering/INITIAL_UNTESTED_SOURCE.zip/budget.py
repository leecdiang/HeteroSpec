"""Own-child resource watchdog and immutable child lifetime ledger."""
import argparse
import ctypes
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path(__file__).parent
def save(p,x):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x',encoding='utf-8') as f:json.dump(x,f,indent=2);f.write('\n')
class Memory(ctypes.Structure):
    _fields_=[('cb',ctypes.c_ulong),('faults',ctypes.c_ulong)]+[(n,ctypes.c_size_t) for n in ('peak_ws','ws','peak_pool','pool','peak_nonpool','nonpool','page','peak_page')]
def main():
    p=argparse.ArgumentParser();p.add_argument('--label',required=True);p.add_argument('command',nargs=argparse.REMAINDER);a=p.parse_args()
    ledger=ROOT/'child_ledger';ledger.mkdir(exist_ok=True)
    assert not (ROOT/'CPU_JOB.lock').exists(),'one heavy child at a time'
    spent=sum(json.loads(x.read_text())['seconds'] for x in ledger.glob('*-EXIT.json'))
    assert spent<14400
    lock=ROOT/'CPU_JOB.lock';lock.write_text(a.label)
    index=len(list(ledger.glob('*-START.json')));prefix=f'{index:03d}-{a.label}'
    save(ledger/(prefix+'-START.json'),dict(command=a.command,epoch=time.time(),label=a.label))
    start=time.perf_counter();peak=0;reason=None
    try:
        with (ledger/(prefix+'.stdout.log')).open('xb') as out,(ledger/(prefix+'.stderr.log')).open('xb') as err:
            child=subprocess.Popen(a.command,cwd=ROOT,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
            mem=Memory();mem.cb=ctypes.sizeof(mem)
            api=ctypes.WinDLL('psapi').GetProcessMemoryInfo;api.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_ulong]
            while child.poll() is None:
                if api(int(child._handle),ctypes.byref(mem),ctypes.sizeof(mem)):peak=max(peak,mem.peak_ws)
                elapsed=time.perf_counter()-start
                if elapsed+spent>=14400 or peak>8589934592:
                    reason='TIME_OR_RSS_CAP';child.kill();break
                if sum(x.stat().st_size for x in ROOT.rglob('*') if x.is_file())>2147483648:
                    reason='DERIVED_OUTPUT_CAP';child.kill();break
                time.sleep(.1)
            code=child.wait()
        save(ledger/(prefix+'-EXIT.json'),dict(seconds=time.perf_counter()-start,exit_code=code,peak_rss_bytes=peak,stop_reason=reason))
    finally:lock.unlink()
    print(json.dumps(dict(label=a.label,exit_code=code,peak_rss_bytes=peak,seconds=time.perf_counter()-start)))
    sys.exit(code)
if __name__=='__main__':main()
