$ErrorActionPreference='Stop'
$g='C:/hs/pr108-tools/git/cmd/git.exe'
& $g init 'C:/hs/b570-zero-gpu-repair-v1-20261016/repo'
if($LASTEXITCODE){throw 'init failed'}
Set-Location 'C:/hs/b570-zero-gpu-repair-v1-20261016/repo'
& $g remote add origin https://github.com/leecdiang/HeteroSpec.git
if($LASTEXITCODE){throw 'remote failed'}
& $g config core.sparseCheckout true
Set-Content -LiteralPath .git/info/sparse-checkout -Value '/benchmarks/b570_zero_gpu_repair_v1/' -Encoding ascii
& $g fetch --filter=blob:none --depth=1 origin 8b8c78f8fc63195369e276c83216075b8475a352
if($LASTEXITCODE){throw 'fetch failed'}
& $g switch -c codex/b570-zero-gpu-repair-20261016 FETCH_HEAD
if($LASTEXITCODE){throw 'checkout failed'}
& $g status --short
& $g rev-parse HEAD
