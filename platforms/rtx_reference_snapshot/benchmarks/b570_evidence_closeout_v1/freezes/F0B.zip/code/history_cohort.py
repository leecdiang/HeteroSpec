from common import *
import re,unicodedata,urllib.request
sys.path.insert(0,str(REPO/'scripts/platform/b570_evidence_closeout_v1'))
import closeout
d=load(DOC/'DESIGN.json')
dataset=R/'datasets';dataset.mkdir(exist_ok=True)
mbpp_url='https://raw.githubusercontent.com/google-research/google-research/'+d['dataset_pins']['MBPP']['revision']+'/mbpp/sanitized-mbpp.json'
b=urllib.request.urlopen(mbpp_url,timeout=30).read();(dataset/'sanitized-mbpp.json').write_bytes(b)
assert sha(dataset/'sanitized-mbpp.json')=='ca95deaa9a01ef0a6f439f88bcf0dd3db3563d22f22aad6cae04ebb9a8d8c8e9'
gsm_url='https://raw.githubusercontent.com/openai/grade-school-math/'+d['dataset_pins']['GSM8K']['revision']+'/grade_school_math/data/test.jsonl'
b=urllib.request.urlopen(gsm_url,timeout=30).read();(dataset/'gsm8k-test.jsonl').write_bytes(b);assert sha(dataset/'gsm8k-test.jsonl')==d['dataset_pins']['GSM8K']['sha256']
save(R/'DATASET_BINDINGS.json',dict(MBPP=dict(url=mbpp_url,repository='google-research/google-research',revision=d['dataset_pins']['MBPP']['revision'],path='mbpp/sanitized-mbpp.json',sha256=sha(dataset/'sanitized-mbpp.json'),test_id_range=[11,510],full_corpus_availability_not_exposure=True,prior_huggingface_endpoint_404='Revision is official Google Git commit, not current HF dataset Git commit'),GSM8K=dict(url=gsm_url,revision=d['dataset_pins']['GSM8K']['revision'],sha256=sha(dataset/'gsm8k-test.jsonl'),full_corpus_availability_not_exposure=True)))
candidates=[dict(id='MBPP/'+str(x['task_id']),domain='MBPP',description=x['prompt']) for x in load(dataset/'sanitized-mbpp.json') if 11<=x['task_id']<=510]
for i,line in enumerate((dataset/'gsm8k-test.jsonl').read_text().splitlines()):
 x=json.loads(line);candidates.append(dict(id='GSM8K/test/'+str(i),domain='GSM8K',description=x['question']))
assert len([x for x in candidates if x['domain']=='GSM8K'])==1319
excluded=set(d['mandatory_excluded_ids']);texts=set(d['mandatory_excluded_text_sha256']);desc_hits={};id_hits={};catalog={};seen=set();strings={};errors=[]
rx=re.compile(rb'\b(?:MBPP/\d+|GSM8K/test/\d+)\b')
skip={'.git','models','vendor','third_party','node_modules','datasets','corpus','build','candidate-build','tokenizer-build','candidate-src','candidate-common','archive','source-history','__pycache__','gguf','source-blobs','mingit','git','dist','python-deps','dependencies','vocab'}
mechanical={'EXPOSURE_AUDIT.json','EXPOSURE_CATALOG.json','EXPOSURE_SUMMARY.json','E_EXPOSURE_AUDIT.json','E_EXPOSURE_CATALOG.json','INPUT_CANDIDATES.json','E_SELECTION.json','MANDATORY_EXCLUSIONS.json','HISTORY_AUDIT.json','HISTORY_CATALOG.json','HISTORY_AUDIT_COMPLETE.json','HISTORY_CATALOG_COMPLETE.json'}
roots=[Path('C:/hs'),Path('C:/Users/DIANG/Documents/ChatGPT/HeteroSpec'),Path('C:/Users/DIANG/.codex/worktrees')]
def strings_in(x,source):
 if isinstance(x,dict):
  for k,v in x.items():
   if isinstance(v,str) and k in ['description','question','raw_prompt','formatted_prompt','prompt','text','native_detokenized_prompt']:
    n=closeout.normalized_text(v)
    if len(n)>20:strings.setdefault(n,source)
   elif isinstance(v,(dict,list)):strings_in(v,source)
 elif isinstance(x,list):
  for v in x:strings_in(v,source)
def scan(p,b):
 h=hashlib.sha256(b).hexdigest();catalog[str(p)]=dict(sha256=h,bytes=len(b))
 if h in seen:return
 seen.add(h)
 for m in rx.finditer(b):
  ident=m.group().decode();excluded.add(ident);id_hits.setdefault(ident,str(p))
 s=b.decode('utf8',errors='replace')
 try:
  if p.suffix=='.json':strings_in(json.loads(s),str(p))
  elif p.suffix=='.jsonl':
   for line in s.splitlines():
    try:strings_in(json.loads(line),str(p))
    except (ValueError,TypeError):pass
  elif p.suffix in ['.md','.txt','.tex']:strings.setdefault(closeout.normalized_text(s),str(p))
 except (ValueError,TypeError):pass
for root in roots:
 if not root.exists():continue
 for directory,dirs,files in os.walk(root):
  dirs[:]=[n for n in dirs if n not in skip and not n.startswith('.venv')]
  for name in files:
   p=Path(directory)/name
   if p.is_relative_to(R) or p.is_relative_to(REPO) or p.is_relative_to(Path('C:/hs/b570-evidence-readback-v1')):continue
   if name in mechanical or 'STATIC_QUERIES' in name or ('tokenization' in name.lower() and 'stdout' in name.lower()):continue
   if p.suffix.lower() not in {'.json','.jsonl','.md','.txt','.csv','.log','.py','.tex','.yaml'}:continue
   try:
    if p.stat().st_size>128*1024*1024:errors.append(dict(path=str(p),error='TOO_LARGE_FOR_AUDIT'));continue
    b=p.read_bytes()
    if name=='STATIC_INPUT_SELECTION.json':
     x=json.loads(b);subset=x.get('selected',[]);scan(p,json.dumps(subset,ensure_ascii=False).encode())
     catalog[str(p)]=dict(sha256=hashlib.sha256(b).hexdigest(),bytes=len(b),scope='selected only; static eligible pool is corpus availability, not executed exposure')
    else:scan(p,b)
   except OSError as e:errors.append(dict(path=str(p),error=str(e)))
# Exact pinned complete PR84 engineering/formal pools, read separately from broad local audit.
for p in (R/'history_sources').glob('*INPUTS.json'):scan(p,p.read_bytes())
# Exact PR88 engineering/raw task exposure already restored; include all bound descriptions.
scan(R/'PR88_ENGINEERING_INPUTS.json',(R/'PR88_ENGINEERING_INPUTS.json').read_bytes())
for c in candidates:
 norm=closeout.normalized_text(c['description']);fp=hashlib.sha256(norm.encode()).hexdigest()
 hit=next((src for text,src in strings.items() if norm in text),None)
 if hit:excluded.add(c['id']);texts.add(fp);desc_hits[c['id']]=dict(normalized_description_sha256=fp,evidence_source=hit)
assert not errors,errors[:10]
save(R/'HISTORY_CATALOG_COMPLETE.json',catalog)
audit=dict(status='PASS_ACCESSIBLE_ID_AND_EXACT_NORMALIZED_DESCRIPTION',completed=True,by_id_and_description=True,unknown_hosts_disclosed=True,training_unseen_claim=False,excluded_ids=sorted(excluded),excluded_text_sha256=sorted(texts),roots=[str(x) for x in roots],files=len(catalog),unique_hashes=len(seen),id_evidence=id_hits,description_evidence=desc_hits,catalog_sha256=sha(R/'HISTORY_CATALOG_COMPLETE.json'),remote_PR84_head='59b0f87a7011dad15f5e1146591ae83d9556d0e7',remote_PR88_head='4db9bc501fa01c76db50721e7d11e9a0d1e53782',limitations=['Other private hosts and pretraining corpora unavailable. Novel within accessible executed/planned input evidence only.','Static full corpus candidate lists and raw datasets are availability, not all-task exposure. Selected static cohort entries are audited.','Binary source/runtime/archive files excluded from text matching; restored scientific input files audited.','Prior corpus-wide zero-forward TOKENIZATION.stdout.jsonl is static corpus availability, not an executed or registered panel; actual schedules/records remain audited. Preliminary conservative audit overexcluded this static availability and selected no cohort.'],utc=now())
save(R/'HISTORY_AUDIT_COMPLETE.json',audit)
eligible=[]
for c in candidates:
 norm=closeout.normalized_text(c['description']);fp=hashlib.sha256(norm.encode()).hexdigest()
 if c['id'] in excluded or fp in texts or closeout.cohort_parity(c['domain'],c['description'])!=1:continue
 c['selection_hash']=hashlib.sha256(('heterospec-final-closeout-v1|'+c['domain']+'|'+norm).encode()).hexdigest();eligible.append(c)
chosen=[]
for dom in ['MBPP','GSM8K']:
 pool=sorted((c for c in eligible if c['domain']==dom),key=lambda c:(c['selection_hash'],c['id']))
 assert len(pool)>=12,(dom,len(pool));chosen+=pool[:12]
save(R/'COHORT_SELECTION.json',dict(status='SELECTED_CPU_ONLY_NO_FORWARD',eligible_counts={dom:sum(c['domain']==dom for c in eligible) for dom in ['MBPP','GSM8K']},selected=chosen,history_sha256=sha(R/'HISTORY_AUDIT_COMPLETE.json'),salt='heterospec-final-closeout-v1',parity=1,selection='first12 per domain ordered full salted SHA256, then task ID',eligible_pool=eligible,utc=now(),no_output_or_gain_selector=True))
print('HISTORY_COMPLETE',len(catalog),'EXCLUDED',len(excluded),'ELIGIBLE',len(eligible),'SELECTED',[c['id'] for c in chosen],flush=True)
