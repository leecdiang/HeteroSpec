from pathlib import Path
import json,hashlib,sys,runpy
p=Path(__file__).resolve().parent
plan=p/'QUALIFICATION_PLAN_001.json'
assert hashlib.sha256(plan.read_bytes()).hexdigest()=='a2a963ffc036f5a67437c061775b72e19e397d18200a0466ab096181541f01ca'
for row in json.loads(plan.read_bytes())['controller_inputs']:
 assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256']
sys.argv=[str(p/'runner_v3.py'),str(plan)]
runpy.run_path(str(p/'runner_v3.py'),run_name='__main__')
