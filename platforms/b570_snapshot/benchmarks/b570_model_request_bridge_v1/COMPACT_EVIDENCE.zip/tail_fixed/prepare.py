from pathlib import Path
import json,shutil,difflib
root=Path(__file__).parent
backend=Path("C:/hs/b570-qb-broadcast-20261020061400")
prior=Path("C:/hs/b570-model-concurrent-20261020163500")
src=(backend/"ggml-vulkan.cpp").read_text()
needle="""        compute_ctx = ctx->compute_ctx.lock();
        ggml_vk_ctx_end(compute_ctx);

        ggml_vk_submit(compute_ctx, ctx->device->fence);"""
assert src.count(needle)==1
replacement="""        compute_ctx = ctx->compute_ctx.lock();
        // Concurrent timestamps are emitted at dependency boundaries. Close the
        // last interval too, otherwise its nodes (e.g. the output projection)
        // are omitted from both the reported groups and the total.
        if (vk_perf_logger_concurrent) {
            GGML_ASSERT(ctx->query_idx < ctx->num_queries);
            ctx->query_node_idx[ctx->query_idx] = cgraph->n_nodes;
            compute_ctx->s->buffer->buf.writeTimestamp(vk::PipelineStageFlagBits::eAllCommands, ctx->query_pool, ctx->query_idx++);
        }
        ggml_vk_ctx_end(compute_ctx);

        ggml_vk_submit(compute_ctx, ctx->device->fence);"""
fixed=src.replace(needle,replacement)
(root/"ggml-vulkan.cpp").write_text(fixed)
(root/"ggml-vulkan.parent.cpp").write_text(src)
(root/"concurrent-tail.patch").write_text("".join(difflib.unified_diff(src.splitlines(True),fixed.splitlines(True),fromfile="a/ggml/src/ggml-vulkan/ggml-vulkan.cpp",tofile="b/ggml/src/ggml-vulkan/ggml-vulkan.cpp")))
cmake=(backend/"CMakeLists.txt").read_text().split("add_executable(cross")[0]
(root/"CMakeLists.txt").write_text(cmake)
for name in ["model_bridge.cpp","INPUT.json","MODEL_IDENTITY.json"]:shutil.copyfile(prior/name,root/name)
s=(prior/"RUN.ps1").read_text().replace(prior.as_posix(),root.as_posix())
s=s.replace("110.3223807","144.7492952").replace("189.6776193","155.2507048")
s=s.replace("$session -lt 2","$session -lt 3").replace("-lt 140","-lt 55")
s=s.replace("deadline_seconds=120","deadline_seconds=40").replace("WaitForExit(120000)","WaitForExit(40000)")
s=s.replace("if($session -eq 0)","if($session -eq 1)")
s=s.replace("PROFILE_AND_CLEAN_COMPLETED","TAIL_FIXED_THREE_PROCESSES_COMPLETED")
(root/"RUN.ps1").write_text(s)
p=json.loads((prior/"PREREGISTRATION.json").read_text())
p["study"]="TERMINAL_TIMESTAMP_REPAIR_AND_CONCURRENT_CALIBRATION"
p["baseline"]="New clean process using the same tail-fixed runtime as profile and final clean."
p["design"]="Three NEW processes CLEAN_A / FIXED_CONCURRENT_PROFILE / CLEAN_B, same executable, same tail-fixed DLL. Each3 fresh contexts; third-context15 decode medians for coarse calibration."
p["budget"]={"total_seconds":300,"prior_charged_seconds":144.7492952,"remaining_seconds":155.2507048,"parent_deadline_seconds":40,"minimum_remaining_admission":55,"charge":"full native parent wall incl initialization, capture and cleanup"}
p["repair"]="Add terminal timestamp and graph-end node index only when concurrent performance logger is active. Prior logger omitted output-projection tail; all prior results retained."
p["completeness"]="All3 profile-context tables must contain output projection m151936 n1 k4096 exactly16 times; QK/AV/softmax each5004 effective occurrences; all raw full logits equal original clean reference. Mixed groups not fractionally apportioned."
p["calibration"]="Unchanged: third-context median decode clean A/B and profile vs EACH clean all within [0.90,1.10]. Only coarse necessary observer gate; no per-op perturbation or critical-path proof."
p["decision"]="If corrected coarse observer passes and full output/reference and counter checks pass, report instrumented group costs with strict limits; otherwise retain failure and do not claim bottleneck."
p.pop("clean_reference",None)
(root/"PREREGISTRATION.json").write_text(json.dumps(p,indent=2)+"\n")
print("Prepared terminal-timestamp-only backend candidate.")
