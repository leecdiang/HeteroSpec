"""Prepare idle-gated rearm after explicit local confirmation; math/budget unchanged."""
from pathlib import Path
import json,hashlib,shutil,importlib.util
p=Path(__file__).resolve().parent;sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
def write(q,v):
 with q.open('x',encoding='utf8',newline='\n') as f:json.dump(v,f,indent=2)
oldstage=json.loads((p/'STAGING_V3.json').read_bytes());stage=p.parent/'rtx223-e07/staging-B1/e11-ucontract-004';stage.mkdir(exist_ok=False)
for row in oldstage['files']:shutil.copy2(Path(row['path']),stage/Path(row['path']).name)
qual=p/'evidence-run/profile/AC/Temp/e11-qualification-001'
for a,b in [('U-r0-activation.bin','U-qualified-activation.bin'),('U-r0-output.bin','U-qualified-output.bin')]:shutil.copy2(qual/a,stage/b)
files=[dict(path=str(q),sha256=sha(q),bytes=q.stat().st_size,file_id=dict(volume=q.stat().st_dev,inode=q.stat().st_ino)) for q in sorted(stage.iterdir())]
write(p/'STAGING_V4.json',dict(stage=str(stage),profile=oldstage['profile'],package=oldstage['package'],files=files,model_files_copied=0,ACL_changes=0,reused_qualification_result_sha256=sha(qual/'result.json')))
s=(p/'observation_v2.py').read_text();s=s.replace('class ComputeProcess(C.Structure):','class Utilization(C.Structure):\n    _fields_=[("gpu",C.c_uint),("memory",C.c_uint)]\n\nclass ComputeProcess(C.Structure):')
s=s.replace('        self.temperature = None','        self.util_fn = function(self.lib,"nvmlDeviceGetUtilizationRates",C.c_int,v,C.POINTER(Utilization))\n        self.temperature = None')
s=s.replace('    def sample(self, out):','    def utilization(self):\n        v=Utilization();require(self.util_fn(self.device,C.byref(v))==0,"utilization unavailable");return int(v.gpu)\n\n    def sample(self, out):')
s=s.replace('        checked_watermarks(first, first[2], 0, True)','        checked_watermarks(first, first[2], 0, True)\n        initial_util=self.mgmt.utilization();self.emit({"observer":"initial_utilization","percent":initial_util});require(initial_util<=5,"GPU busy before native creation")')
s=s.replace('"compute_processes": len(data[4])})','"compute_processes": len(data[4]),"GPU_utilization_percent":self.mgmt.utilization()})')
with (p/'observation_v3.py').open('x',encoding='utf8',newline='\n') as f:f.write(s)
s=(p/'runner_v4.py').read_text().replace('observation_v2.py','observation_v3.py').replace('STAGING_V3.json','STAGING_V4.json').replace('CPU_SMOKE_PASS_V4.json','CPU_SMOKE_PASS_V5.json').replace('runner_v4.py','runner_v5.py')
with (p/'runner_v5.py').open('x',encoding='utf8',newline='\n') as f:f.write(s)
s=(p/'create_profile.py').read_text().replace('PROFILE_CREATED.json','PROFILE_CREATED_002.json').replace('Current415-kernel','Current500-kernel')
with (p/'create_profile_002.py').open('x',encoding='utf8',newline='\n') as f:f.write(s)
plan=json.loads((p/'CPU_PLAN_004.json').read_bytes());plan.update(receipt_dir='D:/HeteroSpec-PC/rtx223-e11-u-contract/cpu-003',output_dir=str(Path(oldstage['profile'])/'Temp/e11-cpu-003'))
mapping={str(p/'runner_v4.py'):p/'runner_v5.py',str(p/'observation_v2.py'):p/'observation_v3.py',str(p/'STAGING_V3.json'):p/'STAGING_V4.json'}
plan['controller_inputs']=[x for x in plan['controller_inputs'] if Path(x['path']).name!='PROFILE_CREATED.json']
for row in plan['controller_inputs']:
 if row['path'] in mapping:row.update(path=str(mapping[row['path']]),sha256=sha(mapping[row['path']]))
plan['controller_inputs'] += [dict(path=str(p/x),sha256=sha(p/x)) for x in ['create_profile_002.py','idle_admission.py','continuation_proof_v2.py']]
write(p/'CPU_PLAN_005.json',plan)
entry=p/'execute_cpu_005.py';source="from pathlib import Path\nimport json,hashlib,runpy,sys\np=Path(__file__).resolve().parent\nplan=p/'CPU_PLAN_005.json'\nassert hashlib.sha256(plan.read_bytes()).hexdigest()=="+repr(sha(p/'CPU_PLAN_005.json'))+"\nfor row in json.loads(plan.read_bytes())['controller_inputs']:\n assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256']\nrunpy.run_path(str(p/'create_profile_002.py'),run_name='__main__')\nsys.argv=[str(p/'runner_v5.py'),str(plan)]\nrunpy.run_path(str(p/'runner_v5.py'),run_name='__main__')\n"
with entry.open('x',encoding='utf8',newline='\n') as f:f.write(source)
queue=p/'admin-queue-idle';queue.mkdir();write(queue/'008-cpu-readmit.json',dict(script=str(entry),sha256=sha(entry),reservation=0,kind='CPU_ONLY'))
s=(p/'admin_continuation.py').read_text().replace('ADMIN2.bootstrap.log','ADMIN3.bootstrap.log').replace('runner_v4.py','runner_v5.py').replace('continuation_proof.py','continuation_proof_v2.py').replace('CONTINUATION_POLICY.json','IDLE_CONTINUATION_POLICY.json').replace('admin-queue-continuation','admin-queue-idle').replace('ADMIN2_STOP','ADMIN3_STOP').replace('CPU_SMOKE_PASS_V4.json','CPU_SMOKE_PASS_V5.json').replace('006-timing-continuation.json','009-timing-idle.json').replace('005-cpu-readmit.json','008-cpu-readmit.json').replace('007-cleanup.json','010-cleanup.json')
s=s.replace("claimed=True;hard=120","module('idle',root/'idle_admission.py').wait(root,r.ob,event,end,root/'ADMIN3_STOP')\n   claimed=True;hard=120")
s=s.replace("kind='CONTINUATION_","kind='IDLE_CONTINUATION_")
with (p/'admin_idle_continuation.py').open('x',encoding='utf8',newline='\n') as f:f.write(s)
s=(p/'analyze_v4.py').read_text().replace('e11-timing-002','e11-timing-003').replace('rtx223-e11-u-contract/timing-002','rtx223-e11-u-contract/timing-003')
with (p/'analyze_v5.py').open('x',encoding='utf8',newline='\n') as f:f.write(s)
print('Idle-entry sources prepared;no profile,noGPU,no budget change')
