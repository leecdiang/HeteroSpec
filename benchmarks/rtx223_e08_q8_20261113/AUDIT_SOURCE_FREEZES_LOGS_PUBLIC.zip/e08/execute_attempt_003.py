"""Fresh host clearance and the third and final authorized new bootstrap attempt."""
import sys,json,hashlib,subprocess,datetime as dt,runpy
from pathlib import Path
root=Path(__file__).resolve().parent
a=json.loads((root/'APPROVAL_003.json').read_bytes())
now=dt.datetime.now(dt.timezone.utc)
end=dt.datetime.fromisoformat(a['window'][1])
if not dt.datetime.fromisoformat(a['window'][0])<=now<=end-dt.timedelta(seconds=90):
 raise RuntimeError('outside authorized night')
for record in (a['release'],a['contract'],a['etw_smoke'],a['appcontainer_smoke']):
 if hashlib.sha256(Path(record['path']).read_bytes()).hexdigest()!=record['sha256']:
  raise RuntimeError('drift')
subprocess.run(['C:/Program Files/PowerShell/7/pwsh.exe','-NoProfile','-NonInteractive','-File',str(root/'Collect-Host-003.ps1'),'-root',str(root)],check=True,creationflags=0x08000000)
host=root/'HOST_PRE_003.json'
state=Path('D:/HeteroSpec-PC/rtx223-e08/attempt-003');state.mkdir()
clear=dict(observed_utc=dt.datetime.now(dt.timezone.utc).isoformat(),device_uuid=a['device_uuid'],nonce=a['nonce'],source_chats=['221','223-interrupted','223-successor'],pending=[],other_leases=[],fenced_through=a['window'][1],dispatcher_ownership='Single authorized overnight controller. Prior attempt 002 ended with owned_process_exit_confirmed, family ledger preserved. No other visible dedicated worker or project scheduled/service dispatch. Original tasks ended per owner, native runner holds UUID mutex, checks legacy markers and rejects foreign NVML compute processes.',host_snapshot=dict(path=str(host),sha256=hashlib.sha256(host.read_bytes()).hexdigest()))
with (state/'dispatch-clearance.json').open('x',encoding='utf8') as f:json.dump(clear,f,indent=2)
expected=hashlib.sha256((root/'APPROVAL_003.json').read_bytes()).hexdigest()
sys.argv=[str(root/'run_attempt_003.py'),expected]
runpy.run_path(str(root/'run_attempt_003.py'),run_name='__main__')
