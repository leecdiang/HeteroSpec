# Reproduction boundary

The committed `prefill_submit.cpp` is the final source compiled directly by CMake. `prepare.py`, `setup.py` and `prepare_retry.py` retain derivation history; do not run them over the sealed evidence root. They contain platform-specific absolute paths. Preserve the original attempt1 and attempt2 directories.

This experiment uses the frozen PR134 model identities, private request-bridge llama DLL and Vulkan backend. Rebuilding only the C++ host against arbitrary current upstream libraries does not reproduce it. BUILD_MANIFEST.json lists the actual executable, DLLs, source, reference inputs and models used. Full raw evidence is local; LOCAL_ARCHIVE.json supplies its path, size and hash.

On this platform, re-analysis without GPU execution:

```powershell
$py='C:/Users/DIANG/AppData/Local/Programs/Python/Python312/python.exe'
$study='C:/hs/b570-draft-prefill-submit-20261020-r2'
& $py "$study/recheck.py"
& $py "$study/analyze_timing.py"
& $py "$study/stage_analysis.py"
& $py "$study/verify_delivery.py"
```

These checks verify existing evidence; they do not rerun native experiments or certify a different environment. For a new native replication, copy the frozen host source and matching dependencies into a fresh root, preregister a new attempt with its own input and accounting links, rebuild/freeze, then qualify against the original full bytes before timing. Never reuse an existing output directory or reset its ledger.

The native receipt is a whole-parent wall-clock charge including model load, observer/raw capture during qualification, normal cleanup and log capture. It is not measured active GPU occupancy. The full service scientific timer is a distinct boundary documented in RESULT.md.
