"""CPU fault tests and frozen idle-gated launch; no numerical execution."""
from pathlib import Path
import json,hashlib,importlib.util,copy,types,inspect
p=Path(__file__).resolve().parent;state=Path('D:/HeteroSpec-PC/rtx223-e11-u-contract');sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
def write(q,v):
 with q.open('x',encoding='utf8',newline='\n') as f:json.dump(v,f,indent=2)
def module(name,path):
 sp=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);return m
events=[json.loads(x) for x in (state/'family.jsonl').read_bytes().splitlines()];attempt=[json.loads(x) for x in (state/'timing-001/attempt.jsonl').read_bytes().splitlines()]
qual=p/'evidence-run/profile/AC/Temp/e11-qualification-001/result.json';native=json.loads(qual.read_bytes());proof=module('p2',p/'continuation_proof_v2.py');audit=proof.audit(events,attempt,native,sha(p/'CONTRACT.json'))
for mutate in ['reserved','already_idle','native_count']:
 e=copy.deepcopy(events);n=copy.deepcopy(native)
 if mutate=='reserved':e[-1]['total_reserved']=0
 if mutate=='already_idle':e.insert(-1,dict(kind='IDLE_CONTINUATION_CLAIMED'))
 if mutate=='native_count':n['explicit_prelaunch_charged']=9
 try:proof.audit(e,attempt,n,sha(p/'CONTRACT.json'))
 except RuntimeError:pass
 else:raise RuntimeError('invalid idle adoption accepted')
old=module('ob_old',p/'observation.py');new=module('ob_new',p/'observation_v3.py');assert inspect.getsource(old.validate_watermarks)==inspect.getsource(new.validate_watermarks)
idle=module('idle',p/'idle_admission.py');real_time=idle.time;real_run=idle.subprocess.run
class Clock:
 def __init__(self):self.now=0
 def monotonic(self):return self.now
 def time(self):return self.now
 def sleep(self,s):self.now+=s
class Stop:
 def exists(self):return False
for busy in [False,True]:
 clock=Clock();idle.time=clock;records=[]
 class Management:
  def __init__(self,path):pass
  def start(self):pass
  def close(self):pass
  def sample(self,path):return (12*1024**3,11*1024**3,1024**3,30*1024**3,[123] if busy or clock.now<3 else [])
  def utilization(self):return 32 if busy or clock.now<3 else 0
 idle.subprocess.run=lambda *a,**k:types.SimpleNamespace(returncode=0,stdout='[]')
 try:idle.wait(p,types.SimpleNamespace(Management=Management),lambda **x:records.append(x),10000,Stop());passed=True
 except RuntimeError:passed=False
 assert passed is (not busy)
 assert all(x.get('native_process_created') is False for x in records if x['kind']=='IDLE_READ_ONLY_SAMPLE')
 assert bool([x for x in records if x['kind']=='IDLE_WINDOW_CONFIRMED']) is (not busy)
idle.time=real_time;idle.subprocess.run=real_run
write(p/'IDLE_CPU_TESTS.json',dict(pass_=True,adoption_positive=True,adoption_negative_cases=3,unchanged_foreign_PID_predicate=True,busy_window_never_started_native=True,quiet10seconds_required=True,wait_timeout90_no_GPU=True,CUDA_initializations=0,numerical_DLL_loads=0))
prefix=(state/'family.jsonl').read_bytes();assert not (state/'runner.lease').exists() and not Path('D:/HeteroSpec-PC/RTX_EXPERIMENT.lock').exists()
with (p/'FAMILY_PREFIX_BEFORE_IDLE.jsonl').open('xb') as f:f.write(prefix)
policy=dict(prefix_sha256=sha(state/'family.jsonl'),prefix_bytes=len(prefix),failed_attempt_sha256=sha(state/'timing-001/attempt.jsonl'),second_failed_attempt_sha256=sha(state/'timing-002/attempt.jsonl'),qualification_result=str(qual),qualification_result_sha256=sha(qual),audit=audit,runner_context=json.loads((p/'CPU_SMOKE_PASS_V4.json').read_bytes())['runner_context'],authorization='Current500 authorization;user clarified local onsite confirmation after video-session conflict;one idle-gated rearm,no new budget',guards='same foreignPID rejection plus GPUutil<=5 initial,ToDesk video absent,10squiet,max90sreadonlywait',device_run_max_seconds=120)
write(p/'IDLE_CONTINUATION_POLICY.json',policy)
s=(p/'admin_idle_continuation.py').read_text();anchor="audit=proof.audit("
idx=s.index(anchor);s=s[:idx]+"w.need(sha(state/'timing-002/attempt.jsonl')==policy['second_failed_attempt_sha256'],'second failed proof drift')\n"+s[idx:]
with (p/'admin_idle_continuation.py').open('w',encoding='utf8',newline='\n') as f:f.write(s)
s=(p/'Launch-Continuation.ps1').read_text().replace('CONTINUATION_RELEASE.json','IDLE_RELEASE.json').replace('admin_continuation.py','admin_idle_continuation.py').replace('ADMIN2_LAUNCH.json','ADMIN3_LAUNCH.json').replace('append-only continuation','idle-gated append-only continuation')
with (p/'Launch-Idle.ps1').open('x',encoding='utf8',newline='\n') as f:f.write(s)
files=[p/x for x in ['admin_idle_continuation.py','continuation_proof.py','continuation_proof_v2.py','IDLE_CONTINUATION_POLICY.json','IDLE_CPU_TESTS.json','idle_admission.py','runner_v5.py','observation_v3.py','CPU_PLAN_005.json','execute_cpu_005.py','create_profile_002.py','Launch-Idle.ps1','CONTRACT.json','STAGING_V4.json','DEPLOYMENT.json','INDEPENDENT_QUALIFICATION.json','PERFORMANCE_DECISION.json','analyze_v5.py']]
write(p/'IDLE_RELEASE.json',dict(files=[dict(path=str(q),sha256=sha(q)) for q in files],scope='500 unchanged,430charged,416unspent,oneidle-gatednativeattempt;readOnlywait90,quiet10s,eachGPUrun120;noACL/security changes'))
print(json.dumps(dict(CPU_tests_pass=True,audit=audit,ready_for_local_UAC=True)))
