import json,hashlib,subprocess,sys
from pathlib import Path
B=Path(__file__).resolve().parents[1];R=B/'repo';D=R/'benchmarks/b570_zero_gpu_repair_v1';G='C:/hs/pr108-tools/git/cmd/git.exe'
report=json.loads((B/'task/DEV4_FULL1_AUDIT.json').read_text(encoding='utf-8'))
summary={'scope':'Development evidence, not confirmation or readiness','latest_run':'dev4-full-1','case_results':[{k:r.get(k) for k in ('run','revision','case_id','status','reason')} for r in report['cases']],'raw_audit_sha256':hashlib.sha256((B/'task/DEV4_FULL1_AUDIT.json').read_bytes()).hexdigest(),'portable_semantics_tests':32,'raw_auditor_counterexample_tests':10,'confirmation_started':False}
(D/'results/DEVELOPMENT_SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
files={p.relative_to(D).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (D/'host').rglob('*') if p.is_file() and '__pycache__' not in p.parts}
files.update({n:hashlib.sha256((D/n).read_bytes()).hexdigest() for n in ('ACCEPTANCE.json','BUDGET.json','PROTOCOL.md','EVIDENCE.md','SOURCE_LOCK.json','check_receipts.py')})
(D/'results/REVIEW_TARGET.json').write_text(json.dumps({'scope':'Final host, raw/closure auditors, acceptance and fixed protocol; candidate revision4; source hashes before independent review','files':files},sort_keys=True,indent=2)+'\n',encoding='utf-8')
subprocess.run([G,'add','--','benchmarks/b570_zero_gpu_repair_v1'],cwd=R,check=True)
subprocess.run([G,'add','-f','--','benchmarks/b570_zero_gpu_repair_v1/host/LauncherCapture.dll'],cwd=R,check=True)
subprocess.run([G,'-c','commit.gpgsign=false','commit','-m','Implement bounded zero-GPU supervision repair and raw evidence gates'],cwd=R,check=True)
subprocess.run([G,'rev-parse','HEAD'],cwd=R,check=True)
