#!/usr/bin/env python3
"""Stdlib reviewer checks: preserved primary/derived assertions and RTX V4."""
import hashlib,json
from pathlib import Path
from verify_original import validate
from analysis import compute
from verify_v4 import validate as validate_v4
ROOT=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text())
def main():
 m=read(ROOT/'SHA256SUMS.json');assert {p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()}==set(m)|{'SHA256SUMS.json'}
 for n,h in m.items():assert hashlib.sha256((ROOT/n).read_bytes()).hexdigest()==h,n
 studies={p.stem:read(p) for p in (ROOT/'evidence').glob('*.json') if p.stem!='RTX_V4'}
 old=validate(studies);derived,_=compute(read(ROOT/'derived/inputs.json'));assert json.loads(json.dumps(derived))==read(ROOT/'derived/results.json')
 v4=validate_v4(read(ROOT/'evidence/RTX_V4.json'))
 print(json.dumps({'status':'PASS','prior_studies':old,'post_study_replay':'PASS','RTX_V4':v4,'limits':'Retained finite-cohort arrays, raw timer intervals and arithmetic. No GPU execution, trusted absolute-time or omitted-asset authentication.'}))
if __name__=='__main__':main()
